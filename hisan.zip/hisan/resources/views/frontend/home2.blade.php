<!DOCTYPE html>
<!-- saved from url=(0052)https://wdtgrassroot.wpengine.com/rtl-demo/services/ -->
<html dir="rtl" lang="ar"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <link rel="profile" href="https://gmpg.org/xfn/11">


    <title>Services – RTL GrassRoot Site</title>
<meta name="robots" content="noindex, nofollow">
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	<link rel="dns-prefetch" href="https://fonts.googleapis.com/">
<link rel="alternate" type="application/rss+xml" title="RTL GrassRoot Site « الخلاصة" href="https://wdtgrassroot.wpengine.com/rtl-demo/feed/">
<link rel="alternate" type="application/rss+xml" title="RTL GrassRoot Site « خلاصة التعليقات" href="https://wdtgrassroot.wpengine.com/rtl-demo/comments/feed/">
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.2"}};
/*! This file is auto-generated */
!function(s,n){var o,i,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),a=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===a[t]})}function u(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);for(var n=e.getImageData(16,16,1,1),a=0;a<n.data.length;a++)if(0!==n.data[a])return!1;return!0}function f(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\udedf")}return!1}function g(e,t,n,a){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):s.createElement("canvas"),o=r.getContext("2d",{willReadFrequently:!0}),i=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(function(e){i[e]=t(o,e,n,a)}),i}function t(e){var t=s.createElement("script");t.src=e,t.defer=!0,s.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",i=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){s.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+g.toString()+"("+[JSON.stringify(i),f.toString(),p.toString(),u.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"}),r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=function(e){c(n=e.data),r.terminate(),t(n)})}catch(e){}c(n=g(i,f,p,u))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id="wp-emoji-styles-inline-css" type="text/css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id="classic-theme-styles-inline-css" type="text/css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id="global-styles-inline-css" type="text/css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--primary: #D9EF82;--wp--preset--color--secondary: #161616;--wp--preset--color--tertiary: #365140;--wp--preset--color--quaternary: #F9F9F9;--wp--preset--color--body-bg: #FFFAF6;--wp--preset--color--body-text: #161616;--wp--preset--color--alternate: #161616;--wp--preset--color--transparent: rgba(0,0,0,0);--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="stylesheet" id="contact-form-7-css" href="./Services – RTL GrassRoot Site_files/styles.css" type="text/css" media="all">
<link rel="stylesheet" id="contact-form-7-rtl-css" href="./Services – RTL GrassRoot Site_files/styles-rtl.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-plus-elementor-css" href="./Services – RTL GrassRoot Site_files/elementor.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-plus-common-css" href="./Services – RTL GrassRoot Site_files/common.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-pro-widget-css" href="./Services – RTL GrassRoot Site_files/widget.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-elementor-addon-core-css" href="./Services – RTL GrassRoot Site_files/core.css" type="text/css" media="all">
<style id="wdt-elementor-addon-core-inline-css" type="text/css">
:root {
--wdt-elementor-color-primary: #161616;
--wdt-elementor-color-primary-rgb: 22,22,22;
--wdt-elementor-color-secondary: #D9EF82;
--wdt-elementor-color-secondary-rgb: 217,239,130;
--wdt-elementor-color-text: #161616;
--wdt-elementor-color-text-rgb: 22,22,22;
--wdt-elementor-color-accent: #D9EF82;
--wdt-elementor-color-accent-rgb: 217,239,130;
--wdt-elementor-color-custom-1: #161616;
--wdt-elementor-color-custom-1-rgb: 22,22,22;
--wdt-elementor-color-custom-2: #365140;
--wdt-elementor-color-custom-2-rgb: 54,81,64;
--wdt-elementor-color-custom-3: #E6E6E6;
--wdt-elementor-color-custom-3-rgb: 230,230,230;
--wdt-elementor-color-custom-4: #FFFFFF;
--wdt-elementor-color-custom-4-rgb: 255,255,255;
--wdt-elementor-typo-primary-font-family: Fraunces;
--wdt-elementor-typo-primary-font-weight: 600;
--wdt-elementor-typo-secondary-font-family: Fraunces;
--wdt-elementor-typo-secondary-font-weight: 600;
--wdt-elementor-typo-text-font-family: Plus Jakarta Sans;
--wdt-elementor-typo-text-font-weight: 400;
--wdt-elementor-typo-accent-font-family: Fraunces;
--wdt-elementor-typo-accent-font-weight: 500;
}
</style>
<link rel="stylesheet" id="woocommerce-layout-rtl-css" href="./Services – RTL GrassRoot Site_files/woocommerce-layout-rtl.css" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce-smallscreen-rtl-css" href="./Services – RTL GrassRoot Site_files/woocommerce-smallscreen-rtl.css" type="text/css" media="only screen and (max-width: 768px)">
<link rel="stylesheet" id="woocommerce-general-rtl-css" href="./Services – RTL GrassRoot Site_files/woocommerce-rtl.css" type="text/css" media="all">
<style id="woocommerce-inline-inline-css" type="text/css">
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel="stylesheet" id="brands-styles-css" href="./Services – RTL GrassRoot Site_files/brands.css" type="text/css" media="all">
<link rel="preload" as="font" type="font/woff2" crossorigin="anonymous" id="tinvwl-webfont-font-css" href="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/plugins/ti-woocommerce-wishlist/assets/fonts/tinvwl-webfont.woff2?ver=xu2uyi" media="all">
<link rel="stylesheet" id="tinvwl-webfont-rtl-css" href="./Services – RTL GrassRoot Site_files/webfont-rtl.min.css" type="text/css" media="all">
<link rel="stylesheet" id="tinvwl-rtl-css" href="./Services – RTL GrassRoot Site_files/public-rtl.min.css" type="text/css" media="all">
<link rel="stylesheet" id="swiper-css" href="./Services – RTL GrassRoot Site_files/swiper.min.css" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css" href="./Services – RTL GrassRoot Site_files/all.min.css" type="text/css" media="all">
<link rel="stylesheet" id="material-icon-css" href="./Services – RTL GrassRoot Site_files/material-design-iconic-font.min.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-base-css" href="./Services – RTL GrassRoot Site_files/base.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-common-css" href="./Services – RTL GrassRoot Site_files/common(1).css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-modules-listing-css" href="./Services – RTL GrassRoot Site_files/modules-listing.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-modules-default-css" href="./Services – RTL GrassRoot Site_files/modules-default.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-rtl-css" href="./Services – RTL GrassRoot Site_files/rtl.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-social-share-frontend-css" href="./Services – RTL GrassRoot Site_files/social-share-frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="chosen-css" href="./Services – RTL GrassRoot Site_files/chosen.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-fields-css" href="./Services – RTL GrassRoot Site_files/fields.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-search-frontend-css" href="./Services – RTL GrassRoot Site_files/search-frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-media-images-frontend-css" href="./Services – RTL GrassRoot Site_files/media-images-frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-media-attachments-frontend-css" href="./Services – RTL GrassRoot Site_files/media-attachments-frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-modules-singlepage-css" href="./Services – RTL GrassRoot Site_files/modules-singlepage.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-comments-frontend-css" href="./Services – RTL GrassRoot Site_files/comments-frontend.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-business-hours-frontend-css" href="./Services – RTL GrassRoot Site_files/business-hours-frontend.css" type="text/css" media="all">
<link rel="stylesheet" href="./Services – RTL GrassRoot Site_files/dialog.min.css"><link rel="stylesheet" id="elementor-frontend-css" href="./Services – RTL GrassRoot Site_files/custom-frontend-rtl.min.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-8-css" href="./Services – RTL GrassRoot Site_files/post-8.css" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-5-all-css" href="./Services – RTL GrassRoot Site_files/all(1).min.css" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-4-shim-css" href="./Services – RTL GrassRoot Site_files/v4-shims.min.css" type="text/css" media="all">
<link rel="stylesheet" id="e-animation-fadeInLeft-css" href="./Services – RTL GrassRoot Site_files/fadeInLeft.min.css" type="text/css" media="all">
<link rel="stylesheet" id="e-animation-fadeInRight-css" href="./Services – RTL GrassRoot Site_files/fadeInRight.min.css" type="text/css" media="all">
<link rel="stylesheet" id="e-animation-fadeInUp-css" href="./Services – RTL GrassRoot Site_files/fadeInUp.min.css" type="text/css" media="all">
<link rel="stylesheet" id="widget-spacer-css" href="./Services – RTL GrassRoot Site_files/widget-spacer-rtl.min.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-2132-css" href="./Services – RTL GrassRoot Site_files/post-2132.css" type="text/css" media="all">
<style id="wdt-skin-inline-css" type="text/css">
.wdt-dashbord-container .wdt-dashbord-section-holder .wdt-dashbord-section-title,	.wdt-dashbord-section-holder-content .ui-sortable .wdt-social-item-section div[class*="section-options"] span:hover, .wdt-listings-item-wrapper .wdt-listings-item-bottom-section-content .wdt-listings-item-title a:hover, .wdt-add-listing .wdt-dashbord-section-holder-content .wdt-dashboard-option-item div[class*="wdt-dashboard-option-item"] input[type="checkbox"]:checked ~ label:before, .wdt-my-ads-container .wdt-dashbord-section-holder-content .wdt-dashbord-ads-addnew-wrapper .wdt-dashbord-ad-details input[type="checkbox"]:checked ~ label:before, .wdt-dashboard-addincharge-form .wdt-dashbord-section-holder-content .wdt-dashboard-option-item input[type="checkbox"]:checked ~ label:before, .wdt-dashbord-reviews-listing-wrapper .wdt-dashbord-reviews-listing .wdt-ratings-holder span, .wdt-listings-item-wrapper.type1 .wdt-listings-item-bottom-section-content .custom-button-style.wdt-listing-view-details, .wdt-listings-item-wrapper.type2 .wdt-listings-item-bottom-section-content > div.wdt-listings-item-bottom-pricing-holder .custom-button-style, .wdt-packages-item-wrapper .wdt-item-pricing-details ins, .wdt-packages-item-wrapper.type1 .wdt-packagelist-view-details-button span, .wdt-packages-item-wrapper.type1 .wdt-item-status-details .wdt-proceed-button .custom-button-style span, .wdt-packages-item-wrapper.type2 .wdt-packagelist-view-details .custom-button-style span, .wdt-packages-item-wrapper.type2 .wdt-packagelist-view-details .custom-button-style:hover, .wdt-packages-item-wrapper.type2 .wdt-item-status-details .custom-button-style, .wdt-packages-item-wrapper.type2 .wdt-item-status-details .added_to_cart, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .custom-button-style, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .added_to_cart, .wdt-packages-item-wrapper.type3 .wdt-packagelist-view-details .custom-button-style, ul.wdt-dashboard-menus li a, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .wdt-purchased, .wdt-listings-item-wrapper.type3 .wdt-listings-item-bottom-section a.custom-button-style, .wdt-listings-item-wrapper.type4 .wdt-listings-item-bottom-section>div.wdt-listings-item-bottom-pricing-holder .custom-button-style:before, .wdt-listings-item-wrapper.type5 .wdt-listings-item-bottom-section a.custom-button-style, .wdt-listings-item-wrapper.type4 .wdt-listings-item-top-section .wdt-listings-item-top-section-content > div.wdt-listings-utils-item-holder .wdt-listings-utils-item > *, .wdt-listing-taxonomy-item .wdt-listing-taxonomy-meta-data h3 a, wdt-sf-fields-holder input[type="checkbox"].wdt-sf-field:checked ~ label:before, .wdt-sf-location-field-holder .wdt-sf-location-field-inner-holder .wdt-detect-location, .wdt-sf-fields-holder input[type="checkbox"].wdt-sf-field:checked ~ label::before, .wdt-sf-fields-holder .ui-widget.ui-widget-content .wdt-sf-radius-slider-handle, .wdt-sf-features-field-holder > div > div[class*="-handle"], .wdt-custom-login, .wdt-custom-login li a, .wdt-swiper-arrow-pagination a:hover, .wdt-sf-others-field-holder div.wdt-sf-others-list, .wdt-marker-addition-info.wdt-marker-addition-info-totalviews, .wdt-marker-addition-info.wdt-marker-addition-info-averageratings, .wdt-marker-addition-info.wdt-marker-addition-info-startdate, .wdt-marker-addition-info.wdt-marker-addition-info-distance, .wdt-listing-taxonomy-item.type2 .wdt-listing-taxonomy-icon-image > span, .wdt-listing-taxonomy-item .wdt-listing-taxonomy-starting-price-html ins > span, .wdt-listings-item-wrapper:hover .wdt-listings-item-top-section .wdt-listings-item-ad-section, .wdt-listings-item-wrapper:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container, .wdt-listings-item-wrapper.type2 .wdt-listings-item-top-section .wdt-listings-featured-item-container a:after, .wdt-listings-item-wrapper.type2:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container:before, .wdt-listings-item-wrapper.type7 .wdt-listings-item-top-section .wdt-listings-item-ad-section, .wdt-listings-item-wrapper.type7 .wdt-listings-item-top-section .wdt-listings-featured-item-container, .wdt-listings-item-wrapper.type5 .wdt-listings-item-top-section .wdt-listings-featured-item-container:before, .wdt-listings-item-wrapper.type5:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container:after, .wdt-listings-item-wrapper.type3 .wdt-listings-item-top-section div.wdt-listings-item-ad-section, .wdt-listings-item-wrapper.type3 .wdt-listings-item-top-section div.wdt-listings-featured-item-container a, .wdt-listings-item-wrapper.type3:hover .wdt-listings-item-top-section div.wdt-listings-item-ad-section:before, .wdt-listings-item-wrapper.type1:not(.has-post-thumbnail) .wdt-listings-item-top-section .wdt-listings-item-top-section-content .wdt-listings-utils-item-holder > div a, .wdt-listings-item-wrapper.type1:not(.has-post-thumbnail) .wdt-listings-item-top-section .wdt-listings-item-top-section-content .wdt-listings-utils-item-holder > div div, .wdt-dashbord-section-holder-content ul.wdt-dashbord-inbox-listing-messages-wrapper li:hover, .wdt-dashbord-section-holder-content ul.wdt-dashbord-inbox-listing-messages-wrapper li.active, .wdt-listings-comment-list-holder .commentlist li.comment .comment-body .reply a.comment-reply-link, .wdt-listings-countdown-timer-container.type2 .wdt-listings-countdown-timer-holder .wdt-listings-countdown-timer-notice span, .wdt-listings-item-wrapper ul.wdt-listings-contactdetails-list li span, .single-wdt_packages .wdt-item-pricing-details ins, .single-wdt_packages .wdt-item-pricing-details span.amount, .single-wdt_packages .wdt-packagelist-features li:before, .wdt-listings-item-wrapper.type2:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container a:before, .wdt-listings-item-wrapper.type5:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container a:after, .wdt-listings-item-wrapper.type8:hover .wdt-listings-item-top-section div.wdt-listings-featured-item-container a, .wdt-listing-taxonomy-item.type6 .wdt-category-total-items a:hover, .wdt-comment-form-fields-holder input#wdt_media+label:before, .wdt-listings-item-wrapper.type5 .wdt-listings-item-top-section .wdt-listings-featured-item-container a, .wdt-swiper-arrow-pagination a:before, .wdt-packages-item-wrapper .wdt-packagelist-details > h5 a,  .wdt-listings-item-wrapper.type7 .wdt-listings-item-bottom-section .wdt-listings-item-title a, .wdt-user-list-item .wdt-user-item-meta-data h4 a, .wdt-user-list-item.type1 .wdt-user-sociallinks-list li a, .wdt-user-list-item.type2 .wdt-user-contactdetails-list li a, .wdt-user-list-item.type3 .wdt-user-contactdetails-list li span, .wdt-user-list-item.type2 .wdt-user-contactdetails-list li span, .wdt-listings-item-wrapper.type3 .wdt-listings-taxonomy-container li a, .wdt-listings-taxonomy-container.type3 li a, .wdt-listings-item-wrapper .wdt-listings-excerpt span, .wdt-listings-item-wrapper.type7 .wdt-listings-item-bottom-section-content .wdt-listings-item-bottom-left-content div[class*="wdt-listings-"] label[class*="wdt-listings-"], .wdt-comment-form-fields-holder input#wdt_media + label, p.tpl-forget-pwd a, .wdt-listings-item-wrapper.type5 .wdt-listings-item-bottom-section-content > div .wdt-listings-utils-item-holder a, .wdt-dashbord-recent-activites-holder .wdt-dashbord-recent-activites-content p a, .wdt-dashbord-recent-activites-holder .wdt-dashbord-recent-activites-content p strong, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-details h5 a, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-dashboard-owner a, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-details .wdt-mylisting-options-container > a[data-tooltip]:after, .wdt-dashbord-inbox-listing-conversation-wrapper ul.wdt-dashbord-inbox-conversation-list li>span:before, .wdt-listings-dates-container [class*="date-container"] > :not(:last-child), .wdt-listings-dates-container [class*="date-container"] > div:not(:last-child) > :not(:last-child), .wdt-listings-post-dates-container.type1 .wdt-listings-post-date-container span, .wdt-listings-dates-container.type2 [class*="date-container"] > span, p.login-remember input[type="checkbox"]:checked~label:before, .wdt-login-title h2, .wdt-claim-form-container .wdt-claimform-secure-note > span { color:#1e306e}.wdt-pagination.wdt-ajax-pagination ul.page-numbers li span, .wdt-pagination.wdt-ajax-pagination ul.page-numbers li a:hover, .wdt-pagination.wdt-ajax-pagination .prev-post a:hover, .wdt-pagination.wdt-ajax-pagination .next-post a:hover { color:#1e306e}.wdt-pagination.wdt-ajax-pagination .prev-post a, .wdt-pagination.wdt-ajax-pagination .next-post a, .wdt-pagination.wdt-ajax-pagination ul.page-numbers li span, .wdt-pagination.wdt-ajax-pagination ul.page-numbers li a { border-color:#1e306e}.wdt-dashbord-container .woocommerce-orders-table th, .wdt-pagination.wdt-ajax-pagination .prev-post a, .wdt-pagination.wdt-ajax-pagination .next-post a, .wdt-pagination.wdt-ajax-pagination ul.page-numbers li a { background-color:#1e306e}.wdt-packages-item-wrapper .wdt-packagelist-features li:before, .wdt-listings-average-rating-container .wdt-listings-average-rating-holder span, .wdt-listings-average-rating-container .wdt-listings-average-rating-overall, .wdt-listings-featured-item-container.type1 > span, .wdt-listings-dates-container.type2 .wdt-listings-post-date-container span, .wdt-listings-nearby-places-container .wdt-listings-nearby-places-item .wdt-listings-nearby-places-content .wdt-listings-nearby-places-title, .wdt-listings-nearby-places-container .wdt-listings-nearby-places-item .wdt-listings-nearby-places-content .wdt-listings-nearby-places-ratings:before, .wdt-listings-nearby-places-container .wdt-listings-nearby-places-item .wdt-listings-nearby-places-content .wdt-listings-nearby-places-distance:before, .wdt-listings-nearby-places-container .wdt-listings-nearby-places-item .wdt-listings-nearby-places-content .wdt-listings-nearby-places-address:before, .wdt-listings-contactdetails-container.type2 .wdt-listings-contactdetails-list > li span, .wdt-announcement-listing-holder.booknow span, .wdt-announcement-listing-holder.booknow a:hover, .wdt-announcement-listing-holder.contactus:hover h2, .wdt-announcement-listing-holder.contactus:hover p, .wdt-claim-form-container .wdt-claim-form .wdt-claim-form-title, .wdt-listings-dates-container.type4 [class*="date-container"] span, .wdt-listings-countdown-timer-container.type2 .wdt-countdown-wrapper .wdt-countdown-icon-wrapper, .wdt-listings-countdown-timer-container.type2 .wdt-listings-countdown-timer-holder .wdt-listings-countdown-timer-holder .wdt-listings-countdown-timer-notice span,[class*="wdt-listings-utils-"] .wdt-listings-price-container .wdt-listings-price-item ins, .wdt-yelp-places-container .wdt-yelp-places-item .wdt-yelp-places-content .wdt-yelp-places-title, .wdt-yelp-places-container .wdt-yelp-places-item .wdt-yelp-places-content .wdt-yelp-places-ratings:before, .wdt-yelp-places-container .wdt-yelp-places-item .wdt-yelp-places-content .wdt-yelp-places-distance:before, .wdt-yelp-places-container .wdt-yelp-places-item .wdt-yelp-places-content .wdt-yelp-places-address:before, div[class*="-output-data-container"] .wdt-ajax-load-image .wdt-loader-inner, .wdt-sf-fields-holder input[type="text"] ~ span:not(.wdt-detect-location), .wdt-listings-contactform input ~ span, .wdt-listings-contactform textarea ~ span,.wdt-comment-form-fields-holder p input[type="text"]~span, .wdt-comment-form-fields-holder p input[type="email"]~span, .wdt-comment-form-fields-holder p textarea~span, .wdt-listings-item-wrapper:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container a, form.lidd_mc_form .lidd_mc_input input[type="text"]~span:not(#lidd_mc_total_amount-error):before, form.lidd_mc_form .lidd_mc_input input[type="text"]~span:not(#lidd_mc_total_amount-error):after, .wdt-user-list-item.type3 .wdt-user-sociallinks-list li a, .wdt-user-list-item.type3 .wdt-user-contactdetails-list li a, .wdt-listings-contactdetails-container.type2 .wdt-listings-contactdetails-list > li a, .wdt-listings-item-wrapper.type7 .wdt-listings-item-bottom-section-content .wdt-listings-item-bottom-right-content .wdt-listings-utils-item-holder a, .wdt-listings-features-box-container.type3 .wdt-listings-features-box-item .wdt-listings-features-box-item-icon, .wdt-announcement-listing-holder.announcement, [class*="wdt-listings-utils-"] .wdt-listings-taxonomy-container .wdt-listings-taxonomy-list li a:hover span[class*="wdt"], .wdt-listings-item-wrapper.type6 .wdt-listings-item-bottom-section .wdt-listings-utils-item-holder a.wdt-listings-utils-favourite-item, .wdt-listings-attachment-holder.type1 .wdt-listings-attachment-box-item span, #loginform .wdt-login-field-item input~span, .wdt-listings-claim-form>.wdt-listings-claim-form-item input~span, .wdt-listings-claim-form>.wdt-listings-claim-form-item textarea~span, .wdt-listings-comment-list-holder .comment-body .comment-meta .comment-author b.fn, .wdt-listings-claim-form>.wdt-listings-claim-form-item input#wdt-claimform-verification-file+label, .wdt-listings-social-share-container .wdt-listings-social-share-list li a:hover, .wdt-listings-social-share-container .wdt-listings-social-share-list li a:hover, .wdt-user-list-item.type3 .wdt-user-item-meta-data .wdt-listings-social-share-container .wdt-listings-social-share-list li a:hover { color:#1e306e}ul.wdt-dashboard-menus li a span, .wdt-dashboard-user-package-details .wdt-dashboard-package-detail span.wdt-dashboard-package-detail-value, .wdt-dashboard-user-package-details .wdt-dashboard-package-detail span.wdt-dashboard-package-detail-title, .wdt-dashbord-container .wdt-dashbord-section-holder .wdt-dashbord-statistics-counter-label, .custom-button-style, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-details .wdt-mylisting-options-container > a, .wdt-dashbord-section-holder-content ul.wdt-dashbord-reviews-listing-options-wrapper li:hover, .wdt-dashbord-section-holder-content ul.wdt-dashbord-reviews-listing-options-wrapper li.wdt-active, .wdt-dashboard-container .woocommerce-button.view, .wdt-listings-item-wrapper.type1:hover .wdt-listings-item-bottom-section-content .custom-button-style.wdt-listing-view-details:hover, .wdt-listings-item-wrapper.type2 .wdt-listings-item-bottom-section-content > div.wdt-listings-item-bottom-pricing-holder .custom-button-style:hover,	.wdt-dashbord-container .wdt-packages-container .wdt-packages-item-wrapper .wdt-packagelist-details .wdt-item-status-details .wdt-proceed-button a.custom-button-style, .wdt-packages-item-wrapper.type1 .wdt-packagelist-view-details-button:hover, .wdt-packages-item-wrapper.type1 .wdt-item-status-details .wdt-proceed-button .custom-button-style:hover,  .wdt-packages-item-wrapper.type1 .wdt-item-status-details .wdt-proceed-button .added_to_cart:hover, .wdt-packages-item-wrapper.type2 .wdt-item-status-details .custom-button-style:hover, .wdt-packages-item-wrapper.type2 .wdt-item-status-details .added_to_cart:hover, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .custom-button-style:hover, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .added_to_cart:hover, .wdt-packages-item-wrapper.type3 .wdt-packagelist-view-details .custom-button-style:hover, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .wdt-purchased:hover, .wdt-listings-item-wrapper.type3 .wdt-listings-item-bottom-section a.custom-button-style:hover, .wdt-listings-item-wrapper.type4 .wdt-listings-item-bottom-section>div.wdt-listings-item-bottom-pricing-holder .custom-button-style:hover, .wdt-sf-orderby-field-holder ul.wdt-sf-orderby-list li a:hover, .wdt-sf-orderby-field-holder ul.wdt-sf-orderby-list li a.active, .wdt-sf-fields-holder .ui-widget-content .ui-state-default.ui-state-active, .wdt-sf-fields-holder.wdt-sf-features-field-holder .ui-widget.ui-widget-content, div[class*="-output-data-container"] .wdt-swiper-pagination-holder .wdt-swiper-bullet-pagination.swiper-pagination-bullets .swiper-pagination-bullet:hover, div[class*="-output-data-container"] .wdt-swiper-pagination-holder .wdt-swiper-bullet-pagination.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active, .wdt-sf-others-field-holder div.wdt-sf-others-list:hover, .wdt-dashbord-ads-addnew-wrapper ul.wdt-addtocart-purhcase-preview-wrapper li:not(.duration):not(.total-amount) span.active, .wdt-marker-container, .wdt-marker-addition-info.wdt-marker-addition-info-categoryimage .wdt-marker-addition-info-categoryimage-inner, table.wdt-my-incharges-table thead tr th, .wdt-dashbord-load-buyer-listings-content table thead tr th, table.wdt-custom-table > tbody:first-child > tr > th, .wdt-dashbord-ads-listing table.wdt-custom-table tbody tr td:last-child a:hover, .wdt-listings-item-wrapper .wdt-listings-item-top-section .wdt-listings-featured-item-container a, .wdt-listings-item-wrapper .wdt-listings-item-top-section .wdt-listings-item-ad-section, .wdt-listings-item-wrapper.type3 .wdt-listings-item-top-section div.wdt-listings-item-ad-section:before, .wdt-listings-item-wrapper.type3 .wdt-listings-item-top-section div.wdt-listings-featured-item-container a:before, .wdt-listings-item-wrapper.type8 .wdt-listings-item-top-section .wdt-listings-featured-item-container a, .wdt-listings-item-wrapper.type7 .wdt-listings-item-top-section .wdt-listings-item-ad-section span:before, table.wdt-user-claimed-posts-table thead tr th, .wdt-dashbord-load-favourite-listings-content table th, .wdt-dashbord-inbox-listing-conversation-wrapper ul.wdt-dashbord-inbox-conversation-list li a.wdt-dashbord-inbox-conversation-reply-loader, .wdt-dashbord-inbox-listing-conversation-wrapper ul.wdt-dashbord-inbox-conversation-list li .wdt-dashbord-inbox-conversation-reply-wrapper .wdt-inbox-conversation-reply-submit, .wdt-dashbord-ads-addnew-wrapper ul.wdt-addtocart-purhcase-preview-wrapper li.duration span, .wdt-dashbord-ads-addnew-wrapper ul.wdt-addtocart-purhcase-preview-wrapper li.total-amount span, .wdt-listings-contactform a.wdt-contactform-submit-button, .wdt-listings-floorplan-top-section .wdt-listings-floorplan-expand-bottom-section, .wdt-listings-author-container[class*=swiper-container-] .wdt-listings-swiper-pagination-holder.type1 .wdt-swiper-bullet-pagination .swiper-pagination-bullet-active, .wdt-listings-item-wrapper.type2 .wdt-listings-item-top-section div.wdt-listings-item-ad-section:after, .wdt-listings-item-wrapper.type2 .wdt-listings-item-top-section div.wdt-listings-item-ad-section:before, .wdt-listings-item-wrapper.type3.wdt-list:hover .wdt-listings-item-top-section div.wdt-listings-item-ad-section:after, .wdt-listings-item-wrapper.type3.wdt-list:hover .wdt-listings-item-top-section div.wdt-listings-featured-item-container:after, .wdt-listing-taxonomy-item.type7:hover .wdt-listing-taxonomy-starting-price:after, .wdt-listings-social-share-container.type2.active .wdt-listings-social-share-item-icon > span, .wdt-listings-social-share-container.type2:hover .wdt-listings-social-share-item-icon > span, .wdt-listings-item-wrapper.type5 .wdt-listings-item-top-section div.wdt-listings-taxonomy-container ul.wdt-listings-taxonomy-list li>a:before, .wdt-sf-pricerange-field-holder .ui-widget.ui-widget-content .ui-widget-header, .wdt-comment-form-fields-holder .comment-form-media span:hover input#wdt_media + label, .wdt-user-list-item.type3 .wdt-user-item-meta-data .wdt-listings-social-share-container.active .wdt-listings-social-share-item-icon span, .wdt-user-list-item.type3 .wdt-user-item-meta-data .wdt-listings-social-share-container .wdt-listings-social-share-item-icon:hover span, .wdt-user-list-item.type3 .wdt-user-item-meta-data .wdt-listings-utils-favourite .wdt-listings-utils-favourite-author:hover span, .wdt-listings-nearby-places-container .wdt-listings-nearby-places-item .wdt-listings-nearby-places-image .wdt-listings-nearby-places-icon, form.lidd_mc_form .lidd_mc_input input[type="submit"], .comment-form .wdt-comment-form-fields-holder p.form-submit input[type="submit"], .logged-in .wdt-listings-comment-list-holder p.form-submit input[type="submit"], #loginform .login-submit input[type="submit"], .wdt-listings-features-box-container.type1 .wdt-listings-features-box-item .wdt-listings-features-box-item-title:first-child:before, .wdt-announcement-listing-holder.contactus span, .wdt-listings-claim-wrapper .wdt-listings-claim-item, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-details .wdt-mylisting-options-container>a[data-tooltip]:before, .wdt-sf-fields-holder .ui-widget-content .ui-widget-header, .wdt-listings-post-dates-container.type2 .wdt-listings-post-date-container span, .wdt-listings-attachment-holder.type2 .wdt-listings-attachment-box-item span, .wdt-listings-dates-container.type3 [class*="date-container"] span, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-date-container:hover>span, .wdt-dashbord-ads-listing table.wdt-custom-table tbody tr td:last-child>*, .wdt-announcement-listing-holder.announcement h2:after, .wdt-announcement-listing-holder.announcement a,  .wdt-listings-item-wrapper.type8 .wdt-listings-item-bottom-section ul.wdt-listings-taxonomy-list li a { background-color:#1e306e}.wdt-listings-sociallinks-container.type1 .wdt-listings-sociallinks-list li a, .wdt-listings-sociallinks-container.type2 .wdt-listings-sociallinks-list li a, .wdt-listings-sociallinks-container.type3 .wdt-listings-sociallinks-list li a, .wdt-listings-sociallinks-container.type7 .wdt-listings-sociallinks-list li a, .wdt-listings-sociallinks-container.type4 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type5 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type6 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type8 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-average-rating-container.type2 .wdt-listings-average-rating-holder, .wdt-listings-average-rating-container.type2 .wdt-listings-average-rating-overall, .wdt-listings-average-rating-container.type2 .wdt-listings-average-rating-reviews-count, .wdt-listings-average-rating-container.type3 .wdt-listings-average-rating-overall, .wdt-listings-mls-number-container span, .wdt-listings-mls-number-container.type3 > span:before, .wdt-listings-featured-item-container.type2 > span, .wdt-listings-featured-item-container.type3 > span:before, .wdt-listings-price-container.type1 .wdt-listings-price-label-holder ins:before, .wdt-listings-price-container.type1 .wdt-listings-price-label-holder del:before, .wdt-listings-price-container.type3 .wdt-price-currency-symbol, .wdt-listings-price-container.type3 .wdt-listings-price-label-holder .wdt-listings-price-item, .wdt-listings-dates-container.type4 .wdt-listings-post-date-container, .wdt-listings-dates-container.type5 .wdt-listings-post-date-container a:hover, .wdt-listings-contactdetails-request-container.type1 > a, .wdt-listings-contactdetails-request-container.type2 > a:hover, .wdt-listings-address-directions, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-date-container:hover span:before, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-contactdetails-list li:hover span, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-utils-favourite-item:hover span, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-utils-pageview-item:hover span, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-utils-print-item:hover span, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-social-share-item-icon:hover span, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-social-share-container.active .wdt-listings-social-share-item-icon span, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-average-rating-container:hover .wdt-listings-average-rating-overall span, .wdt-listings-utils-container .wdt-listings-utils-item .wdt-listings-featured-item-container:hover span:before, .wdt-listings-utils-container .wdt-listings-taxonomy-container .wdt-listings-taxonomy-list li:hover a span:before, [class*="wdt-listings-utils-"] .wdt-listings-dates-container [class*="-date-container"]:hover span:before, .wdt-listings-contactdetails-container.type1 .wdt-listings-contactdetails-list > li:hover span, .wdt-announcement-listing-holder.booknow a, .wdt-announcement-listing-holder.booknow:hover span, .wdt-claim-form-container .wdt-listings-claim-form .wdt-claimform-submit-button, .wdt-listings-dates-container.type5 [class*="date-container"], .wdt-listings-countdown-timer-container.type1 .wdt-countdown-wrapper .wdt-countdown-icon-wrapper, .wdt-listings-countdown-timer-container.type1 .wdt-listings-countdown-timer-holder .wdt-listings-countdown-timer-notice, .wdt-listings-attachment-holder.type4 .wdt-listings-attachment-box-item, .wdt-listings-attachment-holder.type5 .wdt-listings-attachment-box-item a:hover, .wdt-listings-image-gallery-container .wdt-swiper-bullet-pagination.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active, .swiper-pagination-progressbar .swiper-pagination-progressbar-fill, .wdt-swiper-scrollbar .swiper-scrollbar-drag, .wdt-listings-image-gallery-container .wdt-listings-swiper-pagination-holder .wdt-swiper-fraction-pagination, .wdt-listings-media-videos-container .wdt-swiper-bullet-pagination.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active, .swiper-pagination-progressbar .swiper-pagination-progressbar-fill, .wdt-swiper-scrollbar .swiper-scrollbar-drag, .wdt-listings-media-videos-container .wdt-listings-swiper-pagination-holder .wdt-swiper-fraction-pagination, .wdt-listings-media-videos-container.swiper-container div[class*="wdt-swiper-arrow-pagination"].type1 a[class*="wdt-swiper-arrow-"]:after, .wdt-sf-others-field-holder div.wdt-sf-others-list div.active, .ui-datepicker th, .single-wdt_packages .wdt-payment-details a.added_to_cart, .wdt-sf-fields-holder .ui-state-default, .wdt-sf-fields-holder .ui-widget-content .ui-state-default, .wdt-listings-taxonomy-container.type3 li a span.wdt-listings-taxonomy-image, .wdt-listings-taxonomy-container.type5 .wdt-listings-taxonomy-list li a:before, .wdt-listings-post-dates-container.type4 .wdt-listings-post-date-container, .wdt-listings-claim-form>.wdt-listings-claim-form-item input#wdt-claimform-verification-file:hover+label { background-color:#1e306e}.wdt-listings-item-wrapper.type2 .wdt-listings-item-bottom-section-content > div.wdt-listings-item-bottom-pricing-holder .custom-button-style:hover, .wdt-listings-item-wrapper.type3 .wdt-listings-item-bottom-section a.custom-button-style:hover, .wdt-packages-item-wrapper.type1 .wdt-packagelist-view-details-button:hover, .wdt-packages-item-wrapper.type1 .wdt-item-status-details .wdt-proceed-button .custom-button-style:hover,  .wdt-packages-item-wrapper.type1 .wdt-item-status-details .wdt-proceed-button .added_to_cart:hover, .wdt-sf-orderby-field-holder ul.wdt-sf-orderby-list li a:hover, .wdt-sf-orderby-field-holder ul.wdt-sf-orderby-list li a.active, .wdt-sf-fields-holder .ui-widget-content .ui-state-default.ui-state-active,
		.wdt-sf-others-field-holder div.wdt-sf-others-list div:hover, .wdt-sf-others-field-holder div.wdt-sf-others-list div.active, .wdt-dashbord-ads-listing table.wdt-custom-table tbody tr td:last-child a:hover, .wdt-sf-fields-holder input[type="text"]~span:not(.wdt-detect-location), form.lidd_mc_form .lidd_mc_input input[type="text"] ~ span:not(#lidd_mc_total_amount-error) { border-color:#1e306e}.wdt-listings-sociallinks-container.type4 .wdt-listings-sociallinks-list li a, .wdt-listings-sociallinks-container.type5 .wdt-listings-sociallinks-list li a, .wdt-listings-sociallinks-container.type6 .wdt-listings-sociallinks-list li a, .wdt-listings-sociallinks-container.type4 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type5 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type6 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type8 .wdt-listings-sociallinks-list li a, .wdt-listings-contactdetails-request-container.type2 > a, .wdt-listings-contactdetails-request-container.type3 > a, .wdt-announcement-listing-holder.booknow, .wdt-announcement-listing-holder.contactus, .wdt-announcement-listing-holder.contactus a, .wdt-announcement-listing-holder.booknow  a, .wdt-claim-form-container .wdt-listings-claim-form textarea:focus, .wdt-listings-dates-container.type4 [class*="date-container"], .wdt-listings-image-gallery-holder .wdt-listings-image-gallery-thumb-container .wdt-listings-image-gallery-thumb .swiper-slide-active:after, .wdt-listings-media-videos-holder .wdt-listings-media-videos-thumb-container .wdt-listings-media-videos-thumb .swiper-slide-active:after, .wdt-listings-media-videos-container.swiper-container div[class*="wdt-swiper-arrow-pagination"].type1 a[class*="wdt-swiper-arrow-"]:last-child:before, .wdt-listings-media-videos-container.swiper-container div[class*="wdt-swiper-arrow-pagination"].type1 a[class*="wdt-swiper-arrow-"]:first-child:before { border-color:#1e306e}.wdt-packages-item-wrapper.type2 .wdt-item-status-details .custom-button-style, .wdt-packages-item-wrapper.type2 .wdt-item-status-details .added_to_cart, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .custom-button-style, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .added_to_cart, .wdt-packages-item-wrapper.type3 .wdt-packagelist-view-details .custom-button-style, .wdt-packages-item-wrapper.type3 .wdt-item-status-details .wdt-purchased,
		.wdt-listings-item-wrapper.type3:not(.wdt-list) .wdt-listings-item-top-section div.wdt-listings-item-ad-section:before { box-shadow: inset 0 0 0 2px #1e306e }input[type="submit"], button, input[type="button"], input[type="reset"] { background-color:#1e306e}input[type="text"]:focus, input[type="text"]:active, input[type="password"]:focus, input[type="password"]:active, input[type="email"]:focus, input[type="email"]:active, input[type="url"]:focus, input[type="url"]:active, input[type="tel"]:focus, input[type="tel"]:active, input[type="number"]:focus, input[type="number"]:active, input[type="range"]:focus, input[type="range"]:active, input[type="date"]:focus, input[type="date"]:active, textarea:focus, textarea:active, input.text:focus, input.text:active, input[type="search"]:focus, input[type="search"]:active { border-color:#1e306e}.wdt-dashbord-container .wdt-my-listings-container .wdt-listing-dashboard-status:after, .wdt-dashbord-container .wdt-packages-container .wdt-packages-item-wrapper .wdt-packagelist-details .wdt-item-status-details .wdt-purchased:after, .wdt-dashbord-container .wdt-packages-container .wdt-packages-item-wrapper .wdt-packagelist-details .wdt-item-status-details .wdt-active:after, .wdt-listings-item-wrapper:hover .wdt-listings-item-bottom-section-content>div .wdt-listings-price-container .wdt-listings-price-label-holder ins, ul.wdt-dashboard-menus li a:hover, ul.wdt-dashboard-menus li a.wdt-active, .wdt-packages-item-wrapper .wdt-item-status-details .wdt-purchased:after, .wdt-listings-item-wrapper.type3 .wdt-listings-item-bottom-section-content > div .wdt-listings-price-container .wdt-listings-price-label-holder ins, .wdt-listings-item-wrapper.type5 .wdt-listings-item-bottom-section a.custom-button-style:hover, .wdt-custom-login li a:hover, .wdt-listing-taxonomy-item .wdt-listing-taxonomy-meta-data h3 a:hover, .wdt-listings-comment-list-holder .commentlist li.comment .comment-body .reply a.comment-reply-link:hover, .wdt-packages-item-wrapper .wdt-packagelist-details > h5 a:hover, .wdt-listings-item-wrapper .wdt-listings-item-bottom-section-content .wdt-listings-item-title a, .wdt-listings-item-wrapper.type7 .wdt-listings-item-bottom-section .wdt-listings-item-title a:hover, .wdt-user-list-item .wdt-user-item-meta-data h4 a:hover, .wdt-user-list-item.type2 .wdt-user-contactdetails-list li a:hover, .wdt-user-list-item.type3 .wdt-user-sociallinks-list li a:hover, .wdt-user-list-item.type3 .wdt-user-contactdetails-list li a:hover, .wdt-listings-item-wrapper.type3 .wdt-listings-taxonomy-container li a:hover, .wdt-listings-taxonomy-container.type3 li a:hover, .wdt-listings-contactdetails-container.type2 .wdt-listings-contactdetails-list > li a:hover, p.tpl-forget-pwd a:hover, .wdt-listings-item-wrapper.type5 .wdt-listings-item-bottom-section-content > div .wdt-listings-utils-item-holder a:hover, .wdt-listings-item-wrapper.type7 .wdt-listings-item-bottom-section-content .wdt-listings-item-bottom-right-content .wdt-listings-utils-item-holder a:hover, .wdt-listings-item-wrapper.type1.has-post-thumbnail .wdt-listings-item-top-section .wdt-listings-item-top-section-content .wdt-listings-utils-item-holder > div a:hover, .wdt-dashbord-recent-activites-holder .wdt-dashbord-recent-activites-content p a:hover, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-details h5 a:hover, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-dashboard-owner a:hover, .wdt-listings-item-wrapper.type5 .wdt-listings-item-bottom-section-content > div .wdt-listings-utils-item-holder [class*="wdt-listings-utils-"] a.wdt-listings-utils-favourite-item span:hover, .wdt-listings-item-wrapper.type1:not(.has-post-thumbnail) .wdt-listings-item-top-section .wdt-listings-item-top-section-content .wdt-listings-utils-item-holder .wdt-listings-utils-item:first-child>* span:hover, .wdt-listings-item-wrapper.type1:not(.has-post-thumbnail) .wdt-listings-item-top-section .wdt-listings-item-top-section-content .wdt-listings-utils-item-holder > div a:hover, .wdt-listings-item-wrapper.type1.has-post-thumbnail .wdt-listings-item-top-section .wdt-listings-item-top-section-content > div.wdt-listings-utils-item-holder .wdt-listings-utils-item > * > span:hover, div[class*="-apply-isotope"] div[class*="-isotope-filter"] a.active-sort, div[class*="-apply-isotope"] div[class*="-isotope-filter"] a:hover,
		.comment-form .wdt-comment-form-fields-holder>p.comment-form-cookies-consent input[type="checkbox"]:checked~label:before { color:#2fa5fb}ul.wdt-dashboard-menus li a:hover span, ul.wdt-dashboard-menus li a.wdt-active span, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-dashboard-status, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-details .wdt-mylisting-options-container > a:hover, .custom-button-style:hover, .wdt-dashbord-container .wdt-packages-container .wdt-packages-item-wrapper .wdt-packagelist-details .wdt-item-status-details .wdt-purchased, .wdt-dashbord-container .wdt-packages-container .wdt-packages-item-wrapper .wdt-packagelist-details .wdt-item-status-details .wdt-active, .wdt-dashboard-container .woocommerce-button.view:hover, .wdt-dashbord-container .wdt-packages-container .wdt-packages-item-wrapper .wdt-packagelist-details .wdt-item-status-details .wdt-proceed-button a.custom-button-style:hover, .wdt-packages-item-wrapper .wdt-item-status-details .wdt-purchased, .wdt-listings-item-wrapper .wdt-listings-features-box-item>div.wdt-listings-features-box-item-title:first-child:before, .wdt-listings-item-wrapper.type6:hover .wdt-listings-item-bottom-section .wdt-listings-utils-item-holder a.wdt-listings-utils-favourite-item, .wdt-user-list-item.type1 .wdt-user-sociallinks-list li a:hover, div[class*="-output-data-container"] .wdt-swiper-pagination-holder .wdt-swiper-bullet-pagination.swiper-pagination-bullets .swiper-pagination-bullet, .wdt-dashbord-inbox-listing-conversation-wrapper ul.wdt-dashbord-inbox-conversation-list li a.wdt-dashbord-inbox-conversation-reply-loader:hover, .wdt-dashbord-inbox-listing-conversation-wrapper ul.wdt-dashbord-inbox-conversation-list li .wdt-dashbord-inbox-conversation-reply-wrapper .wdt-inbox-conversation-reply-submit:hover, .wdt-listings-contactform a.wdt-contactform-submit-button:hover, .wdt-listings-floorplan-top-section .wdt-listings-floorplan-expand-bottom-section:hover, .wdt-announcement-listing-holder a:hover, .single-wdt_packages .wdt-payment-details a.added_to_cart:hover, form.lidd_mc_form .lidd_mc_input input[type="submit"]:hover, .comment-form .wdt-comment-form-fields-holder p.form-submit input[type="submit"]:hover, .logged-in .wdt-listings-comment-list-holder p.form-submit input[type="submit"]:hover, #loginform .login-submit input[type="submit"]:hover, .wdt-listings-contactdetails-request-container.type2 > a:hover, .wdt-listings-claim-wrapper .wdt-listings-claim-item:hover, .wdt-listings-post-dates-container.type2 .wdt-listings-post-date-container:hover span, .wdt-dashbord-ads-listing table.wdt-custom-table tbody tr td:last-child > a:hover, .wdt-claim-form-container .wdt-listings-claim-form .wdt-claimform-submit-button:hover, .dismissButton:hover:hover, .wdt-announcement-listing-holder.announcement a:hover, .wdt-listings-item-wrapper.type4:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container a:hover { background-color:#2fa5fb}.wdt-listings-sociallinks-container.type1 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type2 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type3 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-sociallinks-container.type7 .wdt-listings-sociallinks-list li a:hover, .wdt-listings-average-rating-container.type3, .wdt-listings-mls-number-container.type3 > span, .wdt-listings-featured-item-container.type3 > span, .wdt-listings-price-container.type2 .wdt-listings-price-label-holder .wdt-listings-price-item, .wdt-listings-dates-container.type4 .wdt-listings-post-date-container:hover, .wdt-listings-contactdetails-request-container > a:hover, .wdt-listings-contactdetails-request-container.type3 > a:hover, .wdt-listings-address-directions:hover, .wdt-listings-contactdetails-container.type2 .wdt-listings-contactdetails-list > li:hover span, .wdt-claim-form-container .wdt-listings-claim-form .wdt-claimform-submit-button:hover, .wdt-listings-dates-container.type3 [class*="date-container"]:hover span, .wdt-listings-dates-container.type4 [class*="date-container"]:hover, .wdt-listings-dates-container.type5 [class*="date-container"]:hover, .wdt-listings-attachment-holder.type2 .wdt-listings-attachment-box-item:hover span, .wdt-listings-attachment-holder.type3 .wdt-listings-attachment-box-item:hover, .wdt-listings-attachment-holder.type4 .wdt-listings-attachment-box-item:hover,.wdt-listings-image-gallery-container .wdt-swiper-bullet-pagination.swiper-pagination-bullets .swiper-pagination-bullet, .wdt-listings-media-videos-container .wdt-swiper-bullet-pagination.swiper-pagination-bullets .swiper-pagination-bullet, .wdt-listings-item-wrapper.type4 .wdt-listings-item-top-section .wdt-listings-item-top-section-content > div.wdt-listings-utils-item-holder .wdt-listings-utils-item > *:hover, .wdt-listings-item-wrapper.type4 .wdt-listings-item-top-section .wdt-listings-item-top-section-content > div:not(.wdt-listings-taxonomy-container) a.wdt-listings-utils-favourite-item:hover span,
		.wdt-listings-item-wrapper.type6:not(.has-post-thumbnail):hover .wdt-listings-item-top-section div.wdt-listings-item-ad-section, .wdt-listings-item-wrapper.type6:not(.has-post-thumbnail):hover .wdt-listings-item-top-section div.wdt-listings-featured-item-container a { background-color:#2fa5fb}.wdt-listings-author-container[class*=swiper-container-] .wdt-listings-author-details-holder:hover, .wdt-announcement-listing-holder.contactus a:hover, .wdt-listings-contactdetails-request-container.type2 > a:hover, .wdt-listings-contactdetails-request-container.type3 > a:hover, .wdt-listings-attachment-holder.type3 .wdt-listings-attachment-box-item:hover, .wdt-listings-dates-container.type4 [class*="date-container"]:hover, .dismissButton:hover:hover, .wdt-listings-features-box-container:not(.listing).type7 .wdt-listings-features-box-item,
		.wdt-listings-post-dates-container.type3 .wdt-listings-post-date-container, .wdt-listings-attachment-holder.type3 .wdt-listings-attachment-box-item { border-color:#2fa5fb}.wdt-listings-item-wrapper.type3:not(.wdt-list):hover .wdt-listings-item-top-section div.wdt-listings-featured-item-container a { box-shadow: inset 0 0 0 0px #2fa5fb }input[type="submit"]:hover, button:hover, input[type="button"]:hover, input[type="reset"]:hover { background-color:#2fa5fb}.wdt-packages-item-wrapper.type2 .wdt-packagelist-view-details .custom-button-style, .wdt-listings-item-wrapper.type6:not(.has-post-thumbnail) .wdt-listings-item-bottom-section .wdt-listings-utils-item-holder, .wdt-listings-item-wrapper.type2 .wdt-listings-item-top-section .wdt-listings-featured-item-container a:before, .wdt-listings-item-wrapper.type5:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container:before, .single-wdt_packages .wdt_packages>img, .wdt-listings-item-wrapper.type1 .wdt-listings-item-top-section .wdt-listings-item-top-section-content .wdt-listings-utils-item-holder>div a:hover, .wdt-listings-item-wrapper.type5:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container a:before, p.login-remember input[type="checkbox"]~label:before,
		.wdt-listings-item-wrapper.type6 .wdt-listings-item-bottom-section .wdt-listings-taxonomy-list li a span { color:#d2edf8}.wdt-packages-item-wrapper h5:before, .wdt-listings-item-wrapper.type1:hover .wdt-listings-item-bottom-section-content .custom-button-style.wdt-listing-view-details, .wdt-listings-item-wrapper.type4 .wdt-listings-item-bottom-section>div.wdt-listings-item-bottom-pricing-holder .custom-button-style, .wdt-listings-item-wrapper.type4 .wdt-listings-item-top-section .wdt-listings-item-top-section-content>div a, .wdt-listings-item-wrapper.type4 .wdt-listings-item-top-section .wdt-listings-item-top-section-content>div.wdt-listings-utils-item-holder .wdt-listings-utils-item>*, .wdt-listings-item-wrapper.type6:not(.has-post-thumbnail):hover .wdt-listings-item-bottom-section .wdt-listings-utils-item-holder a.wdt-listings-utils-favourite-item, .wdt-sf-pricerange-field-holder > div > div[class*="-handle"], .wdt-sf-features-field-holder > div > div[class*="-handle"], .wdt-sf-features-field-holder .ui-widget.ui-widget-content .ui-widget-header, .wdt-swiper-arrow-pagination a:hover, .wdt-marker-addition-info.wdt-marker-addition-info-totalviews, .wdt-marker-addition-info.wdt-marker-addition-info-averageratings, .wdt-marker-addition-info.wdt-marker-addition-info-startdate, .wdt-marker-addition-info.wdt-marker-addition-info-distance, .wdt-listing-taxonomy-item.type7 .wdt-listing-taxonomy-starting-price:after, .wdt-listings-item-wrapper:hover .wdt-listings-item-top-section .wdt-listings-item-ad-section, .wdt-listings-item-wrapper:hover .wdt-listings-item-top-section .wdt-listings-featured-item-container a, .wdt-listings-item-wrapper.type7 .wdt-listings-item-top-section .wdt-listings-item-ad-section, .wdt-listings-item-wrapper.type7 .wdt-listings-item-top-section .wdt-listings-featured-item-container, .wdt-listings-item-wrapper.type3 .wdt-listings-item-top-section div.wdt-listings-item-ad-section:after, .wdt-listings-item-wrapper.type3 .wdt-listings-item-top-section div.wdt-listings-featured-item-container a:after, .wdt-listings-item-wrapper.type3:hover .wdt-listings-item-top-section div.wdt-listings-item-ad-section:before, .wdt-listings-item-wrapper.type3:hover .wdt-listings-item-top-section div.wdt-listings-featured-item-container a:before, .wdt-listings-floorplan-top-section, .wdt-listings-contactdetails-request-container.type3 > a, .wdt-listings-contactdetails-container.type2 .wdt-listings-contactdetails-list > li span, .wdt-announcement-listing-holder.contactus:hover, .wdt-listings-dates-container.type4 [class*="date-container"], .wdt-listings-countdown-timer-container.type2 .wdt-listings-countdown-timer-holder .wdt-listings-countdown-timer-notice span, .wdt-listings-attachment-holder.type2 .wdt-listings-attachment-box-item:hover span, .wdt-listings-image-gallery-container .wdt-listings-swiper-pagination-holder .wdt-swiper-progress-pagination, .wdt-listings-image-gallery-container .wdt-listings-swiper-pagination-holder .wdt-swiper-scrollbar, .wdt-listings-media-videos-container .wdt-listings-swiper-pagination-holder .wdt-swiper-progress-pagination, .wdt-listings-media-videos-container .wdt-listings-swiper-pagination-holder .wdt-swiper-scrollbar, .wdt-packages-item-wrapper:before, .single-wdt_packages .wdt-packagelist-items h3:before, .single-wdt_packages .wdt-payment-details .wdt-item-status-details>span, .wdt-listings-item-wrapper.type2:hover .wdt-listings-item-top-section div.wdt-listings-item-ad-section:after, .wdt-listings-item-wrapper.type2:hover .wdt-listings-item-top-section div.wdt-listings-item-ad-section:before, .wdt-sf-fields-holder.wdt-sf-pricerange-field-holder .ui-widget.ui-widget-content, .wdt-listing-taxonomy-item.type6 .wdt-category-total-items a:hover, .wdt-comment-form-fields-holder input#wdt_media+label, .wdt-user-list-item.type3 .wdt-user-contactdetails-list li:hover span, .wdt-user-list-item.type3 .wdt-user-item-meta-data .wdt-listings-social-share-container.active .wdt-listings-social-share-list, .wdt-listings-features-box-container.type5 .wdt-listings-features-box-item, .wdt-announcement-listing-holder, .wdt-listings-item-wrapper.type4 .wdt-listings-item-top-section .wdt-listings-item-top-section-content > div:not(.wdt-listings-taxonomy-container) a.wdt-listings-utils-favourite-item span, .wdt-listings-item-wrapper.type6 .wdt-listings-item-bottom-section .wdt-listings-utils-item-holder a.wdt-listings-utils-favourite-item span:hover, .wdt-sf-fields-holder .ui-widget.ui-widget-content, .wdt-dashbord-section-holder-content ul.wdt-dashbord-inbox-listing-messages-wrapper li.active, .wdt-dashbord-section-holder-content ul.wdt-dashbord-inbox-listing-messages-wrapper li:hover, .wdt-listings-business-hours-container .wdt-listings-business-hours-currenttime, .wdt-listings-claim-form > .wdt-listings-claim-form-item input#wdt-claimform-verification-file + label { background-color:#d2edf8}.wdt-listings-item-wrapper, .wdt-listings-item-wrapper.type1 .wdt-listings-item-bottom-section-content > div.wdt-listings-item-bottom-right-content, .wdt-packages-item-wrapper, .wdt-listings-item-wrapper.type4 .wdt-listings-item-bottom-section .wdt-listings-item-bottom-section-content .wdt-listings-item-title, .wdt-packages-item-wrapper.type1 .wdt-packagelist-view-details-button, .wdt-packages-item-wrapper.type1 .wdt-item-status-details .wdt-proceed-button .custom-button-style, .wdt-packages-item-wrapper.type2>ul.wdt-packagelist-features, .wdt-packages-item-wrapper.type3 .wdt-packagelist-details,  .wdt-packages-item-wrapper.type1 .wdt-item-status-details .wdt-proceed-button .added_to_cart, .wdt-listings-item-wrapper.type4 .wdt-listings-features-box-container>div:not(:last-child), .wdt-listings-item-wrapper.type5 .wdt-listings-item-bottom-section-content > div .wdt-listings-utils-item .wdt-listings-utils-totalimages-item a, .wdt-listings-item-wrapper.type7 .wdt-listings-item-bottom-section-content .wdt-listings-item-bottom-right-content .wdt-listings-utils-item-holder .wdt-listings-utils-item .wdt-listings-utils-totalimages-item a, .wdt-listing-taxonomy-item.type4, .wdt-user-list-item.type3, .wdt-user-list-item.type3 .wdt-user-contactdetails-list li span, .wdt-swiper-arrow-pagination a, .wdt-marker-info-box .wdt-listings-map-item-wrapper.type3 .wdt-listings-item-bottom-section .wdt-listings-item-title, .wdt-listing-taxonomy-item.type4 .wdt-listing-taxonomy-starting-price, .wdt-listings-item-wrapper.type7 .wdt-listings-item-bottom-section-content .wdt-listings-item-bottom-left-content .wdt-listings-post-dates-container, .wdt-dashbord-recent-activites-holder .wdt-dashbord-recent-activites-content p, .wdt-listings-comment-list-holder .comment-body, .comment-form .wdt-comment-form-fields-holder .wdt-ratings-holder, .wdt-marker-info-box .wdt-listings-map-item-wrapper.type3 .wdt-listings-item-bottom-section .wdt-listings-item-title, .wdt-listings-floorplan-box-container .wdt-listings-floorplan-box-item, .wdt-listings-business-hours-container, .wdt-listings-business-hours-container .wdt-listings-business-hours-status, .wdt-listings-business-hours-container .wdt-listings-business-hours-list li, .wdt-listings-dates-container.type1, .wdt-listings-dates-container.type1 > div:not(:last-child), .wdt-listings-dates-container.type1 .wdt-listings-business-hours-list, .wdt-listings-dates-container.type1 .wdt-listings-business-hours-list li, .wdt-listings-image-gallery-thumb-container .wdt-listings-image-gallery-thumb .swiper-slide:hover:after, .wdt-listings-media-videos-thumb-container .wdt-listings-media-videos-thumb .swiper-slide:hover:after, .single-wdt_packages .wdt-payment-details .wdt-item-status-details, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-item-wrapper, .wdt-sf-fields-holder .ui-widget-content .ui-state-default.ui-state-hover, .wdt-listing-taxonomy-item.type6 .wdt-category-total-items a:hover, .wdt-user-list-item.type3 .wdt-user-item-meta-data .wdt-listings-utils-favourite, .wdt-listings-features-box-container.type4 .wdt-listings-features-box-item:not(:last-child), .wdt-listings-features-box-container.type7 .wdt-listings-features-box-item, .wdt-listings-countdown-timer-container.type2 .wdt-listings-countdown-timer-holder .wdt-listings-countdown-timer-notice,  .wdt-announcement-listing-holder.contactus, .wdt-announcement-listing-holder.contactus:hover, .wdt-dashbord-section-holder-content ul.wdt-dashbord-inbox-listing-messages-wrapper li.active, .wdt-dashbord-section-holder-content ul.wdt-dashbord-inbox-listing-messages-wrapper li:hover { border-color:#d2edf8}.wdt-listings-nearby-places-container .wdt-listings-nearby-places-item:not(:last-child), .wdt-listings-author-container .wdt-listings-author-details-holder, .wdt-packages-item-wrapper.type2 .wdt-packagelist-details, #primary.page-with-sidebar .wdt-packages-item-wrapper.type2 .wdt-packagelist-details { border-color:#d2edf8}.wdt-listings-item-wrapper.type1 .wdt-listings-item-bottom-section-content .custom-button-style.wdt-listing-view-details, .wdt-listings-item-wrapper.type2 .wdt-listings-item-bottom-section-content > div.wdt-listings-item-bottom-pricing-holder { border-top-color:#d2edf8}.wdt-packages-item-wrapper:hover, .wdt-packages-item-wrapper.type1:hover .wdt-packagelist-view-details-button, .wdt-packages-item-wrapper.type1:hover .wdt-item-status-details .wdt-proceed-button .custom-button-style, .wdt-user-list-item.type1:hover, .wdt-listings-taxonomy-container.type7 li a:hover, .wdt-listings-author-container .wdt-listings-author-details-holder:hover { box-shadow: 0 15px 30px 0 #d2edf8 }.swiper-wrapper .wdt-listings-item-wrapper:hover { box-shadow: 0 10px 20px 0 #d2edf8 }.comment-form .wdt-comment-form-fields-holder, .wdt-listings-contactform, .logged-in .wdt-listings-comment-list-holder .comment-form, .wdt-listings-nearby-places-container .wdt-listings-nearby-places-item .wdt-listings-nearby-places-image,
		.wdt-yelp-places-container .wdt-yelp-places-item .wdt-yelp-places-image, .wdt-listings-taxonomy-container.type7 li a:hover { box-shadow: 0 0 30px 0 #d2edf8 }
		.wdt-packages-item-container.swiper-wrapper .wdt-packages-item-wrapper:hover, .wdt-packages-item-container.swiper-wrapper .wdt-packages-item-wrapper.type1:hover .wdt-item-status-details .wdt-proceed-button .custom-button-style, .wdt-packages-item-container.swiper-wrapper .wdt-packages-item-wrapper.type1:hover .wdt-packagelist-view-details-button { box-shadow: 0 0 20px 0 #d2edf8 }.wdt-user-list-item.type3 .wdt-user-contactdetails-list li span, .wdt-listings-author-container .wdt-listings-author-details-holder .wdt-listings-author-details .wdt-listings-contactdetails-list li span { box-shadow: inset 0 0 0 2px #d2edf8 }.wdt-listings-media-videos-container.swiper-container div[class*="wdt-swiper-arrow-pagination"].type2 > a[class*="wdt-swiper-arrow"] { background-color:rgba(30,48,110, 0.5)}.wdt-listings-media-videos-container.swiper-container div[class*="wdt-swiper-arrow-pagination"].type2>a[class*="wdt-swiper-arrow"]:hover, .wdt-listings-image-gallery-container.swiper-container div[class*="wdt-swiper-arrow-pagination"].type2>a[class*="wdt-swiper-arrow"]:hover { background-color:rgba(30,48,110, 0.6)}.wdt-listings-image-gallery-container.swiper-container div[class*="wdt-swiper-arrow-pagination"].type2>a[class*="wdt-swiper-arrow"] { background-color:rgba(30,48,110, 0.15)}.wdt-listings-item-wrapper.type6.has-post-thumbnail .wdt-listings-item-top-section .wdt-listings-feature-image-holder:before,
		.wdt-listings-item-wrapper.type6.has-post-thumbnail .wdt-listings-item-top-section .wdt-listings-image-gallery .swiper-slide:before {
		background-color:rgba(30,48,110, 0.8)}.lidd_mc_details .lidd_mc_summary p:not(:last-child), .lidd_mc_details .lidd_mc_results p, .wdt-listing-taxonomy-item.type4:hover, .wdt-listing-taxonomy-item.type4:hover .wdt-listing-taxonomy-starting-price, .wdt-user-list-item.type2 .wdt-user-image img, .wdt-dashbord-section-holder-content ul.wdt-dashbord-inbox-listing-messages-wrapper li:hover span, .wdt-dashbord-section-holder-content ul.wdt-dashbord-inbox-listing-messages-wrapper li.active span { border-color:rgba(47,165,251, 0.2)}.wdt-listings-features-box-container:not(.listing).type7 .wdt-listings-features-box-item,
		.wdt-listings-post-dates-container.type3 .wdt-listings-post-date-container, .wdt-listings-attachment-holder.type3 .wdt-listings-attachment-box-item {
		background-color:rgba(47,165,251, 0.3)}.wdt-dashbord-container .wdt-packages-container .wdt-packages-item-wrapper:hover, .wdt-dashbord-container .wdt-my-listings-container .wdt-listing-item-wrapper:hover { background-color:rgba(210,237,248, 0.135)}.lidd_mc_details, .wdt-listing-taxonomy-item.type4:hover, .wdt-listings-nearby-places-container:hover .wdt-listings-nearby-places-item .wdt-listings-nearby-places-image { background-color:rgba(210,237,248, 0.5)}
</style>
<link rel="stylesheet" id="flatpickr-css" href="./Services – RTL GrassRoot Site_files/flatpickr.min.css" type="text/css" media="all">
<link rel="stylesheet" id="a971fbc1c37daacff709eb88c7fe0bfb-css" href="./Services – RTL GrassRoot Site_files/css" type="text/css" media="all">
<link rel="stylesheet" id="4de3aa1138d41cb03c7d9d3ddd37d9a4-css" href="./Services – RTL GrassRoot Site_files/css(1)" type="text/css" media="all">
<link rel="stylesheet" id="2f61ea5a7b8f2619662f755b6ea6047a-css" href="./Services – RTL GrassRoot Site_files/css(2)" type="text/css" media="all">
<link rel="stylesheet" id="13903dec3b9eaf7f110822ba2399eb72-css" href="./Services – RTL GrassRoot Site_files/css(3)" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-css" href="./Services – RTL GrassRoot Site_files/style.css" type="text/css" media="all">
<style id="grassroot-inline-css" type="text/css">
:root {--wdtPrimaryColor:#d9ef82;--wdtPrimaryColorRgb:217,239,130;--wdtSecondaryColor:#161616;--wdtSecondaryColorRgb:22,22,22;--wdtTertiaryColor:#365140;--wdtTertiaryColorRgb:54,81,64;--wdtQuaternaryColor: #F9F9F9;--wdtQuaternaryColorRgb: 249,249,249;--wdtBodyBGColor:#fffaf6;--wdtBodyBGColorRgb:255,250,246;--wdtBodyTxtColor:#161616;--wdtBodyTxtColorRgb:22,22,22;--wdtHeadAltColor:#161616;--wdtHeadAltColorRgb:22,22,22;--wdtLinkColor:#161616;--wdtLinkColorRgb:22,22,22;--wdtLinkHoverColor:#d9ef82;--wdtLinkHoverColorRgb:217,239,130;--wdtBorderColor:#e6e6e6;--wdtBorderColorRgb:230,230,230;--wdtAccentTxtColor:#FFFFFF;--wdtAccentTxtColorRgb:255,255,255;--wdtFontTypo_Base: 'Plus Jakarta Sans', sans-serif;--wdtFontWeight_Base: 400;--wdtFontSize_Base: 16px;--wdtLineHeight_Base: 1.625;--wdtFontTypo_Alt: 'Fraunces', serif;--wdtFontWeight_Alt: 600;--wdtFontSize_Alt: 70px;--wdtLineHeight_Alt: 1.27;--wdtFontTypo_H1: 'Fraunces', serif;--wdtFontWeight_H1: 600;--wdtFontSize_H1: 70px;--wdtLineHeight_H1: 1.27;--wdtFontTypo_H2: 'Fraunces', serif;--wdtFontWeight_H2: 600;--wdtFontSize_H2: 55px;--wdtLineHeight_H2: 1.27;--wdtFontTypo_H3: 'Fraunces', serif;--wdtFontWeight_H3: 600;--wdtFontSize_H3: 40px;--wdtLineHeight_H3: 1.27;--wdtFontTypo_H4: 'Fraunces', serif;--wdtFontWeight_H4: 600;--wdtFontSize_H4: 26px;--wdtLineHeight_H4: 1.27;--wdtFontTypo_H5: 'Fraunces', serif;--wdtFontWeight_H5: 600;--wdtFontSize_H5: 22px;--wdtLineHeight_H5: 1.27;--wdtFontTypo_H6: 'Fraunces', serif;--wdtFontWeight_H6: 600;--wdtFontSize_H6: 18px;--wdtLineHeight_H6: 1.27;--wdtFontTypo_Ext: "Plus Jakarta Sans", sans-serif;--wdtFontWeight_Ext: 500;--wdtFontSize_Ext: 14px;--wdtLineHeight_Ext: 1.1;}
</style>
<link rel="stylesheet" id="grassroot-icons-css" href="./Services – RTL GrassRoot Site_files/icons.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-base-css" href="./Services – RTL GrassRoot Site_files/base(1).css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-grid-css" href="./Services – RTL GrassRoot Site_files/grid.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-layout-css" href="./Services – RTL GrassRoot Site_files/layout.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-additional-css" href="./Services – RTL GrassRoot Site_files/additional.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-widget-css" href="./Services – RTL GrassRoot Site_files/widget(1).css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-rtl-css" href="./Services – RTL GrassRoot Site_files/rtl(1).css" type="text/css" media="all">
<link rel="stylesheet" id="site-breadcrumb-css" href="./Services – RTL GrassRoot Site_files/breadcrumb.css" type="text/css" media="all">
<link rel="stylesheet" id="site-header-css" href="./Services – RTL GrassRoot Site_files/header.css" type="text/css" media="all">
<link rel="stylesheet" id="site-loader-css" href="./Services – RTL GrassRoot Site_files/loader-1.css" type="text/css" media="all">
<link rel="stylesheet" id="site-to-top-css" href="./Services – RTL GrassRoot Site_files/totop.css" type="text/css" media="all">
<link rel="stylesheet" id="site-sidebar-css" href="./Services – RTL GrassRoot Site_files/sidebar.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-blog-css" href="./Services – RTL GrassRoot Site_files/blog.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-blog-archive-minimal-css" href="./Services – RTL GrassRoot Site_files/blog-archive-minimal.css" type="text/css" media="all">
<link rel="stylesheet" id="jquery-bxslider-css" href="./Services – RTL GrassRoot Site_files/jquery.bxslider.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-breadcrumb-css" href="./Services – RTL GrassRoot Site_files/breadcrumb(1).css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-comments-css" href="./Services – RTL GrassRoot Site_files/comments.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-footer-css" href="./Services – RTL GrassRoot Site_files/footer.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-header-css" href="./Services – RTL GrassRoot Site_files/header(1).css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-pagination-css" href="./Services – RTL GrassRoot Site_files/pagination.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-magnific-popup-css" href="./Services – RTL GrassRoot Site_files/magnific-popup.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-quick-search-css" href="./Services – RTL GrassRoot Site_files/search.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-secondary-css" href="./Services – RTL GrassRoot Site_files/sidebar(1).css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-woo-css" href="./Services – RTL GrassRoot Site_files/default.css" type="text/css" media="all">
<style id="grassroot-woo-cart-notification-inline-css" type="text/css">

/*--------------------------------------------------------------*/
    /* #region - Add-to-Cart Notification Widget */
/*--------------------------------------------------------------*/

    .wdt-shop-cart-widget.cart-notification-widget, .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-inner,
    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content { float: left; width: 100%; }

    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-close-button { font-size: 0; height: 25px; line-height: 0; position: absolute; right: 3px; top: 3px; text-align: center; width: 25px; -webkit-border-radius: 50%; border-radius: 50%; }

    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-close-button:before { content: "\2716"; display: block; font-size: 14px; font-weight: normal; line-height: 25px; }

    .wdt-shop-cart-widget.cart-notification-widget { max-width: 500px; position: fixed; bottom: 32px; left: 18px; width: auto; z-index: 999; -webkit-transition: var(--wdtBaseTransition); transition: var(--wdtBaseTransition); }

    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-inner { padding: 20px; }
    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content > * { display: table-cell; vertical-align: middle; }
    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content-thumb { line-height: 0; padding: 0 10px; width: 120px; }
    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content-info { padding: 5px 10px; text-align: left; }

    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content-thumb a,
    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content-thumb a img { display: block; width: 100%; }

    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content-info a { display: block; font-size: 18px; font-weight: bold; }

    .wdt-shop-cart-widget.cart-notification-widget { opacity: 0; visibility: hidden; }
    .wdt-shop-cart-widget.cart-notification-widget.wdt-shop-cart-widget-active { opacity: 1; visibility: visible; }


    .wdt-shop-cart-widget.cart-notification-widget { background-color: var(--wdtBodyBGColor); }

    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-close-button:before { color: var(--wdtAccentTxtColor); }

    .wdt-shop-cart-widget.cart-notification-widget { -webkit-box-shadow: 0 1px 3px 1px rgba(var(--wdtHeadAltColorRgb),0.25); box-shadow: 0 1px 3px 1px rgba(var(--wdtHeadAltColorRgb),0.25); }

/* #endregion - Add-to-Cart Notification Widget */



/*--------------------------------------------------------------*/
    /* #region - Add-to-Cart Sidebar Widget */
/*--------------------------------------------------------------*/

    .wdt-shop-cart-widget.activate-sidebar-widget { height: 100%; position: fixed; right: 0; top: 0; width: 350px; z-index: 999992; -webkit-transform: translateX(100%); transform: translateX(100%); -webkit-transition: var(--wdtBaseTransition); transition: var(--wdtBaseTransition); }

    .wdt-shop-cart-widget.activate-sidebar-widget:before { content: ""; }

    .wdt-shop-cart-widget.activate-sidebar-widget.wdt-shop-cart-widget-active { -webkit-transform: translateX(0); transform: translateX(0); }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-inner { height: 100%; padding: 45px 0 120px; position: relative; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header { border-width: 0 0 1px; padding-left: 15px; padding-right: 45px; position: absolute; left: 0; top: 0; width: 100%; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 { font-size: 15px; font-weight: bold; line-height: 45px; margin: 0; text-transform: uppercase; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 span, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header a { height: 45px; position: absolute; top: 0; text-align: center; width: 45px; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 span { font-size: 18px; right: 0; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 a { font-size: 0; line-height: 0; margin-right: 1px; overflow: hidden; right: 100%; text-indent: -9999px; -webkit-transform: translateX(100%); transform: translateX(100%); }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 a:before { content: "\2716"; display: block; font-size: 15px; font-weight: normal; line-height: 45px; text-indent: 0; }

    .wdt-shop-cart-widget[class*="sidebar"].activate-sidebar-widget:hover .wdt-shop-cart-widget-header h3 a { -webkit-transform: translateX(0); transform: translateX(0); }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content { float: left; width: 100%; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-inner,
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget,
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li { float: left; width: 100%; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget,
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .total { padding: 0 15px; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li { border-width: 1px 0; display: inline; margin: -1px 0 0 !important; padding: 15px 25px 15px 50px; position: relative; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li:first-child { border-top-width: 0; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li:last-child { border-bottom-width: 0; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a:not(.remove) { font-weight: 600; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a img { margin: auto; position: absolute; left: 0; top: 16px; width: 40px; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a.remove { font-size: 16px; height: 20px; line-height: 20px; margin: auto; position: absolute; bottom: 0; left: auto; right: 0; top: 0 !important; text-align: center; width: 20px; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a.remove:not(:focus) { text-decoration: none; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li:before { content: none !important; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li .quantity { display: table; margin: 0; font-size: 14px; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer { position: absolute; bottom: 0; left: 0; width: 100%; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer::before { content: ""; height: 1px; position: absolute; left: 0; right: 0; top: 0; width: auto; z-index: -1; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p { height: 50px; line-height: 50px; margin: 0; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.total { padding: 0 15px; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.total strong { float: left; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.total .amount { float: right; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.buttons { display: flex; grid-gap: 1px; }
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.buttons a { height: 100%; line-height: inherit; margin: 0; padding-top: 0; padding-bottom: 0; text-align: center; width: 50%; -webkit-border-radius: 0; border-radius: 0; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart__empty-message { margin: 0; padding: 15px; }

    .wdt-shop-cart-widget-overlay { background-color: rgba(var(--wdtHeadAltColorRgb),0.7); height: 100%; position: fixed; top: 0; left: 0; width: 100%; z-index: 999991; -webkit-transition: opacity .25s ease, visibility 0s ease .25s; transition: opacity .25s ease, visibility 0s ease .25s; }


    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header a, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li { border-style: solid;  }


    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 a, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a.remove, .wdt-shop-cart-widget-overlay { opacity: 0; visibility: hidden; }

    .wdt-shop-cart-widget[class*="sidebar"].activate-sidebar-widget:hover .wdt-shop-cart-widget-header h3 a,
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li:hover a.remove,
    .wdt-shop-cart-widget.activate-sidebar-widget.wdt-shop-cart-widget-active + .wdt-shop-cart-widget-overlay { opacity: 1; visibility: visible; }


    /* Default Color - Colors */
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a:not(.remove):not(:hover),
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.total .amount { color: var(--wdtHeadAltColor); }


    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 a, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 a:hover { color: var(--wdtAccentTxtColor); }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a.remove { color: var(--wdtAccentTxtColor) !important; }


    /* Default Color - Borders */
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer::before { -webkit-box-shadow: 0 2px 6px 0 rgba(var(--wdtHeadAltColorRgb),0.5); box-shadow: 0 2px 6px 0 rgba(var(--wdtHeadAltColorRgb),0.5); }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header a, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li { border-color: rgba(var(--wdtHeadAltColorRgb),0.075); }


    /* Default Color - BG */
    .wdt-shop-cart-widget.activate-sidebar-widget { background-color: #f7f7f7; }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer { background-color: var(--wdtBodyBGColor); }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.buttons a.checkout, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a.remove,

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.buttons a:not(.checkout),

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 a, .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .woocommerce-mini-cart-footer p.buttons a:hover, .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-close-button { background-color: var(--wdtHeadAltColor); }

    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 span { background-color: rgba(var(--wdtBodyBGColorRgb),0.15); }

    .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-close-button:hover,
    .wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-content .product_list_widget li a.remove:hover { background-color: #9f2124; }


    /* #endregion - Add-to-Cart Sidebar Widget */


/*--------------------------------------------------------------*/
    /* #region - Responsive */
/*--------------------------------------------------------------*/

    /*----*****---- << Mobile (Landscape) >> ----*****----*/

    /* Common Styles for the devices below 767px width */
    @media only screen and (max-width: 767px) {

        .wdt-shop-cart-widget.cart-notification-widget { margin: auto; bottom: 5px; left: 0; right: 0; }

    }


    /* Note: Design for a width of 480px */
    @media only screen and (min-width: 480px) and (max-width: 767px) {

        .wdt-shop-cart-widget.cart-notification-widget { max-width: 420px; }

    }

    /* Common Styles for the devices below 479px width */
    @media only screen and (max-width: 479px) {

        .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content > * { display: table; margin: auto; text-align: center !important; }

        .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content-info { font-size: 11px; }
        .wdt-shop-cart-widget.cart-notification-widget .wdt-shop-cart-widget-content-info a { font-size: 13px; }


		.wdt-shop-cart-widget[class*="sidebar"] .wdt-shop-cart-widget-header h3 a { right: 0; -webkit-border-radius: 50%; border-radius: 50%; -webkit-transform: scale(0); transform: scale(0); }

		.wdt-shop-cart-widget[class*="sidebar"].activate-sidebar-widget:hover .wdt-shop-cart-widget-header h3 a { -webkit-border-radius: 0; border-radius: 0; -webkit-transform: scale(1); transform: scale(1); }

    }

    /*----*****---- << Mobile >> ----*****----*/

    /* Mobile Portrait Size to Mobile Landscape Size (devices and browsers) */
    @media only screen and (min-width: 320px) and (max-width: 479px) {

        .wdt-shop-cart-widget.cart-notification-widget { max-width: 290px; }


		.wdt-shop-cart-widget.activate-sidebar-widget { max-width: 290px; }
		.wdt-shop-cart-widget.activate-sidebar-widget { width: 290px; }

    }


/* #endregion - Responsive */

</style>
<link rel="stylesheet" id="grassroot-plus-blog-css" href="./Services – RTL GrassRoot Site_files/blog(1).css" type="text/css" media="all">
<link rel="stylesheet" id="dtplugin-nav-menu-animations-css" href="./Services – RTL GrassRoot Site_files/nav-menu-animations.css" type="text/css" media="all">
<link rel="stylesheet" id="dtplugin-nav-menu-css" href="./Services – RTL GrassRoot Site_files/nav-menu.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-pro-advance-field-css" href="./Services – RTL GrassRoot Site_files/style(1).css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-pro-blog-css" href="./Services – RTL GrassRoot Site_files/blog(2).css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-pro-post-navigation-css" href="./Services – RTL GrassRoot Site_files/post-navigation.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-pro-auth-css" href="./Services – RTL GrassRoot Site_files/style(2).css" type="text/css" media="all">
<link rel="stylesheet" id="jquery-select2-css" href="./Services – RTL GrassRoot Site_files/select2.css" type="text/css" media="all">
<link rel="stylesheet" id="grassroot-theme-css" href="./Services – RTL GrassRoot Site_files/theme.css" type="text/css" media="all">
<style id="grassroot-admin-inline-css" type="text/css">
.loader1 { background-color:var( --wdtBodyBGColor );}body { font-family: 'Plus Jakarta Sans', sans-serif;font-weight:400;font-size:16px;line-height:1.625;color:#161616; }
a { color:#161616;}
a:hover { color:#d9ef82;}
h1 { font-family: 'Fraunces', serif;font-weight:600;font-size:70px;line-height:1.27; }
h2 { font-family: 'Fraunces', serif;font-weight:600;font-size:55px;line-height:1.27; }
h3 { font-family: 'Fraunces', serif;font-weight:600;font-size:40px;line-height:1.27; }
h4 { font-family: 'Fraunces', serif;font-weight:600;font-size:26px;line-height:1.27; }
h5 { font-family: 'Fraunces', serif;font-weight:600;font-size:22px;line-height:1.27; }
h6 { font-family: 'Fraunces', serif;font-weight:600;font-size:18px;line-height:1.27; }
.main-title-section-wrapper.overlay-wrapper.dark-bg-breadcrumb > .main-title-section-bg, .main-title-section-wrapper.overlay-wrapper > .main-title-section-bg, .main-title-section-wrapper.dark-bg-breadcrumb > .main-title-section-bg, .main-title-section-wrapper > .main-title-section-bg { background-image: url("https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/05/Breadcrumb-new.jpg");background-attachment:inherit;background-position:center center;background-size:cover;background-repeat:repeat;background-color:var(--wdtTertiaryColor); }

</style>
<link rel="stylesheet" id="elementor-gf-local-fraunces-css" href="./Services – RTL GrassRoot Site_files/fraunces.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-gf-local-plusjakartasans-css" href="./Services – RTL GrassRoot Site_files/plusjakartasans.css" type="text/css" media="all">
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.min.js.download" id="jquery-core-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery-migrate.min.js.download" id="jquery-migrate-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.blockUI.min.js.download" id="jquery-blockui-js" data-wp-strategy="defer"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/rtl-demo\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/rtl-demo\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/add-to-cart.min.js.download" id="wc-add-to-cart-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/js.cookie.min.js.download" id="js-cookie-js" data-wp-strategy="defer"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/rtl-demo\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/rtl-demo\/?wc-ajax=%%endpoint%%","i18n_password_show":"Show password","i18n_password_hide":"Hide password"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/woocommerce.min.js.download" id="woocommerce-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/v4-shims.min.js.download" id="font-awesome-4-shim-js"></script>
<link rel="https://api.w.org/" href="https://wdtgrassroot.wpengine.com/rtl-demo/wp-json/"><link rel="alternate" title="JSON" type="application/json" href="https://wdtgrassroot.wpengine.com/rtl-demo/wp-json/wp/v2/pages/2132"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://wdtgrassroot.wpengine.com/rtl-demo/xmlrpc.php?rsd">
<link rel="canonical" href="https://wdtgrassroot.wpengine.com/rtl-demo/services/">
<link rel="shortlink" href="https://wdtgrassroot.wpengine.com/rtl-demo/?p=2132">
<link rel="alternate" title="oEmbed (JSON)" type="application/json+oembed" href="https://wdtgrassroot.wpengine.com/rtl-demo/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwdtgrassroot.wpengine.com%2Frtl-demo%2Fservices%2F">
<link rel="alternate" title="oEmbed (XML)" type="text/xml+oembed" href="https://wdtgrassroot.wpengine.com/rtl-demo/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwdtgrassroot.wpengine.com%2Frtl-demo%2Fservices%2F&amp;format=xml">
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.30.0; features: e_font_icon_svg, additional_custom_breakpoints, e_element_cache; settings: css_print_method-external, google_font-enabled, font_display-swap">
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<style type="text/css" id="custom-background-css">
body.custom-background { background-image: url("https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/02/body-bg-1.png"); background-position: left center; background-size: cover; background-repeat: no-repeat; background-attachment: fixed; }
</style>
	<link rel="icon" href="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Favicon.svg" sizes="32x32">
<link rel="icon" href="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Favicon.svg" sizes="192x192">
<link rel="apple-touch-icon" href="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Favicon.svg">
<meta name="msapplication-TileImage" content="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Favicon.svg">
<script src="./Services – RTL GrassRoot Site_files/wp-emoji-release.min.js.download" defer=""></script></head>

<body class="rtl wp-singular page-template page-template-elementor_header_footer page page-id-2132 page-parent custom-background wp-custom-logo wp-theme-grassroot theme-grassroot has-go-to-top grassroot-plus-1.0.2 grassroot-pro-1.0.0 woocommerce-js tinvwl-theme-style elementor-default elementor-template-full-width elementor-kit-8 elementor-page elementor-page-2132 e--ua-blink e--ua-chrome e--ua-webkit" style="--header-height: 182px;" data-elementor-device-mode="laptop">
    <div class="pre-loader loader1" style="display: none;">
    <div class="loader-inner">
        <div class="load-container">
            <div class="wdt-droplet wdt-droplet1"></div>
            <div class="wdt-droplet wdt-droplet2"></div>
            <div class="wdt-droplet wdt-droplet3"></div>
            <div class="wdt-droplet wdt-droplet4"></div>
            <div class="wdt-droplet wdt-droplet5"></div>
            <div class="wdt-droplet wdt-droplet6"></div>
            <div class="wdt-droplet wdt-droplet7"></div>
            <div class="wdt-droplet wdt-droplet8"></div>
            <div class="wdt-droplet wdt-droplet9"></div>
            <div class="wdt-droplet wdt-droplet10"></div>
        </div>
    </div>
</div>
    <a class="skip-link screen-reader-text" href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#main">Skip to content</a>

    <!-- **Wrapper** -->
    <div class="wrapper">

        <!-- ** Inner Wrapper ** -->
        <div class="inner-wrapper">


            <!-- ** Header Wrapper ** -->
            <div id="header-wrapper" class="wdt-dark-bg header-top-absolute">

                <!-- **Header** -->
                    <header id="header">
    <div class="wdt-elementor-container-fluid"><div id="header-11" class="wdt-header-tpl header-11">		<div data-elementor-type="wp-post" data-elementor-id="11" class="elementor elementor-11">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-a8ca1b8 elementor-section-content-middle elementor-hidden-mobile_extra elementor-hidden-mobile animated-fast elementor-section-boxed elementor-section-height-default elementor-section-height-default animated fadeInDown" data-id="a8ca1b8" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInDown&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-f65aa08 elementor-hidden-tablet elementor-hidden-mobile_extra elementor-hidden-mobile" data-id="f65aa08" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-e1e858b elementor-icon-list--layout-inline elementor-widget__width-auto elementor-align-left elementor-mobile-align-left elementor-list-item-link-inline wdt-header-info-list elementor-tablet_extra-align-right elementor-widget elementor-widget-icon-list" data-id="e1e858b" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<a href="tel:+000-12345-6789">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 120 120" style="enable-background:new 0 0 120 120;" xml:space="preserve"><path d="M115.8,108c4.8-4.8,4.2-12.8-1.4-16.8l-19.1-14c-4.4-3.3-10.6-2.8-14.4,1l-3.3,3.3c-0.4,0.4-0.8,0.7-1.2,1 c-1.6,1.6-3.9,2.1-6,1.3c-16.6-6.3-28-17.8-34.4-34.4c-0.8-2.1-0.3-4.4,1.3-6l0.6-0.6c0.1-0.2,0.3-0.3,0.4-0.5l3.3-3.3 c3.9-3.9,4.3-10,1.1-14.4l-14-19.1c-4-5.5-12-6.2-16.8-1.4L8.6,7.6c-3.9,3.9-6.4,8.8-7.2,14.2c-0.1,0.7-0.2,1.5-0.2,2.2 C0.2,37.2,5,51.2,14.7,66.2c0.3,0.5,0.7,1,1,1.5c9.7,14.5,22.2,26.9,36.6,36.6c0.5,0.3,1,0.6,1.4,0.9c15,9.7,29.1,14.5,42.2,13.6 c0.7,0,1.5-0.1,2.2-0.2c5.4-0.8,10.3-3.4,14.2-7.2L115.8,108L115.8,108z"></path><path d="M119,57.2c-1.1-14.5-7.4-28.2-17.7-38.5C91,8.4,77.3,2.1,62.8,1c-2.2-0.2-4.1,1.5-4.3,3.7 C58.3,6.9,60,8.8,62.2,9c12.6,0.9,24.5,6.4,33.5,15.3c9,9,14.4,20.8,15.3,33.5c0.2,2.1,1.9,3.7,4,3.7c0.1,0,0.2,0,0.3,0 C117.5,61.3,119.2,59.4,119,57.2L119,57.2z"></path><path d="M86.4,36.6C80.1,30.3,72,26.4,63.2,25.2c-2.3-0.3-4.4,1.3-4.6,3.6c-0.3,2.3,1.3,4.4,3.6,4.6 c7,0.9,13.4,4,18.4,9c5,5,8.1,11.4,9,18.4c0.3,2.1,2.1,3.6,4.1,3.6c0.2,0,0.4,0,0.5,0c2.3-0.3,3.9-2.4,3.6-4.6 C96.7,51,92.7,43,86.4,36.6L86.4,36.6z"></path></svg>						</span>
										<span class="elementor-icon-list-text">+000-12345-6789</span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><path d="M48.1,5C29.1,6,14,21.3,14,40c0,7.9,2.7,15.2,7.2,21h0l24.4,31.8c2.2,2.9,6.6,2.9,8.8,0L78.8,61h0 c4.2-5.4,6.8-11.9,7.2-19.1C87.1,21.2,69.4,4,48.1,5z M74,41c0,13.3-10.7,24-24,24S26,54.3,26,41s10.7-24,24-24S74,27.7,74,41z"></path></svg>						</span>
										<span class="elementor-icon-list-text">No: 58 A, East Street, USA 4508</span>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="mailto:info@example.com">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><path d="M39.6,45.8L39.6,45.8C39.7,45.9,39.7,45.9,39.6,45.8L50,55.3L60.2,46l0.4-0.3l29.8-27.2c-0.2,0-0.5-0.1-0.7-0.1H10.4 c-0.2,0-0.5,0-0.7,0.1L39.6,45.8C39.6,45.8,39.6,45.8,39.6,45.8L39.6,45.8z"></path><path d="M5,23c0,0.2,0,0.4,0,0.6v51.7c0,0.2,0,0.5,0,0.7L32.7,48L5,23z"></path><path d="M51.9,60.3c-0.5,0.5-1.2,0.8-1.9,0.8c-0.7,0-1.3-0.3-1.9-0.8l-10.3-9.7L9.6,80.6c0.2,0,0.5,0.1,0.7,0.1h79.4 c0.2,0,0.5,0,0.7-0.1L62.1,50.7L51.9,60.3L51.9,60.3z"></path><path d="M95,23L67.3,48L95,76.1c0-0.2,0-0.5,0-0.7V23.7C95,23.4,95,23.2,95,23L95,23z"></path></svg>						</span>
										<span class="elementor-icon-list-text">info@example.com</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-fb52024" data-id="fb52024" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-b8849b1 elementor-widget__width-auto wdt-dark-bg elementor-hidden-mobile_extra elementor-hidden-mobile elementor-widget elementor-widget-wdt-heading" data-id="b8849b1" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-heading.default">
				<div class="elementor-widget-container">
					<div class="wdt-heading-holder " id="wdt-heading-b8849b1"><h6 class="wdt-heading-title-wrapper wdt-heading-align- wdt-heading-deco-wrapper"><span class="wdt-heading-title">We are Social:</span></h6></div>				</div>
				</div>
				<div class="elementor-element elementor-element-0ae5b05 elementor-icon-list--layout-inline elementor-widget__width-auto elementor-list-item-link-inline elementor-widget elementor-widget-icon-list" data-id="0ae5b05" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://www.facebook.com/">

												<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-facebook-f" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg"><path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path></svg>						</span>
										<span class="elementor-icon-list-text"></span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://www.x.com/">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><path d="M0.7,3.7L39,54.8L0.5,96.3h8.7L42.8,60L70,96.3h29.5l-40.4-54L94.9,3.7h-8.7l-31,33.5L30.2,3.7H0.7z M13.5,10H27L86.8,90 H73.2L13.5,10z"></path></svg>						</span>
										<span class="elementor-icon-list-text"></span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://web.whatsapp.com/">

												<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-whatsapp" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path></svg>						</span>
										<span class="elementor-icon-list-text"></span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://instagram.com/">

												<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg>						</span>
										<span class="elementor-icon-list-text"></span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-b81b5c3 elementor-section-full_width elementor-section-height-default elementor-section-height-default animated fadeIn" data-id="b81b5c3" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b9405ca" data-id="b9405ca" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-a41f9dd elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="a41f9dd" data-element_type="section" data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7cdf558 wdt-order-1" data-id="7cdf558" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-e7d5a53 elementor-widget__width-auto elementor-widget elementor-widget-wdt-logo" data-id="e7d5a53" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-logo.default">
				<div class="elementor-widget-container">
					<div id="grassroot-e7d5a53" class="wdt-logo-container">  <a href="https://wdtgrassroot.wpengine.com/rtl-demo/" rel="home"><img loading="lazy" src="./Services – RTL GrassRoot Site_files/Light-Logo.png" alt="RTL GrassRoot Site" width="350" height="80"></a></div>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-73065a6 wdt-order-3 elementor-hidden-tablet elementor-hidden-mobile_extra elementor-hidden-mobile" data-id="73065a6" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-158cb18 elementor-align-center wdt-dark-bg elementor-widget__width-auto elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile_extra elementor-hidden-mobile elementor-widget elementor-widget-wdt-header-menu" data-id="158cb18" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-header-menu.default">
				<div class="elementor-widget-container">
					<div class="wdt-header-menu" data-menu="2"><div class="menu-container"><ul id="menu-main-menu-1" class="wdt-primary-nav " data-menu="2"> <li class="close-nav"><a href="javascript:void(0);"></a></li> <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children menu-item-16427 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/"><span data-text="%1$s">Home</span></a>
<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-16200 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/"><span data-text="%1$s">Home 1 – Flourish Garden</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16201 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/home-2/"><span data-text="%1$s">Home 2 – Botanic Bliss</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16202 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/home-3/"><span data-text="%1$s">Home 3 – Garden Haven</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16216 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/home-4/"><span data-text="%1$s">Home 4 – Verdant Garden</span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-7570 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#"><span data-text="%1$s">Pages</span></a>
<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7572 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/about-us/"><span data-text="%1$s">About Us</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16225 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/portfolio/"><span data-text="%1$s">Portfolio</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7736 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/portfolio/"><span data-text="%1$s">Portfolio Listing</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-wdt_listings menu-item-16093 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/listings/gardening-masterpiece/"><span data-text="%1$s">Portfolio Detail</span></a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-4920 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/"><span data-text="%1$s">Shop</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16068 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/"><span data-text="%1$s">Shop Listing</span></a>
		<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7637 menu-item-depth-3"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/shop-left-sidebar/"><span data-text="%1$s">With Left Sidebar</span></a></li>
			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7639 menu-item-depth-3"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/shop-right-siderbar/"><span data-text="%1$s">With Right Sidebar</span></a></li>
			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7638 menu-item-depth-3"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/shop-no-sidebar/"><span data-text="%1$s">Without Sidebar</span></a></li>
		</ul>
</li>
		<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-16224 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/product/garden-gloves/"><span data-text="%1$s">Shop Single</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7644 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/cart/"><span data-text="%1$s">Cart</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7645 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/checkout/"><span data-text="%1$s">Checkout</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7646 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/wishlist/"><span data-text="%1$s">Wishlist</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16199 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/my-account/"><span data-text="%1$s">My account</span></a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7571 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/faq/"><span data-text="%1$s">FAQ</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7573 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/price-plan/"><span data-text="%1$s">Price Plan</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7574 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/our-team/"><span data-text="%1$s">Our Team</span></a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7575 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/404-error-page"><span data-text="%1$s">404 Error Page</span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-761 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/"><span data-text="%1$s">Blog</span></a>
<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16189 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/"><span data-text="%1$s">Blog Listings</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16192 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/with-left-sidebar/"><span data-text="%1$s">With Left Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16193 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/with-right-sidebar/"><span data-text="%1$s">With Right Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16194 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/without-sidebar/"><span data-text="%1$s">Without Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16191 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/blog-list-style/"><span data-text="%1$s">Blog List Style</span></a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-16197 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/tips-to-keep-your-garden-pest-free/"><span data-text="%1$s">Blog Details</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-16195 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/designing-smart-functional-garden/"><span data-text="%1$s">With Left Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-16196 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/greatest-blooming-garden-plants/"><span data-text="%1$s">With Right Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-16198 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/tips-to-keep-your-garden-pest-free/"><span data-text="%1$s">Without Sidebar</span></a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2132 current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-7568 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/" aria-current="page"><span data-text="%1$s">Services</span></a>
<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2132 current_page_item menu-item-16672 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/" aria-current="page"><span data-text="%1$s">Service Listings</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16092 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/seasonal-gardening-services/"><span data-text="%1$s">Service Details</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16666 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/commercial-gardening/"><span data-text="%1$s">Commercial Gardening</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16667 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/garden-installation/"><span data-text="%1$s">Garden Installation</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16668 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/large-scale-gardening/"><span data-text="%1$s">Large-Scale Gardening</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16669 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/seasonal-gardening-services/"><span data-text="%1$s">Seasonal Gardening Services</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16670 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/smart-gardening-solutions/"><span data-text="%1$s">Smart Gardening Solutions</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16671 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/vertical-farming-solutions/"><span data-text="%1$s">Vertical Farming Solutions</span></a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7567 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/contact-us/"><span data-text="%1$s">Contact</span></a></li>
 </ul> <div class="sub-menu-overlay"></div></div><div class="mobile-nav-container mobile-nav-offcanvas-right" data-menu="2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" class="menu-trigger menu-trigger-icon" data-menu="2"><i></i><span>Menu</span></a><div class="mobile-menu" data-menu="2"></div><div class="overlay"></div></div></div>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3a029dc wdt-order-2" data-id="3a029dc" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-75d8a90 elementor-widget__width-auto elementor-hidden-mobile_extra elementor-hidden-mobile elementor-widget elementor-widget-wdt-header-icons" data-id="75d8a90" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-header-icons.default">
				<div class="elementor-widget-container">
					<div class="woocommerce"><div class="wdt-header-icons-list"><div class="wdt-header-icons-list-item search-item search-overlay"><div class="wdt-search-menu-icon"><a href="javascript:void(0)" class="wdt-search-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><g>	<path d="M95,90.2L67.9,63.1C73,57,76,49.1,76,40.5C76,20.9,60.1,5,40.5,5C20.9,5,5,20.9,5,40.5C5,60.1,20.9,76,40.5,76  c8.6,0,16.4-3.1,22.6-8.1L90.2,95L95,90.2L95,90.2z M40.5,69.3c-15.8,0-28.7-12.9-28.7-28.7s12.9-28.7,28.7-28.7  c15.8,0,28.7,12.9,28.7,28.7S56.4,69.3,40.5,69.3L40.5,69.3z"></path></g></svg></i></span></a></div></div><div class="wdt-header-icons-list-item cart-item"><div class="wdt-shop-menu-icon"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/cart/"><span class="wdt-shop-menu-icon-wrapper"><span class="wdt-shop-menu-cart-inner"><span class="wdt-shop-menu-cart-icon"><i><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><g>	<g>		<path d="M79.3,80.3H34.2c-1.4,0-2.5-1.1-2.5-2.5s1.1-2.5,2.5-2.5h45.1c1.7,0,3.1-1.4,3.1-3.1s-1.4-3.1-3.1-3.1H31.9   c-1.2,0-2.2-0.8-2.4-1.9L15.7,10H4.9c-1.4,0-2.5-1.1-2.5-2.5S3.5,5,4.9,5h12.7c1.2,0,2.2,0.8,2.4,1.9l13.8,57.3h45.4   c4.4,0,8.1,3.6,8.1,8.1S83.7,80.3,79.3,80.3z"></path>	</g>	<g>		<path d="M85.9,56.6H28.9c-1.2,0-2.2-0.8-2.4-1.9l-9-37.3c-0.2-0.7,0-1.5,0.5-2.1c0.5-0.6,1.2-1,2-1h75c0.8,0,1.5,0.4,2,1   c0.5,0.6,0.6,1.4,0.5,2.1l-9,37.3C88.1,55.8,87.1,56.6,85.9,56.6z M30.8,51.6H84l7.8-32.3H23.1L30.8,51.6z"></path>	</g>	<g>		<path d="M40.7,95.8c-3.7,0-6.8-3-6.8-6.8s3-6.8,6.8-6.8s6.8,3,6.8,6.8S44.5,95.8,40.7,95.8z M40.7,87.2c-1,0-1.8,0.8-1.8,1.8   s0.8,1.8,1.8,1.8s1.8-0.8,1.8-1.8S41.7,87.2,40.7,87.2z"></path>	</g>	<g>		<path d="M77,95.8c-3.7,0-6.8-3-6.8-6.8s3-6.8,6.8-6.8s6.8,3,6.8,6.8S80.7,95.8,77,95.8z M77,87.2c-1,0-1.8,0.8-1.8,1.8   s0.8,1.8,1.8,1.8s1.8-0.8,1.8-1.8S77.9,87.2,77,87.2z"></path>	</g></g></svg></i></span><span class="wdt-shop-menu-cart-number">0</span></span><span class="wdt-shop-menu-cart-totals"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span>0.00</bdi></span></span></span></a></div></div></div></div>				</div>
				</div>
				<div class="elementor-element elementor-element-e395455 elementor-widget__width-auto elementor-hidden-mobile elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile_extra elementor-widget elementor-widget-wdt-button" data-id="e395455" data-element_type="widget" data-settings="{&quot;item_hover_background_background&quot;:&quot;classic&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-button.default">
				<div class="elementor-widget-container">
					<div class="wdt-button-holder wdt-template-filled wdt-button-link wdt-button-style-default wdt-button-size-nm wdt-animation- wdt-button-icon-after" id="wdt-button-e395455"><a class="wdt-button" href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#"><div class="wdt-button-text"><span>Get a Quote</span></div></a></div>				</div>
				</div>
				<div class="elementor-element elementor-element-39d1bf5 elementor-align-center wdt-dark-bg elementor-widget__width-auto elementor-hidden-desktop elementor-hidden-laptop elementor-widget elementor-widget-wdt-header-menu" data-id="39d1bf5" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-header-menu.default">
				<div class="elementor-widget-container">
					<div class="wdt-header-menu" data-menu="2"><div class="menu-container"><ul id="menu-main-menu-2" class="wdt-primary-nav " data-menu="2"> <li class="close-nav"><a href="javascript:void(0);"></a></li> <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children menu-item-16427 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/"><span data-text="%1$s">Home</span></a>
<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-16200 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/"><span data-text="%1$s">Home 1 – Flourish Garden</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16201 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/home-2/"><span data-text="%1$s">Home 2 – Botanic Bliss</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16202 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/home-3/"><span data-text="%1$s">Home 3 – Garden Haven</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16216 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/home-4/"><span data-text="%1$s">Home 4 – Verdant Garden</span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-7570 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#"><span data-text="%1$s">Pages</span></a>
<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7572 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/about-us/"><span data-text="%1$s">About Us</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16225 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/portfolio/"><span data-text="%1$s">Portfolio</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7736 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/portfolio/"><span data-text="%1$s">Portfolio Listing</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-wdt_listings menu-item-16093 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/listings/gardening-masterpiece/"><span data-text="%1$s">Portfolio Detail</span></a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-4920 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/"><span data-text="%1$s">Shop</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16068 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/"><span data-text="%1$s">Shop Listing</span></a>
		<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7637 menu-item-depth-3"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/shop-left-sidebar/"><span data-text="%1$s">With Left Sidebar</span></a></li>
			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7639 menu-item-depth-3"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/shop-right-siderbar/"><span data-text="%1$s">With Right Sidebar</span></a></li>
			<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7638 menu-item-depth-3"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/shop/shop-no-sidebar/"><span data-text="%1$s">Without Sidebar</span></a></li>
		</ul>
</li>
		<li class="menu-item menu-item-type-post_type menu-item-object-product menu-item-16224 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/product/garden-gloves/"><span data-text="%1$s">Shop Single</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7644 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/cart/"><span data-text="%1$s">Cart</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7645 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/checkout/"><span data-text="%1$s">Checkout</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7646 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/wishlist/"><span data-text="%1$s">Wishlist</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16199 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/my-account/"><span data-text="%1$s">My account</span></a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7571 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/faq/"><span data-text="%1$s">FAQ</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7573 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/price-plan/"><span data-text="%1$s">Price Plan</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7574 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/our-team/"><span data-text="%1$s">Our Team</span></a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7575 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/404-error-page"><span data-text="%1$s">404 Error Page</span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-761 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/"><span data-text="%1$s">Blog</span></a>
<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16189 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/"><span data-text="%1$s">Blog Listings</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16192 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/with-left-sidebar/"><span data-text="%1$s">With Left Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16193 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/with-right-sidebar/"><span data-text="%1$s">With Right Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16194 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/without-sidebar/"><span data-text="%1$s">Without Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16191 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/blog-list-style/"><span data-text="%1$s">Blog List Style</span></a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-has-children menu-item-16197 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/tips-to-keep-your-garden-pest-free/"><span data-text="%1$s">Blog Details</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-16195 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/designing-smart-functional-garden/"><span data-text="%1$s">With Left Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-16196 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/greatest-blooming-garden-plants/"><span data-text="%1$s">With Right Sidebar</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-16198 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/blog/tips-to-keep-your-garden-pest-free/"><span data-text="%1$s">Without Sidebar</span></a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2132 current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-7568 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/" aria-current="page"><span data-text="%1$s">Services</span></a>
<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2132 current_page_item menu-item-16672 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/" aria-current="page"><span data-text="%1$s">Service Listings</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16092 menu-item-depth-1"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/seasonal-gardening-services/"><span data-text="%1$s">Service Details</span></a>
	<ul class="sub-menu is-hidden">
<li class="close-nav"><a href="javascript:void(0);"></a></li><li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16666 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/commercial-gardening/"><span data-text="%1$s">Commercial Gardening</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16667 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/garden-installation/"><span data-text="%1$s">Garden Installation</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16668 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/large-scale-gardening/"><span data-text="%1$s">Large-Scale Gardening</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16669 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/seasonal-gardening-services/"><span data-text="%1$s">Seasonal Gardening Services</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16670 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/smart-gardening-solutions/"><span data-text="%1$s">Smart Gardening Solutions</span></a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16671 menu-item-depth-2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/vertical-farming-solutions/"><span data-text="%1$s">Vertical Farming Solutions</span></a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7567 menu-item-depth-0"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/contact-us/"><span data-text="%1$s">Contact</span></a></li>
 </ul> <div class="sub-menu-overlay"></div></div><div class="mobile-nav-container mobile-nav-offcanvas-right" data-menu="2"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" class="menu-trigger menu-trigger-icon" data-menu="2"><i></i><span>Menu</span></a><div class="mobile-menu" data-menu="2"></div><div class="overlay"></div></div></div>				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<div class="elementor-element elementor-element-3947615 elementor-absolute elementor-widget elementor-widget-spacer" data-id="3947615" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
							<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div></div></header>                <!-- **Header - End ** -->

                <!-- ** Slider ** -->

                <!-- ** Slider End ** -->

                <!-- ** Breadcrumb ** -->
                    <section class="main-title-section-wrapper dark-bg-breadcrumb aligncenter">
    <div class="main-title-section-container">
        <div class="container">
            <div class="main-title-section"><h1>Services</h1></div>
            <div class="breadcrumb"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/">Home</a><span class="breadcrumb-default-delimiter"></span><span class="current">Services</span></div>        </div>
    </div>
    <div class="main-title-section-bg"></div>
</section>                <!-- ** Breadcrumb End ** -->

            </div><!-- ** Header Wrapper - End ** -->

            <!-- **Main** -->
            <div id="main">


                                <!-- ** Container ** -->
                <div class="wdt-elementor-container-fluid">
                    		<div data-elementor-type="wp-page" data-elementor-id="2132" class="elementor elementor-2132">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-ddeaf6e wdt-cus-half-overlay-bg-style elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ddeaf6e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c26314e" data-id="c26314e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-b46e13a elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="b46e13a" data-element_type="section" data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-b121394 animated-fast animated fadeInLeft" data-id="b121394" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInLeft&quot;,&quot;animation_delay&quot;:&quot;100&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-5a0582b before-title elementor-widget elementor-widget-wdt-heading" data-id="5a0582b" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-heading.default">
				<div class="elementor-widget-container">
					<div class="wdt-heading-holder " id="wdt-heading-5a0582b"><div class="wdt-heading-subtitle-wrapper wdt-heading-align- wdt-heading-deco-wrapper"><span class="wdt-heading-subtitle"><span class="wdt-heading-deco-inner wdt-left-part"><span class="wdt-heading-deco-icon"><span class="wdt-content-icon-wrapper"><span class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><g>	<g>		<path d="M37.8,65.1c2.1,4.3,3.7,8.9,4.8,13.5c-0.4,2.1-0.8,4.2-1.1,6.3c-0.2,1.5-0.4,3-0.6,4.5c-0.3,2.4,1.5,4.5,4,4.7l2.5,0.2   c0-1.5,0-2.9,0-4.3c1.4-2.8,3.2-5.5,5.2-8c1.1-1.3,2.3-2.6,3.6-3.8c2.2-1.9,4.6-3.5,7.1-4.9c3.3-1.7,6.8-3.1,10.4-3.7   c-3.5,1-6.7,2.8-9.7,4.8c-2.9,2.1-5.5,4.6-7.7,7.3c-0.2,0.3-0.4,0.6-0.6,0.9c8.5,2.8,21.8-3.1,22.3-15.3   c-11.8-5.9-24.3,0.2-25.8,11.4c-0.5,0.4-1,0.9-1.5,1.3c-1,0.9-1.9,1.9-2.8,2.9c0.7-7.9,2.3-15.8,4.7-23.5   c2.4-7.4,5.7-14.6,9.8-21.3c1-1.4,2-2.9,3-4.2c2.8-3.6,5.8-7.1,9-10.3c3.3-3.2,6.7-6.1,10.5-8.6c-3.5,2.6-20,18.9-27.4,44.7   c22.1,0.3,48.3-26.4,37.5-55C62.5,2.9,40.5,29.6,49.4,56.6c-0.2,0.5-0.5,1-0.7,1.6c-1.7,4.1-3.1,8.3-4.3,12.6   c-1.2-2.6-2.5-5.1-3.9-7.5c-1-1.7-2.1-3.4-3.3-5c-1.9-2.9-4-5.6-6.3-8.2c-2-2.2-4.2-4.3-6.6-6.2c-2.4-1.9-4.8-3.7-7.6-5.1   c2.5,1,15.1,6.7,23.7,18.7c-0.3-17.1-17-30.1-37.3-25.9C-1.8,53.8,22.4,70.5,37.8,65.1L37.8,65.1z"></path>	</g></g></svg></i></span></span></span></span></span>Transforming Spaces<span class="wdt-heading-deco-inner wdt-right-part"></span></span></div><h2 class="wdt-heading-title-wrapper wdt-heading-align- "><span class="wdt-heading-title">One-Stop Gardening Solution</span></h2></div>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4d34a94 animated-fast animated fadeInRight" data-id="4d34a94" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;,&quot;animation_delay&quot;:&quot;100&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-638666e elementor-widget__width-auto animated-fast elementor-widget elementor-widget-wdt-button" data-id="638666e" data-element_type="widget" data-settings="{&quot;item_normal_background_background&quot;:&quot;classic&quot;,&quot;item_hover_background_background&quot;:&quot;classic&quot;,&quot;_animation&quot;:&quot;none&quot;,&quot;_animation_delay&quot;:&quot;100&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-button.default">
				<div class="elementor-widget-container">
					<div class="wdt-button-holder wdt-template-filled wdt-button-link wdt-button-style-default wdt-button-size-nm wdt-animation- wdt-button-icon-after" id="wdt-button-638666e"><a class="wdt-button" href="https://wdtgrassroot.wpengine.com/rtl-demo/our-services/"><div class="wdt-button-text"><span>View all Services</span></div></a></div>				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-7a05cca animated-fast elementor-section-boxed elementor-section-height-default elementor-section-height-default animated fadeInUp" data-id="7a05cca" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:&quot;100&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-183aea0" data-id="183aea0" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-00387ec elementor-widget-mobile_extra__width-initial elementor-widget-mobile__width-inherit wdt-cus-service-style-01 elementor-widget elementor-widget-wdt-image-box" data-id="00387ec" data-element_type="widget" data-settings="{&quot;button_normal_background_background&quot;:&quot;classic&quot;,&quot;button_hover_background_background&quot;:&quot;classic&quot;,&quot;columns&quot;:&quot;3&quot;,&quot;columns_laptop&quot;:&quot;3&quot;,&quot;columns_tablet_extra&quot;:&quot;3&quot;,&quot;columns_tablet&quot;:2,&quot;columns_mobile_extra&quot;:1,&quot;columns_mobile&quot;:1,&quot;carousel_arrows_prev_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-image-box.default">
				<div class="elementor-widget-container">
					<div class="wdt-image-box-holder wdt-content-item-holder wdt-column-holder wdt-rc-template-custom-template" id="wdt-image-box-00387ec" data-settings="{&quot;enable_popup&quot;:&quot;&quot;,&quot;enable_hover_class&quot;:&quot;&quot;}"><div class="wdt-column-wrapper wdt-column-gap-custom wdt-snap-scroll-enabled" data-column-settings="{&quot;columnDevices&quot;:[&quot;tablet_extra&quot;,&quot;tablet&quot;,&quot;mobile_extra&quot;,&quot;mobile&quot;]}" data-module-id="wdt-module-id-00387ec" id="wdt-module-id-00387ec"><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-elements-group wdt-media-group wdt-media-image-cover"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img fetchpriority="high" decoding="async" width="766" height="800" src="./Services – RTL GrassRoot Site_files/Service-img-1.jpg" class="attachment-full size-full wp-image-15748" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Service-img-1.jpg 766w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Service-img-1-287x300.jpg 287w" sizes="(max-width: 766px) 100vw, 766px"></a></div></div><div class="wdt-media-image-cover-container"><div class="wdt-content-button wdt-button-clone"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><div class="wdt-button-text"><span>View</span></div></a></div></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">01. Vertical Farming Solutions</a></h5></div><div class="wdt-content-description">Egestas vehicula dis imperdiet, diam ut lobortis rutrum viverra praesent nibh conubia sagittis. </div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-elements-group wdt-media-group wdt-media-image-cover"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img decoding="async" width="766" height="800" src="./Services – RTL GrassRoot Site_files/Service-img-2.jpg" class="attachment-full size-full wp-image-15749" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Service-img-2.jpg 766w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Service-img-2-287x300.jpg 287w" sizes="(max-width: 766px) 100vw, 766px"></a></div></div><div class="wdt-media-image-cover-container"><div class="wdt-content-button wdt-button-clone"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><div class="wdt-button-text"><span>View</span></div></a></div></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">02. Seasonal Gardening Services</a></h5></div><div class="wdt-content-description">Faucibus convallis aptent elementum malesuada nibh finibus diamlobortis nostra.</div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-elements-group wdt-media-group wdt-media-image-cover"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img decoding="async" width="766" height="800" src="./Services – RTL GrassRoot Site_files/Service-img-3.jpg" class="attachment-full size-full wp-image-15750" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Service-img-3.jpg 766w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Service-img-3-287x300.jpg 287w" sizes="(max-width: 766px) 100vw, 766px"></a></div></div><div class="wdt-media-image-cover-container"><div class="wdt-content-button wdt-button-clone"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><div class="wdt-button-text"><span>View</span></div></a></div></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">03. Smart Gardening Solutions</a></h5></div><div class="wdt-content-description">Volutpat facilisi quam lectus lacinia massa himenaeos penatibus mi id vehicula purus.</div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-elements-group wdt-media-group wdt-media-image-cover"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="766" height="800" src="./Services – RTL GrassRoot Site_files/Service-img-4.jpg" class="attachment-full size-full wp-image-15751" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Service-img-4.jpg 766w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/Service-img-4-287x300.jpg 287w" sizes="(max-width: 766px) 100vw, 766px"></a></div></div><div class="wdt-media-image-cover-container"><div class="wdt-content-button wdt-button-clone"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><div class="wdt-button-text"><span>View</span></div></a></div></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">04. Commercial Gardening</a></h5></div><div class="wdt-content-description">Felis laoreet sociosqu morbi velit ultricies nostra dis. Et vivamus praesent cursus metus id nunc.</div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-elements-group wdt-media-group wdt-media-image-cover"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="766" height="800" src="./Services – RTL GrassRoot Site_files/H-3-Service-img-2.jpg" class="attachment-full size-full wp-image-16018" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/02/H-3-Service-img-2.jpg 766w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/02/H-3-Service-img-2-287x300.jpg 287w" sizes="(max-width: 766px) 100vw, 766px"></a></div></div><div class="wdt-media-image-cover-container"><div class="wdt-content-button wdt-button-clone"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><div class="wdt-button-text"><span>View</span></div></a></div></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">05. Large-Scale Gardening</a></h5></div><div class="wdt-content-description">Tortor libero tortor faucibus aenean fermentum. Sollicitudin sed vehicula sem nisl non senectus.</div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-elements-group wdt-media-group wdt-media-image-cover"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="766" height="800" src="./Services – RTL GrassRoot Site_files/H-3-Service-img-3.jpg" class="attachment-full size-full wp-image-16019" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/02/H-3-Service-img-3.jpg 766w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/02/H-3-Service-img-3-287x300.jpg 287w" sizes="(max-width: 766px) 100vw, 766px"></a></div></div><div class="wdt-media-image-cover-container"><div class="wdt-content-button wdt-button-clone"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><div class="wdt-button-text"><span>View</span></div></a></div></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">06. Garden Installation</a></h5></div><div class="wdt-content-description">Tristique ultricies semper pharetra convallis netus. Congue lobortis ultrices per.</div></div></div></div></div><div class="wdt-column-pagination wdt-snap-scroll-pagination">
						<button class="wdt-pagination-prev wdt-module-id-00387ec disabled" style="cursor: not-allowed;">Previous</button>
						<button class="wdt-pagination-next wdt-module-id-00387ec disabled" style="cursor: not-allowed;">Next</button></div></div>				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-a9298cf elementor-section-full_width wdt-black-bg elementor-section-height-default elementor-section-height-default" data-id="a9298cf" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d9b3607" data-id="d9b3607" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-55c4e44 elementor-widget elementor-widget-spacer" data-id="55c4e44" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
							<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
						</div>
				</div>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-ee7e44c wdt-dark-bg animated-fast elementor-section-boxed elementor-section-height-default elementor-section-height-default animated fadeInUp" data-id="ee7e44c" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:&quot;100&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7b22198 animated-fast animated fadeInLeft" data-id="7b22198" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInLeft&quot;,&quot;animation_delay&quot;:&quot;100&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-53068b8 before-title wdt-dark-bg elementor-widget elementor-widget-wdt-heading" data-id="53068b8" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-heading.default">
				<div class="elementor-widget-container">
					<div class="wdt-heading-holder " id="wdt-heading-53068b8"><div class="wdt-heading-subtitle-wrapper wdt-heading-align- wdt-heading-deco-wrapper"><span class="wdt-heading-subtitle"><span class="wdt-heading-deco-inner wdt-left-part"><span class="wdt-heading-deco-icon"><span class="wdt-content-icon-wrapper"><span class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><g>	<g>		<path d="M37.8,65.1c2.1,4.3,3.7,8.9,4.8,13.5c-0.4,2.1-0.8,4.2-1.1,6.3c-0.2,1.5-0.4,3-0.6,4.5c-0.3,2.4,1.5,4.5,4,4.7l2.5,0.2   c0-1.5,0-2.9,0-4.3c1.4-2.8,3.2-5.5,5.2-8c1.1-1.3,2.3-2.6,3.6-3.8c2.2-1.9,4.6-3.5,7.1-4.9c3.3-1.7,6.8-3.1,10.4-3.7   c-3.5,1-6.7,2.8-9.7,4.8c-2.9,2.1-5.5,4.6-7.7,7.3c-0.2,0.3-0.4,0.6-0.6,0.9c8.5,2.8,21.8-3.1,22.3-15.3   c-11.8-5.9-24.3,0.2-25.8,11.4c-0.5,0.4-1,0.9-1.5,1.3c-1,0.9-1.9,1.9-2.8,2.9c0.7-7.9,2.3-15.8,4.7-23.5   c2.4-7.4,5.7-14.6,9.8-21.3c1-1.4,2-2.9,3-4.2c2.8-3.6,5.8-7.1,9-10.3c3.3-3.2,6.7-6.1,10.5-8.6c-3.5,2.6-20,18.9-27.4,44.7   c22.1,0.3,48.3-26.4,37.5-55C62.5,2.9,40.5,29.6,49.4,56.6c-0.2,0.5-0.5,1-0.7,1.6c-1.7,4.1-3.1,8.3-4.3,12.6   c-1.2-2.6-2.5-5.1-3.9-7.5c-1-1.7-2.1-3.4-3.3-5c-1.9-2.9-4-5.6-6.3-8.2c-2-2.2-4.2-4.3-6.6-6.2c-2.4-1.9-4.8-3.7-7.6-5.1   c2.5,1,15.1,6.7,23.7,18.7c-0.3-17.1-17-30.1-37.3-25.9C-1.8,53.8,22.4,70.5,37.8,65.1L37.8,65.1z"></path>	</g></g></svg></i></span></span></span></span></span>Their Experiences!<span class="wdt-heading-deco-inner wdt-right-part"></span></span></div><h2 class="wdt-heading-title-wrapper wdt-heading-align- "><span class="wdt-heading-title">Hear from Our Clients</span></h2></div>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-bdb3ad2 animated-fast animated fadeInRight" data-id="bdb3ad2" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;,&quot;animation_delay&quot;:&quot;100&quot;}">
			<div class="elementor-widget-wrap">
							</div>
		</div>
					</div>
		</section>
				<div class="elementor-element elementor-element-cc75cc5 wdt-cus-testimonial-style-2 elementor-widget-mobile_extra__width-initial elementor-widget-mobile__width-inherit animated-fast elementor-widget elementor-widget-wdt-testimonial animated fadeInUp" data-id="cc75cc5" data-element_type="widget" data-settings="{&quot;slides_to_show_opts&quot;:&quot;4&quot;,&quot;slides_to_show_opts_laptop&quot;:&quot;3&quot;,&quot;gap&quot;:{&quot;unit&quot;:&quot;dpt&quot;,&quot;size&quot;:30,&quot;sizes&quot;:[]},&quot;gap_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:30,&quot;sizes&quot;:[]},&quot;gap_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:30,&quot;sizes&quot;:[]},&quot;gap_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:30,&quot;sizes&quot;:[]},&quot;slides_to_show_opts_tablet_extra&quot;:&quot;3&quot;,&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100,&quot;direction&quot;:&quot;horizontal&quot;,&quot;effect&quot;:&quot;default&quot;,&quot;slides_to_show_opts_tablet&quot;:2,&quot;slides_to_show_opts_mobile_extra&quot;:1,&quot;slides_to_show_opts_mobile&quot;:1,&quot;slides_to_scroll_opts&quot;:&quot;single&quot;,&quot;mouse_wheel_scroll&quot;:&quot;false&quot;,&quot;pagination&quot;:&quot;bullets&quot;,&quot;speed&quot;:300,&quot;gap_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;gap_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;allow_touch&quot;:&quot;yes&quot;,&quot;loop&quot;:&quot;yes&quot;,&quot;carousel_arrows_prev_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-testimonial.default">
				<div class="elementor-widget-container">
					<div class="wdt-testimonial-holder  wdt-content-item-holder wdt-carousel-holder wdt-rc-template-custom-template" id="wdt-testimonial-cc75cc5" data-id="cc75cc5" data-settings=""><div class="wdt-testimonial-container swiper swiper-initialized swiper-horizontal swiper-rtl swiper-watch-progress" data-settings="{&quot;direction&quot;:&quot;horizontal&quot;,&quot;effect&quot;:&quot;default&quot;,&quot;slides_to_show&quot;:&quot;4&quot;,&quot;slides_to_scroll&quot;:1,&quot;arrows&quot;:&quot;&quot;,&quot;pagination&quot;:&quot;bullets&quot;,&quot;mouse_wheel_scroll&quot;:&quot;false&quot;,&quot;speed&quot;:300,&quot;autoplay&quot;:&quot;&quot;,&quot;autoplay_speed&quot;:null,&quot;autoplay_direction&quot;:null,&quot;allow_touch&quot;:&quot;yes&quot;,&quot;loop&quot;:&quot;yes&quot;,&quot;centered_slides&quot;:&quot;&quot;,&quot;pause_on_interaction&quot;:null,&quot;overflow_type&quot;:&quot;&quot;,&quot;overflow_opacity&quot;:&quot;&quot;,&quot;unequal_height_compatability&quot;:null,&quot;gap&quot;:30,&quot;responsive&quot;:[{&quot;breakpoint&quot;:319,&quot;toshow&quot;:1,&quot;toscroll&quot;:1},{&quot;breakpoint&quot;:480,&quot;toshow&quot;:1,&quot;toscroll&quot;:1},{&quot;breakpoint&quot;:768,&quot;toshow&quot;:2,&quot;toscroll&quot;:1},{&quot;breakpoint&quot;:1025,&quot;toshow&quot;:3,&quot;toscroll&quot;:1},{&quot;breakpoint&quot;:1281,&quot;toshow&quot;:3,&quot;toscroll&quot;:1},{&quot;breakpoint&quot;:1541,&quot;toshow&quot;:4,&quot;toscroll&quot;:1}],&quot;space_between_gaps&quot;:{&quot;desktop&quot;:30,&quot;mobile&quot;:30,&quot;mobile_extra&quot;:30,&quot;tablet&quot;:30,&quot;tablet_extra&quot;:30,&quot;laptop&quot;:30}}" id="wdt-testimonial-swiper-cc75cc5"><div class="wdt-testimonial-wrapper swiper-wrapper" style="transform: translate3d(0px, 0px, 0px);" id="swiper-wrapper-f7b866e6b1632579" aria-live="polite"><div class="swiper-slide swiper-slide-visible swiper-slide-active" style="width: 587px; margin-left: 30px;" role="group" aria-label="1 / 6" data-swiper-slide-index="0"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="120" height="120" src="./Services – RTL GrassRoot Site_files/testimonial-06.jpg" class="attachment-full size-full wp-image-16595" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-06.jpg 120w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-06-100x100.jpg 100w" sizes="(max-width: 120px) 100vw, 120px"></a></div></div><div class="wdt-content-elements-group wdt-media-group wdt-media-image-default"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Sophia Bloom </a></h5></div><div class="wdt-content-subtitle">Green Designer</div></div><div class="wdt-content-icon-wrapper"><div class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 70" style="enable-background:new 0 0 90 70;" xml:space="preserve"><g>	<path d="M78,36.1c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.7,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C61.2,75.1,46.2,55.6,50,40.2  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path>	<path d="M28.6,34.4c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.6,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C11.8,73.3-3.2,53.8,0.6,38.4  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path></g></svg></i></span></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-description">Ullamcorper dis egestas eget augue ad aptent penatibus molestie proin. Bibendum curae himenaeos sapien lobortis rhoncus vulputate.</div></div></div></div><div class="swiper-slide swiper-slide-visible swiper-slide-next" style="width: 587px; margin-left: 30px;" role="group" aria-label="2 / 6" data-swiper-slide-index="1"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="120" height="120" src="./Services – RTL GrassRoot Site_files/testimonial-05.jpg" class="attachment-full size-full wp-image-16594" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-05.jpg 120w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-05-100x100.jpg 100w" sizes="(max-width: 120px) 100vw, 120px"></a></div></div><div class="wdt-content-elements-group wdt-media-group wdt-media-image-default"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Jessica Sprout</a></h5></div><div class="wdt-content-subtitle">Indoor Gardener</div></div><div class="wdt-content-icon-wrapper"><div class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 70" style="enable-background:new 0 0 90 70;" xml:space="preserve"><g>	<path d="M78,36.1c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.7,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C61.2,75.1,46.2,55.6,50,40.2  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path>	<path d="M28.6,34.4c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.6,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C11.8,73.3-3.2,53.8,0.6,38.4  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path></g></svg></i></span></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-description">Eu odio cubilia netus aliquet integer erat taciti dictum. In nostra elit efficitur fermentum fames ut volutpat hac. Mi ipsum aliquam donec.</div></div></div></div><div class="swiper-slide swiper-slide-visible" style="width: 587px; margin-left: 30px;" role="group" aria-label="3 / 6" data-swiper-slide-index="2"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="120" height="120" src="./Services – RTL GrassRoot Site_files/testimonial-04.jpg" class="attachment-full size-full wp-image-16593" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-04.jpg 120w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-04-100x100.jpg 100w" sizes="(max-width: 120px) 100vw, 120px"></a></div></div><div class="wdt-content-elements-group wdt-media-group wdt-media-image-default"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Emily Moss</a></h5></div><div class="wdt-content-subtitle">Leaf Enthusiast</div></div><div class="wdt-content-icon-wrapper"><div class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 70" style="enable-background:new 0 0 90 70;" xml:space="preserve"><g>	<path d="M78,36.1c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.7,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C61.2,75.1,46.2,55.6,50,40.2  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path>	<path d="M28.6,34.4c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.6,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C11.8,73.3-3.2,53.8,0.6,38.4  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path></g></svg></i></span></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-description">Conubia cras ligula semper diam tristique adipiscing elit. Interdum eros cursus ligula placerat conubia montes. Tincidunt consectetur. </div></div></div></div><div class="swiper-slide" style="width: 587px; margin-left: 30px;" role="group" aria-label="4 / 6" data-swiper-slide-index="3"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="120" height="120" src="./Services – RTL GrassRoot Site_files/testimonial-03.jpg" class="attachment-full size-full wp-image-16592" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-03.jpg 120w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-03-100x100.jpg 100w" sizes="(max-width: 120px) 100vw, 120px"></a></div></div><div class="wdt-content-elements-group wdt-media-group wdt-media-image-default"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">David Leafman</a></h5></div><div class="wdt-content-subtitle">Botanical Expert</div></div><div class="wdt-content-icon-wrapper"><div class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 70" style="enable-background:new 0 0 90 70;" xml:space="preserve"><g>	<path d="M78,36.1c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.7,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C61.2,75.1,46.2,55.6,50,40.2  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path>	<path d="M28.6,34.4c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.6,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C11.8,73.3-3.2,53.8,0.6,38.4  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path></g></svg></i></span></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-description"> Facilisi phasellus vel maximus; congue orci penatibus. Himenaeos ullamcorper dui massa euismod et; posuere mollis vivamus.</div></div></div></div><div class="swiper-slide" style="width: 587px; margin-left: 30px;" role="group" aria-label="5 / 6" data-swiper-slide-index="4"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="120" height="120" src="./Services – RTL GrassRoot Site_files/testimonial-02.jpg" class="attachment-full size-full wp-image-16591" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-02.jpg 120w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-02-100x100.jpg 100w" sizes="(max-width: 120px) 100vw, 120px"></a></div></div><div class="wdt-content-elements-group wdt-media-group wdt-media-image-default"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Michael Fernwood</a></h5></div><div class="wdt-content-subtitle">Gardening Coach</div></div><div class="wdt-content-icon-wrapper"><div class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 70" style="enable-background:new 0 0 90 70;" xml:space="preserve"><g>	<path d="M78,36.1c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.7,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C61.2,75.1,46.2,55.6,50,40.2  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path>	<path d="M28.6,34.4c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.6,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C11.8,73.3-3.2,53.8,0.6,38.4  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path></g></svg></i></span></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-description">Urna integer malesuada placerat interdum blandit proin bibendum. Vulputate et hendrerit taciti dictum augue morbi eget ornare. </div></div></div></div><div class="swiper-slide" role="group" aria-label="6 / 6" style="width: 587px; margin-left: 30px;" data-swiper-slide-index="5"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="120" height="120" src="./Services – RTL GrassRoot Site_files/testimonial-01.jpg" class="attachment-full size-full wp-image-16590" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-01.jpg 120w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/03/testimonial-01-100x100.jpg 100w" sizes="(max-width: 120px) 100vw, 120px"></a></div></div><div class="wdt-content-elements-group wdt-media-group wdt-media-image-default"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Robert Oakley</a></h5></div><div class="wdt-content-subtitle">Farming Consultant</div></div><div class="wdt-content-icon-wrapper"><div class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 70" style="enable-background:new 0 0 90 70;" xml:space="preserve"><g>	<path d="M78,36.1c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.7,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C61.2,75.1,46.2,55.6,50,40.2  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path>	<path d="M28.6,34.4c0.1,0,0.1-1.5,0.1-1.6c-0.1-1.8-0.3-3.6-0.7-5.4c-1.5-7.4-4.7-14.6-9.1-20.6c-1.2-1.6-2.5-3.1-3.9-4.5  c-0.5-0.5-1-1-1.5-1.4c-0.1-0.1-0.9-0.7-0.8-0.7c1.4-0.4,3.6,1.1,4.7,1.8c4.6,2.9,8.3,7.2,11.5,11.5c1.9,2.6,3.8,5.3,5.3,8.2  c1.2,2.3,2.2,4.7,3.1,7.2c4,11.1,6.4,27.3-4.3,35.6c-1.5,1.1-3.1,2.1-4.8,2.7C11.8,73.3-3.2,53.8,0.6,38.4  c2.6-10.5,14.8-16.2,24-10.4c3,1.9,5.4,4.5,7.4,7.4"></path></g></svg></i></span></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-description">Consectetur magnis elit viverra quisque magna metus amet accumsan ullamcorper. Facilisis egestas donec enim parturient fringilla. </div></div></div></div></div><span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div><div class="wdt-carousel-pagination-wrapper"><div class="wdt-swiper-pagination wdt-swiper-pagination-cc75cc5 swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal"><span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button" aria-label="Go to slide 1" aria-current="true"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 2"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 3"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 4"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 5"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 6"></span></div></div></div>				</div>
				</div>
				<div class="elementor-element elementor-element-be57044 e-transform elementor-widget elementor-widget-spacer" data-id="be57044" data-element_type="widget" data-settings="{&quot;_transform_flipY_effect&quot;:&quot;transform&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
							<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-53b7d04 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="53b7d04" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-072d968" data-id="072d968" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-ce04dd3 animated-fast elementor-section-full_width elementor-section-height-default elementor-section-height-default animated fadeInUp" data-id="ce04dd3" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:&quot;100&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-8f964c8" data-id="8f964c8" data-element_type="column">
			<div class="elementor-widget-wrap">
							</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6e1a7e5" data-id="6e1a7e5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-b249a2a before-title animated-fast elementor-widget elementor-widget-wdt-heading animated fadeInUp" data-id="b249a2a" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100,&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-heading.default">
				<div class="elementor-widget-container">
					<div class="wdt-heading-holder " id="wdt-heading-b249a2a"><div class="wdt-heading-subtitle-wrapper wdt-heading-align- wdt-heading-deco-wrapper"><span class="wdt-heading-subtitle"><span class="wdt-heading-deco-inner wdt-left-part"><span class="wdt-heading-deco-icon"><span class="wdt-content-icon-wrapper"><span class="wdt-content-icon"><span><i><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><g>	<g>		<path d="M37.8,65.1c2.1,4.3,3.7,8.9,4.8,13.5c-0.4,2.1-0.8,4.2-1.1,6.3c-0.2,1.5-0.4,3-0.6,4.5c-0.3,2.4,1.5,4.5,4,4.7l2.5,0.2   c0-1.5,0-2.9,0-4.3c1.4-2.8,3.2-5.5,5.2-8c1.1-1.3,2.3-2.6,3.6-3.8c2.2-1.9,4.6-3.5,7.1-4.9c3.3-1.7,6.8-3.1,10.4-3.7   c-3.5,1-6.7,2.8-9.7,4.8c-2.9,2.1-5.5,4.6-7.7,7.3c-0.2,0.3-0.4,0.6-0.6,0.9c8.5,2.8,21.8-3.1,22.3-15.3   c-11.8-5.9-24.3,0.2-25.8,11.4c-0.5,0.4-1,0.9-1.5,1.3c-1,0.9-1.9,1.9-2.8,2.9c0.7-7.9,2.3-15.8,4.7-23.5   c2.4-7.4,5.7-14.6,9.8-21.3c1-1.4,2-2.9,3-4.2c2.8-3.6,5.8-7.1,9-10.3c3.3-3.2,6.7-6.1,10.5-8.6c-3.5,2.6-20,18.9-27.4,44.7   c22.1,0.3,48.3-26.4,37.5-55C62.5,2.9,40.5,29.6,49.4,56.6c-0.2,0.5-0.5,1-0.7,1.6c-1.7,4.1-3.1,8.3-4.3,12.6   c-1.2-2.6-2.5-5.1-3.9-7.5c-1-1.7-2.1-3.4-3.3-5c-1.9-2.9-4-5.6-6.3-8.2c-2-2.2-4.2-4.3-6.6-6.2c-2.4-1.9-4.8-3.7-7.6-5.1   c2.5,1,15.1,6.7,23.7,18.7c-0.3-17.1-17-30.1-37.3-25.9C-1.8,53.8,22.4,70.5,37.8,65.1L37.8,65.1z"></path>	</g></g></svg></i></span></span></span></span></span>HOW We Work<span class="wdt-heading-deco-inner wdt-right-part"></span></span></div><h2 class="wdt-heading-title-wrapper wdt-heading-align- "><span class="wdt-heading-title">Gardening Workflow</span></h2></div>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-e03c967" data-id="e03c967" data-element_type="column">
			<div class="elementor-widget-wrap">
							</div>
		</div>
					</div>
		</section>
				<div class="elementor-element elementor-element-773cbc4 wdt-cus-home3-process wdt-cus-service-process elementor-widget-mobile_extra__width-initial elementor-widget-mobile__width-inherit animated-fast elementor-widget elementor-widget-wdt-image-box animated fadeInUp" data-id="773cbc4" data-element_type="widget" data-settings="{&quot;columns&quot;:&quot;4&quot;,&quot;columns_laptop&quot;:&quot;4&quot;,&quot;columns_tablet_extra&quot;:&quot;3&quot;,&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:100,&quot;columns_tablet&quot;:2,&quot;columns_mobile_extra&quot;:1,&quot;columns_mobile&quot;:1,&quot;carousel_arrows_prev_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-image-box.default">
				<div class="elementor-widget-container">
					<div class="wdt-image-box-holder wdt-content-item-holder wdt-column-holder wdt-rc-template-custom-template wdt-image-active-class" id="wdt-image-box-773cbc4" data-settings="{&quot;enable_popup&quot;:&quot;&quot;,&quot;enable_hover_class&quot;:&quot;yes&quot;}"><div class="wdt-column-wrapper wdt-column-gap-custom wdt-snap-scroll-enabled" data-column-settings="{&quot;columnDevices&quot;:[&quot;tablet_extra&quot;,&quot;tablet&quot;,&quot;mobile_extra&quot;,&quot;mobile&quot;]}" data-module-id="wdt-module-id-773cbc4" id="wdt-module-id-773cbc4"><div class="wdt-column wdt-active"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="130" height="130" src="./Services – RTL GrassRoot Site_files/work-process-img-1.jpg" class="attachment-full size-full wp-image-15899" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/work-process-img-1.jpg 130w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/work-process-img-1-100x100.jpg 100w" sizes="(max-width: 130px) 100vw, 130px"></a></div></div><div class="wdt-content-subtitle">Accumsan mass</div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Consultation</a></h5></div><div class="wdt-content-description">Fermentum accumsan nunc ornare ipsum diam ridiculus sociosqu. </div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="130" height="130" src="./Services – RTL GrassRoot Site_files/work-process-img-2.jpg" class="attachment-full size-full wp-image-15900" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/work-process-img-2.jpg 130w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/work-process-img-2-100x100.jpg 100w" sizes="(max-width: 130px) 100vw, 130px"></a></div></div><div class="wdt-content-subtitle">Accumsan mass</div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Design &amp; Proposal</a></h5></div><div class="wdt-content-description">Nibh ultricies ullamcorper bibendum vehicula tempus facilisis.</div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="130" height="130" src="./Services – RTL GrassRoot Site_files/work-process-img-3.jpg" class="attachment-full size-full wp-image-15901" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/work-process-img-3.jpg 130w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/work-process-img-3-100x100.jpg 100w" sizes="(max-width: 130px) 100vw, 130px"></a></div></div><div class="wdt-content-subtitle">Accumsan mass</div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Planting &amp; Installation</a></h5></div><div class="wdt-content-description">Accumsan lobortis urna dignissim, ante  mus elit imperdiet augue.</div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-content-media-group"><div class="wdt-content-image-wrapper "><div class="wdt-content-image"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" width="130" height="130" src="./Services – RTL GrassRoot Site_files/work-process-img-4.jpg" class="attachment-full size-full wp-image-15902" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/work-process-img-4.jpg 130w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/work-process-img-4-100x100.jpg 100w" sizes="(max-width: 130px) 100vw, 130px"></a></div></div><div class="wdt-content-subtitle">Accumsan mass</div></div><div class="wdt-content-detail-group"><div class="wdt-content-title"><h5><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" target="_blank" rel="nofollow">Final Inspection</a></h5></div><div class="wdt-content-description">Ex hendrerit bibendum mattis lectus ligula tincidunt nunc sodales.</div></div></div></div></div><div class="wdt-column-pagination wdt-snap-scroll-pagination">
						<button class="wdt-pagination-prev wdt-module-id-773cbc4 disabled" style="cursor: not-allowed;">Previous</button>
						<button class="wdt-pagination-next wdt-module-id-773cbc4 disabled" style="cursor: not-allowed;">Next</button></div></div>				</div>
				</div>
				<div class="elementor-element elementor-element-25e935e animated-fast elementor-widget elementor-widget-wdt-button animated fadeInUp" data-id="25e935e" data-element_type="widget" data-settings="{&quot;item_normal_background_background&quot;:&quot;classic&quot;,&quot;item_hover_background_background&quot;:&quot;classic&quot;,&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:&quot;100&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-button.default">
				<div class="elementor-widget-container">
					<div class="wdt-button-holder wdt-template-filled wdt-button-link wdt-button-style-default wdt-button-size-nm wdt-animation- wdt-button-icon-after" id="wdt-button-25e935e"><a class="wdt-button" href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#"><div class="wdt-button-text"><span>Explore all  Services</span></div></a></div>				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		                                    </div><!-- ** Container End ** -->
            </div><!-- **Main - End ** -->


            <!-- **Footer** -->
            <footer id="footer"><div class="wdt-elementor-container-fluid"><div id="footer-15854" class="wdt-footer-tpl footer-15854">		<div data-elementor-type="wp-post" data-elementor-id="15854" class="elementor elementor-15854">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-1112c9d elementor-section-full_width wdt-black-bg elementor-section-height-default elementor-section-height-default" data-id="1112c9d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-66a1009" data-id="66a1009" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2ed325f e-transform elementor-widget elementor-widget-spacer" data-id="2ed325f" data-element_type="widget" data-settings="{&quot;_transform_flipY_effect&quot;:&quot;transform&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
							<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-1c6bf5a wdt-black-bg elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1c6bf5a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-04c5b19" data-id="04c5b19" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-ff6f8d4 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="ff6f8d4" data-element_type="section" data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5504f3e" data-id="5504f3e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-fe3a6aa wdt-dark-bg elementor-widget-tablet__width-initial elementor-widget-mobile__width-inherit elementor-widget elementor-widget-wdt-heading" data-id="fe3a6aa" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-heading.default">
				<div class="elementor-widget-container">
					<div class="wdt-heading-holder " id="wdt-heading-fe3a6aa"><h2 class="wdt-heading-title-wrapper wdt-heading-align- wdt-heading-deco-wrapper"><span class="wdt-heading-title">Consistent Maintenance, Gorgeous Results</span></h2></div>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-a4f3561" data-id="a4f3561" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-7b165e4 wdt-cus-footer-iconbox wdt-dark-bg elementor-widget-mobile__width-initial elementor-widget elementor-widget-wdt-advanced-slider" data-id="7b165e4" data-element_type="widget" data-settings="{&quot;columns&quot;:&quot;3&quot;,&quot;columns_tablet&quot;:&quot;3&quot;,&quot;columns_mobile_extra&quot;:&quot;2&quot;,&quot;columns_laptop&quot;:2,&quot;columns_tablet_extra&quot;:2,&quot;columns_mobile&quot;:1,&quot;carousel_arrows_prev_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-advanced-slider.default">
				<div class="elementor-widget-container">
					<div class="wdt-specifications-holder wdt-content-item-holder wdt-column-holder " id="wdt-specifications-7b165e4" data-settings=""><div class="wdt-column-wrapper wdt-column-gap-default wdt-snap-scroll-enabled" data-column-settings="{&quot;columnDevices&quot;:[&quot;mobile_extra&quot;,&quot;mobile&quot;]}" data-module-id="wdt-module-id-7b165e4" id="wdt-module-id-7b165e4"><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-advanced-slider-block"><div class="wdt-image-icon-group"><div class="wdt-content-icon-wrapper "><div class="wdt-content-icon"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/" class="silde_pop_vid"><span><i><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><path d="M48.1,5C29.1,6,14,21.3,14,40c0,7.9,2.7,15.2,7.2,21h0l24.4,31.8c2.2,2.9,6.6,2.9,8.8,0L78.8,61h0 c4.2-5.4,6.8-11.9,7.2-19.1C87.1,21.2,69.4,4,48.1,5z M74,41c0,13.3-10.7,24-24,24S26,54.3,26,41s10.7-24,24-24S74,27.7,74,41z"></path></svg></i></span></a></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-description"><p>No: 58 A, East Madison</p><p>Street, MD, USA 4508</p></div></div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-advanced-slider-block"><div class="wdt-image-icon-group"><div class="wdt-content-icon-wrapper "><div class="wdt-content-icon"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/" class="silde_pop_vid"><span><i><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 120 120" style="enable-background:new 0 0 120 120;" xml:space="preserve"><path d="M46.4,55.1C46.4,55.1,46.4,55.1,46.4,55.1L46.4,55.1C46.5,55.2,46.5,55.2,46.4,55.1 C46.5,55.2,46.5,55.2,46.4,55.1l4.5,4.1c5.2,4.7,13.1,4.7,18.2,0l4.2-3.8l0.5-0.5l38.4-35.1c0.3-0.3,0.1-0.7-0.3-0.7H8 c-0.4,0-0.5,0.5-0.3,0.7L46.4,55.1C46.4,55.1,46.4,55.1,46.4,55.1C46.4,55.1,46.4,55.1,46.4,55.1C46.4,55.1,46.4,55.1,46.4,55.1z"></path><path d="M1.7,25.8C1.4,25.5,1,25.7,1,26.1v67.8c0,0.4,0.4,0.5,0.7,0.3l23.4-23.8c6.6-6.8,6.3-17.7-0.7-24L1.7,25.8z"></path><path d="M62.5,74.2C62.5,74.2,62.5,74.2,62.5,74.2c-0.7,0.7-1.6,1-2.5,1c-0.9,0-1.8-0.3-2.5-1l-9-8.5 c-2.4-2.3-6.3-2.2-8.5,0.3L7.7,100.1c-0.3,0.3-0.1,0.7,0.3,0.7H112c0.4,0,0.6-0.5,0.3-0.7L80.1,65.9c-2.3-2.4-6.1-2.5-8.5-0.3 L62.5,74.2C62.5,74.2,62.5,74.2,62.5,74.2z"></path><path d="M118.9,25.2C118.9,25.2,118.9,25.2,118.9,25.2L93.1,48.6c-5.7,5.1-5.9,13.9-0.6,19.4l25.8,26.2 c0.3,0.3,0.7,0.1,0.7-0.3V26.1C119,25.8,119,25.5,118.9,25.2C118.9,25.2,118.9,25.2,118.9,25.2z"></path></svg></i></span></a></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-button-group"><div class="wdt-content-button wdt-button-clone"><a href="mailto:info@example.com"><div class="wdt-button-text"><span>info@example.com</span></div></a></div><div class="wdt-content-button wdt-button-clone"><a href="mailto:contact@example.com"><div class="wdt-button-text"><span>contact@example.com</span></div></a></div></div></div></div></div></div><div class="wdt-column"><div class="wdt-content-item"><div class="wdt-advanced-slider-block"><div class="wdt-image-icon-group"><div class="wdt-content-icon-wrapper "><div class="wdt-content-icon"><a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/" class="silde_pop_vid"><span><i><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 120 120" style="enable-background:new 0 0 120 120;" xml:space="preserve"><path d="M115.8,108c4.8-4.8,4.2-12.8-1.4-16.8l-19.1-14c-4.4-3.3-10.6-2.8-14.4,1l-3.3,3.3c-0.4,0.4-0.8,0.7-1.2,1 c-1.6,1.6-3.9,2.1-6,1.3c-16.6-6.3-28-17.8-34.4-34.4c-0.8-2.1-0.3-4.4,1.3-6l0.6-0.6c0.1-0.2,0.3-0.3,0.4-0.5l3.3-3.3 c3.9-3.9,4.3-10,1.1-14.4l-14-19.1c-4-5.5-12-6.2-16.8-1.4L8.6,7.6c-3.9,3.9-6.4,8.8-7.2,14.2c-0.1,0.7-0.2,1.5-0.2,2.2 C0.2,37.2,5,51.2,14.7,66.2c0.3,0.5,0.7,1,1,1.5c9.7,14.5,22.2,26.9,36.6,36.6c0.5,0.3,1,0.6,1.4,0.9c15,9.7,29.1,14.5,42.2,13.6 c0.7,0,1.5-0.1,2.2-0.2c5.4-0.8,10.3-3.4,14.2-7.2L115.8,108L115.8,108z"></path><path d="M119,57.2c-1.1-14.5-7.4-28.2-17.7-38.5C91,8.4,77.3,2.1,62.8,1c-2.2-0.2-4.1,1.5-4.3,3.7 C58.3,6.9,60,8.8,62.2,9c12.6,0.9,24.5,6.4,33.5,15.3c9,9,14.4,20.8,15.3,33.5c0.2,2.1,1.9,3.7,4,3.7c0.1,0,0.2,0,0.3,0 C117.5,61.3,119.2,59.4,119,57.2L119,57.2z"></path><path d="M86.4,36.6C80.1,30.3,72,26.4,63.2,25.2c-2.3-0.3-4.4,1.3-4.6,3.6c-0.3,2.3,1.3,4.4,3.6,4.6 c7,0.9,13.4,4,18.4,9c5,5,8.1,11.4,9,18.4c0.3,2.1,2.1,3.6,4.1,3.6c0.2,0,0.4,0,0.5,0c2.3-0.3,3.9-2.4,3.6-4.6 C96.7,51,92.7,43,86.4,36.6L86.4,36.6z"></path></svg></i></span></a></div></div></div><div class="wdt-content-detail-group"><div class="wdt-content-button-group"><div class="wdt-content-button wdt-button-clone"><a href="tel:(+00)%20123%20456%20789"><div class="wdt-button-text"><span>(+00) 123 456 789</span></div></a></div><div class="wdt-content-button wdt-button-clone"><a href="tel:(+000)%20-%20123%20-%20456%20-%20789"><div class="wdt-button-text"><span>(+000) - 123 - 456 - 789</span></div></a></div></div></div></div></div></div></div><div class="wdt-column-pagination wdt-snap-scroll-pagination">
						<button class="wdt-pagination-prev wdt-module-id-7b165e4 disabled" style="cursor: not-allowed;">Previous</button>
						<button class="wdt-pagination-next wdt-module-id-7b165e4 disabled" style="cursor: not-allowed;">Next</button></div></div>				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-4c3b952 wdt-dark-bg wdt-section-wrap-col elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="4c3b952" data-element_type="section" data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-be77a71" data-id="be77a71" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-394fb59 elementor-widget elementor-widget-wdt-logo" data-id="394fb59" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-logo.default">
				<div class="elementor-widget-container">
					<div id="grassroot-394fb59" class="wdt-logo-container">  <a href="https://wdtgrassroot.wpengine.com/rtl-demo/" rel="home"><img loading="lazy" src="./Services – RTL GrassRoot Site_files/Light-Logo.png" alt="RTL GrassRoot Site" width="350" height="80"></a></div>				</div>
				</div>
				<div class="elementor-element elementor-element-20c16b4 elementor-widget elementor-widget-wdt-heading" data-id="20c16b4" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-heading.default">
				<div class="elementor-widget-container">
					<div class="wdt-heading-holder " id="wdt-heading-20c16b4"><div class="wdt-heading-content-wrapper">Arcu fermentum dolor posuere non morbi egestas nisl aliquet gravida.</div></div>				</div>
				</div>
				<div class="elementor-element elementor-element-0a7afe2 elementor-icon-list--layout-inline wdt-header-icon-social-style wdt-footer-socials elementor-list-item-link-inline elementor-mobile_extra-align-right elementor-widget-mobile_extra__width-inherit elementor-widget elementor-widget-icon-list" data-id="0a7afe2" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items elementor-inline-items">
							<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://www.facebook.com/">

												<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-facebook-f" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg"><path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"></path></svg>						</span>
										<span class="elementor-icon-list-text"></span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://twitter.com/login">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve"><path d="M0.7,3.7L39,54.8L0.5,96.3h8.7L42.8,60L70,96.3h29.5l-40.4-54L94.9,3.7h-8.7l-31,33.5L30.2,3.7H0.7z M13.5,10H27L86.8,90 H73.2L13.5,10z"></path></svg>						</span>
										<span class="elementor-icon-list-text"></span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://in.linkedin.com/">

												<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-youtube" viewBox="0 0 576 512" xmlns="http://www.w3.org/2000/svg"><path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"></path></svg>						</span>
										<span class="elementor-icon-list-text"></span>
											</a>
									</li>
								<li class="elementor-icon-list-item elementor-inline-item">
											<a href="https://www.google.com/">

												<span class="elementor-icon-list-icon">
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 120 120" style="enable-background:new 0 0 120 120;" xml:space="preserve"><path d="M84.9,1H35.1C16.3,1,1,16.3,1,35.1v49.9C1,103.7,16.3,119,35.1,119h49.9c18.8,0,34.1-15.3,34.1-34.1V35.1 C119,16.3,103.8,1,84.9,1z M108.1,85.8c0,12.5-10.1,22.6-22.6,22.6h-51c-12.5,0-22.6-10.1-22.6-22.6v-51c0-12.5,10.1-22.6,22.6-22.6 h51c12.5,0,22.6,10.1,22.6,22.6V85.8z"></path><path d="M58,28.5c-16.3,0-29.5,13.2-29.5,29.5S41.7,87.5,58,87.5S87.5,74.3,87.5,58S74.3,28.5,58,28.5z M58,77.2 c-10.6,0-19.1-8.6-19.1-19.1S47.5,38.9,58,38.9S77.2,47.5,77.2,58S68.6,77.2,58,77.2z"></path><path d="M87.5,20.7c-4.3,0-7.9,3.5-7.9,7.9s3.5,7.9,7.9,7.9s7.9-3.5,7.9-7.9S91.9,20.7,87.5,20.7z"></path></svg>						</span>
										<span class="elementor-icon-list-text"></span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-0fc9044" data-id="0fc9044" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-dc87ddb elementor-widget elementor-widget-wdt-heading" data-id="dc87ddb" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-heading.default">
				<div class="elementor-widget-container">
					<div class="wdt-heading-holder " id="wdt-heading-dc87ddb"><h4 class="wdt-heading-title-wrapper wdt-heading-align- wdt-heading-deco-wrapper"><span class="wdt-heading-title">Instagram</span></h4></div>				</div>
				</div>
				<div class="elementor-element elementor-element-9ee7309 gallery-spacing-custom wdt-cus-footer-gallery elementor-widget elementor-widget-image-gallery" data-id="9ee7309" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="image-gallery.default">
				<div class="elementor-widget-container">
							<div class="elementor-image-gallery">
			<div id="gallery-1" class="gallery galleryid-15720 gallery-columns-3 gallery-size-full"><figure class="gallery-item">
			<div class="gallery-icon landscape">
				<a data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="9ee7309" data-elementor-lightbox-title="footer-gallery-img-1" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NTcsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctMS5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D" href="./Services – RTL GrassRoot Site_files/footer-gallery-img-1.jpg"><img loading="lazy" width="800" height="800" src="./Services – RTL GrassRoot Site_files/footer-gallery-img-1.jpg" class="attachment-full size-full" alt="" decoding="async" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-1.jpg 800w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-1-300x300.jpg 300w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-1-150x150.jpg 150w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-1-768x768.jpg 768w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-1-100x100.jpg 100w" sizes="(max-width: 800px) 100vw, 800px"></a>
			</div></figure><figure class="gallery-item">
			<div class="gallery-icon landscape">
				<a data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="9ee7309" data-elementor-lightbox-title="footer-gallery-img-2" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NTgsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctMi5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D" href="./Services – RTL GrassRoot Site_files/footer-gallery-img-2.jpg"><img loading="lazy" width="800" height="800" src="./Services – RTL GrassRoot Site_files/footer-gallery-img-2.jpg" class="attachment-full size-full" alt="" decoding="async" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-2.jpg 800w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-2-300x300.jpg 300w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-2-150x150.jpg 150w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-2-768x768.jpg 768w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-2-100x100.jpg 100w" sizes="(max-width: 800px) 100vw, 800px"></a>
			</div></figure><figure class="gallery-item">
			<div class="gallery-icon landscape">
				<a data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="9ee7309" data-elementor-lightbox-title="footer-gallery-img-3" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NTksInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctMy5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D" href="./Services – RTL GrassRoot Site_files/footer-gallery-img-3.jpg"><img loading="lazy" width="800" height="800" src="./Services – RTL GrassRoot Site_files/footer-gallery-img-3.jpg" class="attachment-full size-full" alt="" decoding="async" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-3.jpg 800w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-3-300x300.jpg 300w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-3-150x150.jpg 150w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-3-768x768.jpg 768w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-3-100x100.jpg 100w" sizes="(max-width: 800px) 100vw, 800px"></a>
			</div></figure><figure class="gallery-item">
			<div class="gallery-icon landscape">
				<a data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="9ee7309" data-elementor-lightbox-title="footer-gallery-img-4" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NjAsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctNC5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D" href="./Services – RTL GrassRoot Site_files/footer-gallery-img-4.jpg"><img loading="lazy" width="800" height="800" src="./Services – RTL GrassRoot Site_files/footer-gallery-img-4.jpg" class="attachment-full size-full" alt="" decoding="async" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-4.jpg 800w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-4-300x300.jpg 300w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-4-150x150.jpg 150w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-4-768x768.jpg 768w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-4-100x100.jpg 100w" sizes="(max-width: 800px) 100vw, 800px"></a>
			</div></figure><figure class="gallery-item">
			<div class="gallery-icon landscape">
				<a data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="9ee7309" data-elementor-lightbox-title="footer-gallery-img-5" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NjEsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctNS5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D" href="./Services – RTL GrassRoot Site_files/footer-gallery-img-5.jpg"><img loading="lazy" width="800" height="800" src="./Services – RTL GrassRoot Site_files/footer-gallery-img-5.jpg" class="attachment-full size-full" alt="" decoding="async" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-5.jpg 800w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-5-300x300.jpg 300w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-5-150x150.jpg 150w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-5-768x768.jpg 768w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-5-100x100.jpg 100w" sizes="(max-width: 800px) 100vw, 800px"></a>
			</div></figure><figure class="gallery-item">
			<div class="gallery-icon landscape">
				<a data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="9ee7309" data-elementor-lightbox-title="footer-gallery-img-6" data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NjIsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctNi5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D" href="./Services – RTL GrassRoot Site_files/footer-gallery-img-6.jpg"><img loading="lazy" width="800" height="800" src="./Services – RTL GrassRoot Site_files/footer-gallery-img-6.jpg" class="attachment-full size-full" alt="" decoding="async" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-6.jpg 800w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-6-300x300.jpg 300w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-6-150x150.jpg 150w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-6-768x768.jpg 768w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-gallery-img-6-100x100.jpg 100w" sizes="(max-width: 800px) 100vw, 800px"></a>
			</div></figure>
		</div>
		</div>
						</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-7352c06" data-id="7352c06" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-4786dd5 elementor-widget elementor-widget-wdt-accordion-and-toggle" data-id="4786dd5" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-accordion-and-toggle.default">
				<div class="elementor-widget-container">
					<div class="wdt-accordion-toggle-holder wdt-module-toggle wdt-template-default wdt-expand-collapse-position-end accordion ui-accordion ui-accordion-icons ui-widget ui-helper-reset" id="wdt-accordion-and-toggle-4786dd5"><div class="wdt-accordion-toggle-wrapper"><div class="wdt-accordion-toggle-title-holder ui-accordion-header ui-state-default ui-corner-top ui-corner-bottom"><div class="wdt-accordion-toggle-title">Our Services</div><div class="wdt-accordion-toggle-icon"><div class="wdt-accordion-toggle-icon-expand"><svg aria-hidden="true" class="e-font-icon-svg e-fas-plus" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z"></path></svg></div><div class="wdt-accordion-toggle-icon-collapse"><svg aria-hidden="true" class="e-font-icon-svg e-fas-minus" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M416 208H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h384c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z"></path></svg></div></div></div><div class="wdt-accordion-toggle-description ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" style="display: none;"><style>.elementor-widget-icon-list .elementor-icon-list-item:not(:last-child):after{border-color:var( --e-global-color-text );}.elementor-widget-icon-list .elementor-icon-list-icon i{color:var( --e-global-color-primary );}.elementor-widget-icon-list .elementor-icon-list-icon svg{fill:var( --e-global-color-primary );}.elementor-widget-icon-list .elementor-icon-list-item > .elementor-icon-list-text, .elementor-widget-icon-list .elementor-icon-list-item > a{font-family:var( --e-global-typography-text-font-family ), Sans-serif;font-weight:var( --e-global-typography-text-font-weight );line-height:var( --e-global-typography-text-line-height );}.elementor-widget-icon-list .elementor-icon-list-text{color:var( --e-global-color-secondary );}.elementor-15851 .elementor-element.elementor-element-9d93d7b .elementor-icon-list-icon i{transition:color 0.3s;}.elementor-15851 .elementor-element.elementor-element-9d93d7b .elementor-icon-list-icon svg{transition:fill 0.3s;}.elementor-15851 .elementor-element.elementor-element-9d93d7b{--e-icon-list-icon-size:14px;--icon-vertical-offset:0px;}.elementor-15851 .elementor-element.elementor-element-9d93d7b .elementor-icon-list-text{transition:color 0.3s;}@media(max-width:1540px){.elementor-widget-icon-list .elementor-icon-list-item > .elementor-icon-list-text, .elementor-widget-icon-list .elementor-icon-list-item > a{line-height:var( --e-global-typography-text-line-height );}}@media(max-width:1024px){.elementor-widget-icon-list .elementor-icon-list-item > .elementor-icon-list-text, .elementor-widget-icon-list .elementor-icon-list-item > a{line-height:var( --e-global-typography-text-line-height );}}@media(max-width:479px){.elementor-widget-icon-list .elementor-icon-list-item > .elementor-icon-list-text, .elementor-widget-icon-list .elementor-icon-list-item > a{line-height:var( --e-global-typography-text-line-height );}}</style>		<div data-elementor-type="section" data-elementor-id="15851" class="elementor elementor-15851">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-1f1e026 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="1f1e026" data-element_type="section" data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a13fd5" data-id="5a13fd5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9d93d7b elementor-list-item-link-inline elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="9d93d7b" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Landscape Design</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Planting Services </span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Irrigation Systems</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Tree Care</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Soil Preparation</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div></div></div>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-609698a" data-id="609698a" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-415c5ac elementor-widget elementor-widget-wdt-accordion-and-toggle" data-id="415c5ac" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-accordion-and-toggle.default">
				<div class="elementor-widget-container">
					<div class="wdt-accordion-toggle-holder wdt-module-toggle wdt-template-default wdt-expand-collapse-position-end accordion ui-accordion ui-accordion-icons ui-widget ui-helper-reset" id="wdt-accordion-and-toggle-415c5ac"><div class="wdt-accordion-toggle-wrapper"><div class="wdt-accordion-toggle-title-holder ui-accordion-header ui-state-default ui-corner-top ui-corner-bottom"><div class="wdt-accordion-toggle-title">Quick Links</div><div class="wdt-accordion-toggle-icon"><div class="wdt-accordion-toggle-icon-expand"><svg aria-hidden="true" class="e-font-icon-svg e-fas-plus" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z"></path></svg></div><div class="wdt-accordion-toggle-icon-collapse"><svg aria-hidden="true" class="e-font-icon-svg e-fas-minus" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M416 208H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h384c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z"></path></svg></div></div></div><div class="wdt-accordion-toggle-description ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom" style="display: none;"><style>.elementor-widget-icon-list .elementor-icon-list-item:not(:last-child):after{border-color:var( --e-global-color-text );}.elementor-widget-icon-list .elementor-icon-list-icon i{color:var( --e-global-color-primary );}.elementor-widget-icon-list .elementor-icon-list-icon svg{fill:var( --e-global-color-primary );}.elementor-widget-icon-list .elementor-icon-list-item > .elementor-icon-list-text, .elementor-widget-icon-list .elementor-icon-list-item > a{font-family:var( --e-global-typography-text-font-family ), Sans-serif;font-weight:var( --e-global-typography-text-font-weight );line-height:var( --e-global-typography-text-line-height );}.elementor-widget-icon-list .elementor-icon-list-text{color:var( --e-global-color-secondary );}.elementor-15852 .elementor-element.elementor-element-7dd0c1b .elementor-icon-list-icon i{transition:color 0.3s;}.elementor-15852 .elementor-element.elementor-element-7dd0c1b .elementor-icon-list-icon svg{transition:fill 0.3s;}.elementor-15852 .elementor-element.elementor-element-7dd0c1b{--e-icon-list-icon-size:14px;--icon-vertical-offset:0px;}.elementor-15852 .elementor-element.elementor-element-7dd0c1b .elementor-icon-list-text{transition:color 0.3s;}@media(max-width:1540px){.elementor-widget-icon-list .elementor-icon-list-item > .elementor-icon-list-text, .elementor-widget-icon-list .elementor-icon-list-item > a{line-height:var( --e-global-typography-text-line-height );}}@media(max-width:1024px){.elementor-widget-icon-list .elementor-icon-list-item > .elementor-icon-list-text, .elementor-widget-icon-list .elementor-icon-list-item > a{line-height:var( --e-global-typography-text-line-height );}}@media(max-width:479px){.elementor-widget-icon-list .elementor-icon-list-item > .elementor-icon-list-text, .elementor-widget-icon-list .elementor-icon-list-item > a{line-height:var( --e-global-typography-text-line-height );}}</style>		<div data-elementor-type="section" data-elementor-id="15852" class="elementor elementor-15852">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-a90fb6d elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="a90fb6d" data-element_type="section" data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0f5e8a1" data-id="0f5e8a1" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-7dd0c1b elementor-list-item-link-inline elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="7dd0c1b" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Stay Connected</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Special Offers</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Returns &amp; Refunds</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Track Your Order</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">News &amp; Trends</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">

											<span class="elementor-icon-list-text">Affiliate Program</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div></div></div>				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-4375aec" data-id="4375aec" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-aaab735 elementor-widget elementor-widget-wdt-heading" data-id="aaab735" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-heading.default">
				<div class="elementor-widget-container">
					<div class="wdt-heading-holder " id="wdt-heading-aaab735"><h4 class="wdt-heading-title-wrapper wdt-heading-align- wdt-heading-deco-wrapper"><span class="wdt-heading-title">Subscribe Newsletter</span></h4></div>				</div>
				</div>
				<div class="elementor-element elementor-element-40f0e95 elementor-widget-tablet_extra__width-initial elementor-widget elementor-widget-wdt-mailchimp" data-id="40f0e95" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="wdt-mailchimp.default">
				<div class="elementor-widget-container">
					<div class="wdt-mailchimp-holder wdt-template-type5" id="wdt-mailchimp-40f0e95"><div class="wdt-mailchimp-wrapper"><form class="wdt-mailchimp-subscribe-form with-btn-icon" name="mailchimpSubscribeForm" action="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" method="post"><input type="email" name="wdt_mc_emailid" required="required" placeholder="Your Email*" value=""><input type="hidden" name="wdt_mc_apikey" value=""><input type="hidden" name="wdt_mc_listid" value=""><div class="wdt-mailchimp-subscription-button-holder"><button type="submit" name="wdt_mc_submit"><svg aria-hidden="true" class="e-font-icon-svg e-far-paper-plane" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M440 6.5L24 246.4c-34.4 19.9-31.1 70.8 5.7 85.9L144 379.6V464c0 46.4 59.2 65.5 86.6 28.6l43.8-59.1 111.9 46.2c5.9 2.4 12.1 3.6 18.3 3.6 8.2 0 16.3-2.1 23.6-6.2 12.8-7.2 21.6-20 23.9-34.5l59.4-387.2c6.1-40.1-36.9-68.8-71.5-48.9zM192 464v-64.6l36.6 15.1L192 464zm212.6-28.7l-153.8-63.5L391 169.5c10.7-15.5-9.5-33.5-23.7-21.2L155.8 332.6 48 288 464 48l-59.4 387.3z"></path></svg></button></div><div><input type="checkbox" class="wdt-terms-and-conditions" required="required"><span class="wdt-terms-condition-lbl">I agree with the Terms and Conditions</span></div></form><div class="wdt-mailchimp-subscription-msg"></div></div></div>				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-1dfcbbe elementor-section-content-middle wdt-dark-bg wdt-section-wrap-col elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="1dfcbbe" data-element_type="section" data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
						<div class="elementor-container elementor-column-gap-no">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1eb0f08" data-id="1eb0f08" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-6d42fed wdt-dark-bg elementor-widget-mobile_extra__width-auto elementor-widget elementor-widget-text-editor" data-id="6d42fed" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<p>© 2025 &nbsp;<a href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#">Grassroot</a>&nbsp; Design Themes</p>								</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5519fab" data-id="5519fab" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-26d22a4 elementor-widget__width-auto elementor-widget elementor-widget-image" data-id="26d22a4" data-element_type="widget" data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img loading="lazy" width="684" height="60" src="./Services – RTL GrassRoot Site_files/footer-payment.png" class="attachment-full size-full wp-image-16391" alt="" srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-payment.png 684w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-payment-300x26.png 300w" sizes="(max-width: 684px) 100vw, 684px">															</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div></div></footer>            <!-- **Footer - End** -->
        </div><!-- **Inner Wrapper - End** -->

    </div><!-- **Wrapper - End** -->

    <script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/rtl-demo\/*"},{"not":{"href_matches":["\/rtl-demo\/wp-*.php","\/rtl-demo\/wp-admin\/*","\/rtl-demo\/wp-content\/uploads\/sites\/3\/*","\/rtl-demo\/wp-content\/*","\/rtl-demo\/wp-content\/plugins\/*","\/rtl-demo\/wp-content\/themes\/grassroot\/*","\/rtl-demo\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
				<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel="stylesheet" id="wc-blocks-style-rtl-css" href="./Services – RTL GrassRoot Site_files/wc-blocks-rtl.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-11-css" href="./Services – RTL GrassRoot Site_files/post-11.css" type="text/css" media="all">
<link rel="stylesheet" id="widget-icon-list-css" href="./Services – RTL GrassRoot Site_files/custom-widget-icon-list-rtl.min.css" type="text/css" media="all">
<link rel="stylesheet" id="e-animation-fadeInDown-css" href="./Services – RTL GrassRoot Site_files/fadeInDown.min.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-logo-css" href="./Services – RTL GrassRoot Site_files/logo.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-header-icons-css" href="./Services – RTL GrassRoot Site_files/header-icons.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-header-carticons-css" href="./Services – RTL GrassRoot Site_files/header-carticon.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-heading-css" href="./Services – RTL GrassRoot Site_files/style(3).css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-button-css" href="./Services – RTL GrassRoot Site_files/style(4).css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-repeater-content-css" href="./Services – RTL GrassRoot Site_files/style(5).css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-image-box-css" href="./Services – RTL GrassRoot Site_files/style(6).css" type="text/css" media="all">
<style id="wdt-image-box-inline-css" type="text/css">

@media only screen and (min-width: 480px) {
#wdt-image-box-00387ec .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 33.33%;
}
}

@media only screen and (min-width: 480px) {
#wdt-image-box-00387ec .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 33.33%;
}
}

@media only screen and (max-width: 1540px) {
#wdt-image-box-00387ec .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 33.33%;
}
}

@media only screen and (max-width: 1280px) {
#wdt-image-box-00387ec .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 33.33%;
}
}

@media only screen and (max-width: 1024px) {
#wdt-image-box-00387ec .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 50%;
}
}

@media only screen and (max-width: 767px) {
#wdt-image-box-00387ec .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 100%;
}
}

@media only screen and (max-width: 479px) {
#wdt-image-box-00387ec .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 100%;
}
}

@media only screen and (max-width: 1540px) {
#wdt-image-box-00387ec .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 33.33%;
}
}

@media only screen and (max-width: 1280px) {
#wdt-image-box-00387ec .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 33.33%;
}
}

@media only screen and (max-width: 1024px) {
#wdt-image-box-00387ec .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 50%;
}
}

@media only screen and (max-width: 767px) {
#wdt-image-box-00387ec .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 100%;
}
}

@media only screen and (max-width: 479px) {
#wdt-image-box-00387ec .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 100%;
}
}


@media only screen and (min-width: 480px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 25%;
}
}

@media only screen and (min-width: 480px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 25%;
}
}

@media only screen and (max-width: 1540px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 25%;
}
}

@media only screen and (max-width: 1280px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 33.33%;
}
}

@media only screen and (max-width: 1024px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 50%;
}
}

@media only screen and (max-width: 767px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 100%;
}
}

@media only screen and (max-width: 479px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 100%;
}
}

@media only screen and (max-width: 1540px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 25%;
}
}

@media only screen and (max-width: 1280px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 33.33%;
}
}

@media only screen and (max-width: 1024px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 50%;
}
}

@media only screen and (max-width: 767px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 100%;
}
}

@media only screen and (max-width: 479px) {
#wdt-image-box-773cbc4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 100%;
}
}

</style>
<link rel="stylesheet" id="jquery.magnific-image-box-popup-css" href="./Services – RTL GrassRoot Site_files/jquery.magnific-popup.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-column-css" href="./Services – RTL GrassRoot Site_files/column.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-testimonial-css" href="./Services – RTL GrassRoot Site_files/style(7).css" type="text/css" media="all">
<link rel="stylesheet" id="jquery-swiper-css" href="./Services – RTL GrassRoot Site_files/swiper(1).min.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-carousel-css" href="./Services – RTL GrassRoot Site_files/carousel.css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-15854-css" href="./Services – RTL GrassRoot Site_files/post-15854.css" type="text/css" media="all">
<link rel="stylesheet" id="e-swiper-css" href="./Services – RTL GrassRoot Site_files/e-swiper.min.css" type="text/css" media="all">
<link rel="stylesheet" id="widget-image-gallery-css" href="./Services – RTL GrassRoot Site_files/custom-widget-image-gallery-rtl.min.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-advanced-slider-css" href="./Services – RTL GrassRoot Site_files/style(8).css" type="text/css" media="all">
<style id="wdt-advanced-slider-inline-css" type="text/css">

@media only screen and (min-width: 480px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 33.33%;
}
}

@media only screen and (min-width: 480px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 33.33%;
}
}

@media only screen and (max-width: 1540px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 50%;
}
}

@media only screen and (max-width: 1280px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 50%;
}
}

@media only screen and (max-width: 1024px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 33.33%;
}
}

@media only screen and (max-width: 767px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 50%;
}
}

@media only screen and (max-width: 479px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 100%;
}
}

@media only screen and (max-width: 1540px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 50%;
}
}

@media only screen and (max-width: 1280px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 50%;
}
}

@media only screen and (max-width: 1024px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 33.33%;
}
}

@media only screen and (max-width: 767px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 50%;
}
}

@media only screen and (max-width: 479px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 100%;
}
}


@media only screen and (min-width: 480px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 33.33%;
}
}

@media only screen and (min-width: 480px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 33.33%;
}
}

@media only screen and (max-width: 1540px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 50%;
}
}

@media only screen and (max-width: 1280px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 50%;
}
}

@media only screen and (max-width: 1024px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 33.33%;
}
}

@media only screen and (max-width: 767px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 50%;
}
}

@media only screen and (max-width: 479px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper:not(.wdt-snap-scroll-enabled) .wdt-column {
width: 100%;
}
}

@media only screen and (max-width: 1540px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 50%;
}
}

@media only screen and (max-width: 1280px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 50%;
}
}

@media only screen and (max-width: 1024px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 33.33%;
}
}

@media only screen and (max-width: 767px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 50%;
}
}

@media only screen and (max-width: 479px) {
#wdt-specifications-7b165e4 .wdt-column-wrapper.wdt-snap-scroll-enabled .wdt-column {
flex: 0 0 100%;
}
}

</style>
<link rel="stylesheet" id="elementor-post-15851-css" href="./Services – RTL GrassRoot Site_files/post-15851.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-accordion-and-toggle-css" href="./Services – RTL GrassRoot Site_files/style(9).css" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-15852-css" href="./Services – RTL GrassRoot Site_files/post-15852.css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-mailchimp-css" href="./Services – RTL GrassRoot Site_files/style(10).css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-elementor-sections-css" href="./Services – RTL GrassRoot Site_files/style(11).css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-elementor-widgets-css" href="./Services – RTL GrassRoot Site_files/style(12).css" type="text/css" media="all">
<link rel="stylesheet" id="wdt-e-animations-css" href="./Services – RTL GrassRoot Site_files/animations.min.css" type="text/css" media="all">
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/hooks.min.js.download" id="wp-hooks-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/i18n.min.js.download" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'rtl' ] } );
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/index.js.download" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-before">
/* <![CDATA[ */
var wpcf7 = {
    "api": {
        "root": "https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/index(1).js.download" id="contact-form-7-js"></script>
<script type="text/javascript" id="wdt-elementor-addon-core-js-extra">
/* <![CDATA[ */
var wdtElementorAddonGlobals = {"ajaxUrl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/core.js.download" id="wdt-elementor-addon-core-js"></script>
<script type="text/javascript" id="wc-cart-fragments-js-extra">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/rtl-demo\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/rtl-demo\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_0e876cfb1b849e7a49d1400c965b3fa0","fragment_name":"wc_fragments_0e876cfb1b849e7a49d1400c965b3fa0","request_timeout":"5000"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/cart-fragments.min.js.download" id="wc-cart-fragments-js" data-wp-strategy="defer"></script>
<script type="text/javascript" id="tinvwl-js-extra">
/* <![CDATA[ */
var tinvwl_add_to_wishlist = {"text_create":"Create New","text_already_in":"{product_name} already in {wishlist_title}","simple_flow":"","hide_zero_counter":"","i18n_make_a_selection_text":"Please select some product options before adding this product to your wishlist.","tinvwl_break_submit":"No items or actions are selected.","tinvwl_clipboard":"Copied!","allow_parent_variable":"","block_ajax_wishlists_data":"","update_wishlists_data":"","hash_key":"ti_wishlist_data_0e876cfb1b849e7a49d1400c965b3fa0","nonce":"38d7083c2c","rest_root":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-json\/","plugin_url":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-content\/plugins\/ti-woocommerce-wishlist\/","wc_ajax_url":"\/rtl-demo\/?wc-ajax=tinvwl","stats":"","popup_timer":"6000"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/public.min.js.download" id="tinvwl-js"></script>
<script type="text/javascript" id="grassroot-jqcustom-js-extra">
/* <![CDATA[ */
var ajax_object = {"ajax_url":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php","ajax_nonce":"b540583d9d"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/custom.js.download" id="grassroot-jqcustom-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/swiper.min.js.download" id="jquery-swiper-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/isotope.pkgd.min.js.download" id="isotope-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/matchHeight.js.download" id="matchheight-js"></script>
<script type="text/javascript" id="wdt-common-js-extra">
/* <![CDATA[ */
var wdtcommonobject = {"ajaxurl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php","noResult":"No Results Found!"};
var wdtcommonobject = {"ajaxurl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php","noResult":"No Results Found!"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/common.js.download" id="wdt-common-js"></script>
<script type="text/javascript" id="wdt-frontend-js-extra">
/* <![CDATA[ */
var wdtfrontendobject = {"pluginFolderPath":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-content\/plugins\/","pluginPath":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-content\/plugins\/wedesigntech-portfolio\/","ajaxurl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php","purchased":"<p>Purchased<\/p>","somethingWentWrong":"<p>Something Went Wrong<\/p>","outputDivAlert":"Please make sure you have added output shortcode.","printerTitle":"Portfolio Printer","pleaseLogin":"Please login","noMorePosts":"No more posts to load!","elementorPreviewMode":"","primaryColor":"#1e306e","secondaryColor":"#2fa5fb","tertiaryColor":"#d2edf8"};
var wdtfrontendobject = {"pluginFolderPath":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-content\/plugins\/","pluginPath":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-content\/plugins\/wedesigntech-portfolio\/","ajaxurl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php","purchased":"<p>Purchased<\/p>","somethingWentWrong":"<p>Something Went Wrong<\/p>","outputDivAlert":"Please make sure you have added output shortcode.","printerTitle":"Portfolio Printer","pleaseLogin":"Please login","noMorePosts":"No more posts to load!","elementorPreviewMode":"","primaryColor":"#1e306e","secondaryColor":"#2fa5fb","tertiaryColor":"#d2edf8"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/frontend.js.download" id="wdt-frontend-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/sourcebuster.min.js.download" id="sourcebuster-js-js"></script>
<script type="text/javascript" id="wc-order-attribution-js-extra">
/* <![CDATA[ */
var wc_order_attribution = {"params":{"lifetime":1.0e-5,"session":30,"base64":false,"ajaxurl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php","prefix":"wc_order_attribution_","allowTracking":true},"fields":{"source_type":"current.typ","referrer":"current_add.rf","utm_campaign":"current.cmp","utm_source":"current.src","utm_medium":"current.mdm","utm_content":"current.cnt","utm_id":"current.id","utm_term":"current.trm","utm_source_platform":"current.plt","utm_creative_format":"current.fmt","utm_marketing_tactic":"current.tct","session_entry":"current_add.ep","session_start_time":"current_add.fd","session_pages":"session.pgs","session_count":"udata.vst","user_agent":"udata.uag"}};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/order-attribution.min.js.download" id="wc-order-attribution-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/frontend(1).js.download" id="wdt-social-share-frontend-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/core.min.js.download" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/mouse.min.js.download" id="jquery-ui-mouse-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/slider.min.js.download" id="jquery-ui-slider-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/chosen.jquery.min.js.download" id="chosen-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/datepicker.min.js.download" id="jquery-ui-datepicker-js"></script>
<script type="text/javascript" id="jquery-ui-datepicker-js-after">
/* <![CDATA[ */
jQuery(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"\u0625\u063a\u0644\u0627\u0642","currentText":"\u0627\u0644\u064a\u0648\u0645","monthNames":["\u064a\u0646\u0627\u064a\u0631","\u0641\u0628\u0631\u0627\u064a\u0631","\u0645\u0627\u0631\u0633","\u0623\u0628\u0631\u064a\u0644","\u0645\u0627\u064a\u0648","\u064a\u0648\u0646\u064a\u0648","\u064a\u0648\u0644\u064a\u0648","\u0623\u063a\u0633\u0637\u0633","\u0633\u0628\u062a\u0645\u0628\u0631","\u0623\u0643\u062a\u0648\u0628\u0631","\u0646\u0648\u0641\u0645\u0628\u0631","\u062f\u064a\u0633\u0645\u0628\u0631"],"monthNamesShort":["\u064a\u0646\u0627\u064a\u0631","\u0641\u0628\u0631\u0627\u064a\u0631","\u0645\u0627\u0631\u0633","\u0623\u0628\u0631\u064a\u0644","\u0645\u0627\u064a\u0648","\u064a\u0648\u0646\u064a\u0648","\u064a\u0648\u0644\u064a\u0648","\u0623\u063a\u0633\u0637\u0633","\u0633\u0628\u062a\u0645\u0628\u0631","\u0623\u0643\u062a\u0648\u0628\u0631","\u0646\u0648\u0641\u0645\u0628\u0631","\u062f\u064a\u0633\u0645\u0628\u0631"],"nextText":"\u0627\u0644\u062a\u0627\u0644\u064a","prevText":"\u0627\u0644\u0633\u0627\u0628\u0642","dayNames":["\u0627\u0644\u0623\u062d\u062f","\u0627\u0644\u0625\u062b\u0646\u064a\u0646","\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621","\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621","\u0627\u0644\u062e\u0645\u064a\u0633","\u0627\u0644\u062c\u0645\u0639\u0629","\u0627\u0644\u0633\u0628\u062a"],"dayNamesShort":["\u0627\u0644\u0623\u062d\u062f","\u0627\u0644\u0623\u062b\u0646\u064a\u0646","\u0627\u0644\u062b\u0644\u0627\u062b\u0627\u0621","\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621","\u0627\u0644\u062e\u0645\u064a\u0633","\u0627\u0644\u062c\u0645\u0639\u0629","\u0627\u0644\u0633\u0628\u062a"],"dayNamesMin":["\u062f","\u0646","\u062b","\u0623\u0631\u0628","\u062e","\u062c","\u0633"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":true});});
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/frontend(2).js.download" id="wdt-search-frontend-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/frontend(3).js.download" id="wdt-media-images-frontend-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/common(1).js.download" id="wdt-comments-common-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/single-page.js.download" id="wdt-modules-singlepage-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/frontend(4).js.download" id="wdt-comments-frontend-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/webpack.runtime.min.js.download" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/frontend-modules.min.js.download" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":true,"breakpoints":{"xs":0,"sm":480,"md":480,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":479,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":767,"default_value":880,"direction":"max","is_enabled":true},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1280,"default_value":1200,"direction":"max","is_enabled":true},"laptop":{"label":"Laptop","value":1540,"default_value":1366,"direction":"max","is_enabled":true},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},"hasCustomBreakpoints":true},"version":"3.30.0","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"e_element_cache":true,"home_screen":true,"global_classes_should_enforce_capabilities":true,"cloud-library":true,"e_opt_in_v4_page":true},"urls":{"assets":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-content\/uploads\/sites\/3"},"nonces":{"floatingButtonsClickTracking":"a5a75e1510"},"swiperClass":"swiper","settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_mobile_extra","viewport_tablet","viewport_tablet_extra","viewport_laptop"],"viewport_mobile":"479","viewport_mobile_extra":"767","viewport_tablet":"1024","viewport_tablet_extra":"1280","viewport_laptop":"1540","global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":2132,"title":"Services%20%E2%80%93%20RTL%20GrassRoot%20Site","excerpt":"","featuredImage":false}};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/frontend.min.js.download" id="elementor-frontend-js"></script><span id="elementor-device-mode" class="elementor-screen-only"></span>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/select2.full.js.download" id="jquery-select2-js"></script>
<script type="text/javascript" id="post-infinite-js-extra">
/* <![CDATA[ */
var grassroot_urls = {"ajaxurl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/post-infinite.js.download" id="post-infinite-js"></script>
<script type="text/javascript" id="post-loadmore-js-extra">
/* <![CDATA[ */
var grassroot_urls = {"ajaxurl":"https:\/\/wdtgrassroot.wpengine.com\/rtl-demo\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/post-loadmore.js.download" id="post-loadmore-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/mega-menu.js.download" id="dtplugin-mega-menu-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/script.js.download" id="grassroot-pro-auth-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/isotope.pkgd.js.download" id="isotope-pkgd-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.bxslider.js.download" id="jquery-bxslider-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.fitvids.js.download" id="jquery-fitvids-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.debouncedresize.js.download" id="jquery-debouncedresize-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.magnific-popup.min.js.download" id="jquery-magnific-popup-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.nicescroll.js.download" id="jquery-nicescroll-js"></script>
<script type="text/javascript" id="grassroot-woo-cart-notification-js-after">
/* <![CDATA[ */
jQuery.noConflict();

jQuery(document).ready(function($){
    "use strict";

    // After adding product to cart
    $('body').on('added_to_cart', function(e) {

        if($('.wdt-shop-cart-widget').hasClass('activate-sidebar-widget')) {

            $('.wdt-shop-cart-widget').addClass('wdt-shop-cart-widget-active');
            $('.wdt-shop-cart-widget-overlay').addClass('wdt-shop-cart-widget-active');

            // Nice scroll script

            var winHeight = $(window).height();
            var headerHeight = $('.wdt-shop-cart-widget-header').height();
            var footerHeight = $('.woocommerce-mini-cart-footer').height();

            var height = parseInt((winHeight-headerHeight-footerHeight), 10);

            $('.wdt-shop-cart-widget-content').height(height).niceScroll({ cursorcolor:"#000", cursorwidth: "5px", background:"rgba(20,20,20,0.3)", cursorborder:"none" });

        }

        if($('.wdt-shop-cart-widget').hasClass('cart-notification-widget')) {

            $('.wdt-shop-cart-widget').addClass('wdt-shop-cart-widget-active');
            $('.wdt-shop-cart-widget-overlay').addClass('wdt-shop-cart-widget-active');
            setTimeout( function(){
                $('.wdt-shop-cart-widget').removeClass('wdt-shop-cart-widget-active');
                $('.wdt-shop-cart-widget-overlay').removeClass('wdt-shop-cart-widget-active');
            }, 2400 );

        }

        e.preventDefault();
    });

    $('body').on('click', '.wdt-shop-cart-widget-close-button, .wdt-shop-cart-widget-overlay', function( e ) {
        $('.wdt-shop-cart-widget').removeClass('wdt-shop-cart-widget-active');
        $('.wdt-shop-cart-widget-overlay').removeClass('wdt-shop-cart-widget-active');
        e.preventDefault();
    });

});
/* ]]> */
</script>
<script type="text/javascript" id="grassroot-woo-quantity-plus-minus-js-after">
/* <![CDATA[ */
jQuery.noConflict();

jQuery(document).ready(function($){
    "use strict";

    // Quatity plus & minus button

        jQuery( 'body' ).delegate( '.quantity .plus, .quantity .minus', 'click', function(e) {

            var $qty        = $( this ).closest( '.quantity' ).find( '.qty'),
                currentVal  = parseFloat( $qty.val() ),
                max         = parseFloat( $qty.attr( 'max' ) ),
                min         = parseFloat( $qty.attr( 'min' ) ),
                step        = $qty.attr( 'step' );

            if ( ! currentVal || currentVal === '' || currentVal === 'NaN' ) currentVal = 0;
            if ( max === '' || max === 'NaN' ) max = '';
            if ( min === '' || min === 'NaN' ) min = 0;
            if ( step === 'any' || step === '' || step === undefined || parseFloat( step ) === 'NaN' ) step = '1';

            if ( $( this ).is( '.plus' ) ) {
                if ( max && ( currentVal >= max ) ) {
                    $qty.val( max );
                } else {
                    $qty.val( currentVal + parseFloat( step ) );
                }
            } else {
                if ( min && ( currentVal <= min ) ) {
                    $qty.val( min );
                } else if ( currentVal > 0 ) {
                    $qty.val( currentVal - parseFloat( step ) );
                }
            }

            $qty.trigger( 'change' );

            e.preventDefault();

        });


});
/* ]]> */
</script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/flatpickr.min.js.download" id="flatpickr-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/site-loader.js.download" id="site-loader-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/go-to-top.js.download" id="go-to-top-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/header-icons.js.download" id="wdt-header-icons-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.cookie.min.js.download" id="jquery.cookie-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/jquery.magnific-popup.min(1).js.download" id="jquery.magnific-image-box-popup-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/script(1).js.download" id="wdt-image-box-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/column.js.download" id="wdt-column-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/carousel.js.download" id="wdt-carousel-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/accordion.min.js.download" id="jquery-ui-accordion-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/script(2).js.download" id="wdt-accordion-and-toggle-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/script(3).js.download" id="wdt-mailchimp-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/script(4).js.download" id="wdt-elementor-sections-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/parallax-scroll.min.js.download" id="wdt-parallax-scroll-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/parallax.min.js.download" id="wdt-parallax-js"></script>
<script type="text/javascript" src="./Services – RTL GrassRoot Site_files/script(5).js.download" id="wdt-elementor-widgets-js"></script>
<a id="back-to-top" href="https://wdtgrassroot.wpengine.com/rtl-demo/services/#" style="display: inline;">
    <span id="back-to-top-hover"></span>
    <span class="back-to-top-icon" style="color: var(--wdtPrimaryColor);"><i>
<svg xmlns:xodm="http://www.corel.com/coreldraw/odm/2003" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 100 100" style="enable-background:new 0 0 100 100;" xml:space="preserve">
<g>
	<g>
		<path class="bts-leaf" d="M2.5,97.5c22,0.9,38.8-12.2,44.9-31.1c-3.9,6.3-11.3,9.5-21.4,7.5c-1.9-10,1.2-17.5,7.5-21.4C14.7,58.7,1.7,75.5,2.5,97.5
			z M33.6,47.5c-6.3-3.9-9.5-11.3-7.5-21.4c10-1.9,17.5,1.2,21.4,7.5C41.3,14.7,24.5,1.7,2.5,2.5C1.7,24.5,14.7,41.3,33.6,47.5z
			 M97.5,2.5c-22-0.9-38.8,12.2-44.9,31.1c3.9-6.3,11.3-9.5,21.4-7.5c1.9,10-1.2,17.5-7.5,21.4C85.3,41.3,98.3,24.5,97.5,2.5z
			 M52.5,66.4c6.1,18.9,22.9,31.9,44.9,31.1c0.9-22-12.2-38.8-31.1-44.9c6.3,3.9,9.5,11.3,7.5,21.4C63.9,75.8,56.4,72.7,52.5,66.4z"></path>
		<path class="bts-arrow" d="M39.1,49.8c-0.1-0.2-0.1-0.5-0.1-0.7s0-0.5,0.1-0.7c0.1-0.2,0.2-0.4,0.4-0.6l9.2-9.2c0.1-0.1,0.2-0.2,0.3-0.2
			c0,0,0.1,0,0.1-0.1c0,0,0,0,0,0l0,0c0,0,0.1-0.1,0.2-0.1c0.1,0,0.1,0,0.2,0l0,0c0,0,0,0,0,0c0,0,0.1,0,0.1,0c0.2,0,0.5,0,0.7,0
			c0,0,0.1,0,0.1,0c0,0,0,0,0,0l0,0c0,0,0.1,0,0.1,0c0.1,0,0.1,0,0.2,0.1l0,0l0,0c0,0,0.1,0,0.1,0.1c0.1,0.1,0.2,0.1,0.3,0.2
			l9.2,9.2c0.3,0.3,0.4,0.6,0.5,1c0.1,0.4,0,0.7-0.1,1.1c-0.1,0.3-0.4,0.6-0.7,0.8c-0.3,0.2-0.7,0.3-1,0.3c-0.2,0-0.5,0-0.7-0.1
			c-0.2-0.1-0.4-0.2-0.6-0.4l-6-6l0,15.7c0,0.5-0.2,1-0.5,1.3C51,61.8,50.5,62,50,62c-0.5,0-1-0.2-1.3-0.5c-0.4-0.3-0.5-0.8-0.5-1.3
			l0-15.7l-6,6c-0.2,0.2-0.4,0.3-0.6,0.4c-0.2,0.1-0.5,0.1-0.7,0.1c-0.2,0-0.5,0-0.7-0.1s-0.4-0.2-0.6-0.4
			C39.3,50.3,39.2,50.1,39.1,49.8z"></path>
	</g>
</g>
</svg>

</i></span>
</a>
<script src="./Services – RTL GrassRoot Site_files/dialog.min.js.download"></script><script src="./Services – RTL GrassRoot Site_files/share-link.min.js.download"></script><link rel="stylesheet" href="./Services – RTL GrassRoot Site_files/custom-lightbox.min.css"><div class="widget_shopping_cart_live_region screen-reader-text" role="status"></div><div class="wdt-search-form-container"><form method="get" id="searchform" action="https://wdtgrassroot.wpengine.com/rtl-demo/">
	<input id="s" name="s" type="text" value="" placeholder="Enter Keyword" class="text_input">
	<ul class="quick_search_results"></ul>
	<input type="hidden" id="search_security_nonce" name="search_security_nonce" value="b540583d9d">
	<input name="submit" type="submit" value="Go">
</form><div class="wdt-search-form-close"></div></div><div id="my-app"></div><svg style="display: none;" class="e-font-icon-svg-symbols"></svg></body></html>
