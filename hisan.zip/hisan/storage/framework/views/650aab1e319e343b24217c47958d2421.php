 <!-- ** Header Wrapper ** -->
 <div id="header-wrapper" class="header-top-absolute">

     <!-- **Header** -->
     <header id="header">
         <div class="wdt-elementor-container-fluid">
             <div id="header-11" class="wdt-header-tpl header-11">
                 <div data-elementor-type="wp-post" data-elementor-id="11" class="elementor elementor-11">
                     <section
                         class="elementor-section elementor-top-section elementor-element elementor-element-a8ca1b8 elementor-section-content-middle elementor-hidden-mobile_extra elementor-hidden-mobile animated-fast elementor-section-boxed elementor-section-height-default elementor-section-height-default animated fadeInDown"
                         data-id="a8ca1b8" data-element_type="section"
                         data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInDown&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                         <div class="elementor-container elementor-column-gap-no">
                             <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-f65aa08 elementor-hidden-tablet elementor-hidden-mobile_extra elementor-hidden-mobile"
                                 data-id="f65aa08" data-element_type="column">
                                 <div class="elementor-widget-wrap elementor-element-populated">
                                     <div class="elementor-element elementor-element-e1e858b elementor-icon-list--layout-inline elementor-widget__width-auto elementor-align-left elementor-mobile-align-left elementor-list-item-link-inline wdt-header-info-list elementor-tablet_extra-align-right elementor-widget elementor-widget-icon-list"
                                         data-id="e1e858b" data-element_type="widget"
                                         data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                         data-widget_type="icon-list.default">
                                         <div class="elementor-widget-container">
                                             <ul class="elementor-icon-list-items elementor-inline-items">
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <a href="tel:+966 50 555 7749">

                                                         <span class="elementor-icon-list-icon">
                                                             <svg xmlns="http://www.w3.org/2000/svg"
                                                                 xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
                                                                 y="0px" viewBox="0 0 120 120"
                                                                 style="enable-background:new 0 0 120 120;"
                                                                 xml:space="preserve">
                                                                 <path
                                                                     d="M115.8,108c4.8-4.8,4.2-12.8-1.4-16.8l-19.1-14c-4.4-3.3-10.6-2.8-14.4,1l-3.3,3.3c-0.4,0.4-0.8,0.7-1.2,1 c-1.6,1.6-3.9,2.1-6,1.3c-16.6-6.3-28-17.8-34.4-34.4c-0.8-2.1-0.3-4.4,1.3-6l0.6-0.6c0.1-0.2,0.3-0.3,0.4-0.5l3.3-3.3 c3.9-3.9,4.3-10,1.1-14.4l-14-19.1c-4-5.5-12-6.2-16.8-1.4L8.6,7.6c-3.9,3.9-6.4,8.8-7.2,14.2c-0.1,0.7-0.2,1.5-0.2,2.2 C0.2,37.2,5,51.2,14.7,66.2c0.3,0.5,0.7,1,1,1.5c9.7,14.5,22.2,26.9,36.6,36.6c0.5,0.3,1,0.6,1.4,0.9c15,9.7,29.1,14.5,42.2,13.6 c0.7,0,1.5-0.1,2.2-0.2c5.4-0.8,10.3-3.4,14.2-7.2L115.8,108L115.8,108z">
                                                                 </path>
                                                                 <path
                                                                     d="M119,57.2c-1.1-14.5-7.4-28.2-17.7-38.5C91,8.4,77.3,2.1,62.8,1c-2.2-0.2-4.1,1.5-4.3,3.7 C58.3,6.9,60,8.8,62.2,9c12.6,0.9,24.5,6.4,33.5,15.3c9,9,14.4,20.8,15.3,33.5c0.2,2.1,1.9,3.7,4,3.7c0.1,0,0.2,0,0.3,0 C117.5,61.3,119.2,59.4,119,57.2L119,57.2z">
                                                                 </path>
                                                                 <path
                                                                     d="M86.4,36.6C80.1,30.3,72,26.4,63.2,25.2c-2.3-0.3-4.4,1.3-4.6,3.6c-0.3,2.3,1.3,4.4,3.6,4.6 c7,0.9,13.4,4,18.4,9c5,5,8.1,11.4,9,18.4c0.3,2.1,2.1,3.6,4.1,3.6c0.2,0,0.4,0,0.5,0c2.3-0.3,3.9-2.4,3.6-4.6 C96.7,51,92.7,43,86.4,36.6L86.4,36.6z">
                                                                 </path>
                                                             </svg> </span>
                                                         <span class="elementor-icon-list-text">+966 50 555 7749</span>
                                                     </a>
                                                 </li>
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <span class="elementor-icon-list-icon">
                                                         <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                                                             viewBox="0 0 100 100"
                                                             style="enable-background:new 0 0 100 100;"
                                                             xml:space="preserve">
                                                             <path
                                                                 d="M48.1,5C29.1,6,14,21.3,14,40c0,7.9,2.7,15.2,7.2,21h0l24.4,31.8c2.2,2.9,6.6,2.9,8.8,0L78.8,61h0 c4.2-5.4,6.8-11.9,7.2-19.1C87.1,21.2,69.4,4,48.1,5z M74,41c0,13.3-10.7,24-24,24S26,54.3,26,41s10.7-24,24-24S74,27.7,74,41z">
                                                             </path>
                                                         </svg> </span>
                                                     <span class="elementor-icon-list-text">الرياض، المملكة العربية
                                                         السعودية</span>
                                                 </li>
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <a href="mailto:reservations@enala.sa">

                                                         <span class="elementor-icon-list-icon">
                                                             <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                                                                 viewBox="0 0 100 100"
                                                                 style="enable-background:new 0 0 100 100;"
                                                                 xml:space="preserve">
                                                                 <path
                                                                     d="M39.6,45.8L39.6,45.8C39.7,45.9,39.7,45.9,39.6,45.8L50,55.3L60.2,46l0.4-0.3l29.8-27.2c-0.2,0-0.5-0.1-0.7-0.1H10.4 c-0.2,0-0.5,0-0.7,0.1L39.6,45.8C39.6,45.8,39.6,45.8,39.6,45.8L39.6,45.8z">
                                                                 </path>
                                                                 <path
                                                                     d="M5,23c0,0.2,0,0.4,0,0.6v51.7c0,0.2,0,0.5,0,0.7L32.7,48L5,23z">
                                                                 </path>
                                                                 <path
                                                                     d="M51.9,60.3c-0.5,0.5-1.2,0.8-1.9,0.8c-0.7,0-1.3-0.3-1.9-0.8l-10.3-9.7L9.6,80.6c0.2,0,0.5,0.1,0.7,0.1h79.4 c0.2,0,0.5,0,0.7-0.1L62.1,50.7L51.9,60.3L51.9,60.3z">
                                                                 </path>
                                                                 <path
                                                                     d="M95,23L67.3,48L95,76.1c0-0.2,0-0.5,0-0.7V23.7C95,23.4,95,23.2,95,23L95,23z">
                                                                 </path>
                                                             </svg> </span>
                                                         <span
                                                             class="elementor-icon-list-text">reservations@enala.sa</span>
                                                     </a>
                                                 </li>
                                             </ul>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-fb52024"
                                 data-id="fb52024" data-element_type="column">
                                 <div class="elementor-widget-wrap elementor-element-populated">
                                     <div class="elementor-element elementor-element-b8849b1 elementor-widget__width-auto wdt-dark-bg elementor-hidden-mobile_extra elementor-hidden-mobile elementor-widget elementor-widget-wdt-heading"
                                         data-id="b8849b1" data-element_type="widget"
                                         data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                         data-widget_type="wdt-heading.default">
                                         <div class="elementor-widget-container">
                                             <div class="wdt-heading-holder " id="wdt-heading-b8849b1">
                                                 <h6
                                                     class="wdt-heading-title-wrapper wdt-heading-align- wdt-heading-deco-wrapper">
                                                     <span class="wdt-heading-title">We are Social:</span></h6>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="elementor-element elementor-element-0ae5b05 elementor-icon-list--layout-inline elementor-widget__width-auto elementor-list-item-link-inline elementor-widget elementor-widget-icon-list"
                                         data-id="0ae5b05" data-element_type="widget"
                                         data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                         data-widget_type="icon-list.default">

                                         <div class="elementor-widget-container">
                                             <ul class="elementor-icon-list-items elementor-inline-items social-icons">

                                                 <!-- Facebook -->
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <a href="https://www.facebook.com/enala.sau" target="_blank">
                                                         <i class="fab fa-facebook-f"></i>
                                                     </a>
                                                 </li>

                                                 <!-- X (Twitter) -->
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <a href="https://twitter.com/enala_sa" target="_blank">
                                                         <i class="fab fa-x-twitter"></i>
                                                     </a>
                                                 </li>

                                                 <!-- Instagram -->
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <a href="https://www.instagram.com/enala.sa/" target="_blank">
                                                         <i class="fab fa-instagram"></i>
                                                     </a>
                                                 </li>

                                                 <!-- Snapchat -->
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <a href="https://www.snapchat.com/add/enala.sa" target="_blank">
                                                         <i class="fab fa-snapchat-ghost"></i>
                                                     </a>
                                                 </li>

                                                 <!-- YouTube -->
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <a href="https://www.youtube.com/channel/UC2i5QjYXfAw2HBDZWQy5rwg"
                                                         target="_blank">
                                                         <i class="fab fa-youtube"></i>
                                                     </a>
                                                 </li>

                                                 <!-- TikTok -->
                                                 <li class="elementor-icon-list-item elementor-inline-item">
                                                     <a href="https://www.tiktok.com/@enala.sa" target="_blank">
                                                         <i class="fab fa-tiktok"></i>
                                                     </a>
                                                 </li>

                                             </ul>
                                         </div>


                                     </div>
                                 </div>
                             </div>
                     </section>
                     <section
                         class="elementor-section elementor-top-section elementor-element elementor-element-b81b5c3 elementor-section-full_width elementor-section-height-default elementor-section-height-default animated fadeIn"
                         data-id="b81b5c3" data-element_type="section"
                         data-settings="{&quot;animation&quot;:&quot;fadeIn&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                         <div class="elementor-container elementor-column-gap-no">
                             <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b9405ca"
                                 data-id="b9405ca" data-element_type="column">
                                 <div class="elementor-widget-wrap elementor-element-populated">
                                     <section
                                         class="elementor-section elementor-inner-section elementor-element elementor-element-a41f9dd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                         data-id="a41f9dd" data-element_type="section"
                                         data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                                         <div class="elementor-container elementor-column-gap-no">
                                             <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7cdf558 wdt-order-1"
                                                 data-id="7cdf558" data-element_type="column">
                                                 <div class="elementor-widget-wrap elementor-element-populated">
                                                     <div class="elementor-element elementor-element-e7d5a53 elementor-widget__width-auto elementor-widget elementor-widget-wdt-logo"
                                                         data-id="e7d5a53" data-element_type="widget"
                                                         data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                         data-widget_type="wdt-logo.default">
                                                         <div class="elementor-widget-container">
                                                             <div id="grassroot-e7d5a53" class="wdt-logo-container">
                                                                 <a href="<?php echo e(route('frontend.home')); ?>"
                                                                     rel="home"><img loading="lazy"
                                                                         src="../img/logo.png"
                                                                         alt="RTL GrassRoot Site" width="350"
                                                                         height="80"></a></div>
                                                         </div>
                                                     </div>
                                                 </div>
                                             </div>
                                             <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-73065a6 wdt-order-3 elementor-hidden-tablet elementor-hidden-mobile_extra elementor-hidden-mobile"
                                                 data-id="73065a6" data-element_type="column">
                                                 <div class="elementor-widget-wrap elementor-element-populated">
                                                     <div class="elementor-element elementor-element-158cb18 elementor-align-center wdt-dark-bg elementor-widget__width-auto elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile_extra elementor-hidden-mobile elementor-widget elementor-widget-wdt-header-menu"
                                                         data-id="158cb18" data-element_type="widget"
                                                         data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                         data-widget_type="wdt-header-menu.default">
                                                         <div class="elementor-widget-container">
                                                             <div class="wdt-header-menu" data-menu="2">
                                                                 <div class="menu-container">
                                                                     <ul id="menu-main-menu-1"
                                                                         class="wdt-primary-nav " data-menu="2">
                                                                         <li class="close-nav"><a
                                                                                 href="javascript:void(0);"></a></li>
                                                                         <li>
                                                                             <a href="<?php echo e(route('frontend.home')); ?>"
                                                                                 aria-current="page"><span
                                                                                     data-text="%1$s">الرئيسية</span></a>
                                                                         </li>
                                                                                         <li>
                                                                                      <a href="<?php echo e(route('guests.reviews')); ?>"
                                                                                 aria-current="page"><span
                                                                                     data-text="%1$s">اراء النزلاء</span></a>
                                                                             
                                                                         </li>
                                                                         <li>
                                                                            <a href="<?php echo e(route('frontend.rooms')); ?>"><span
                                                                                     data-text="%1$s">قسم
                                                                                     الغرف</span></a>
                                                                             
                                                                         </li>
                                                                         <li>
                                                                            <a
                                                                                 href="<?php echo e(route('frontend.about-us')); ?>"><span
                                                                                     data-text="%1$s">من نحن</span></a>
                                                                             
                                                                         </li>
                                                                         <li>
                                                                            <a
                                                                                 href="<?php echo e(route('frontend.our-services')); ?>"><span
                                                                                     data-text="%1$s">خدماتنا</span></a>
                                                                             
                                                                         </li>
                                                                         <li>
                                                                            <a href="<?php echo e(route('contact')); ?>"><span
                                                                                     data-text="%1$s">تواصل
                                                                                     معنا</span></a></li>
                                                                     
                                                                     <div class="sub-menu-overlay"></div>
                                                                 </div>
                                                                 <div class="mobile-nav-container mobile-nav-offcanvas-right"
                                                                     data-menu="2"><a
                                                                         href="https://wdtgrassroot.wpengine.com/rtl-demo/#"
                                                                         class="menu-trigger menu-trigger-icon"
                                                                         data-menu="2"><i></i><span>Menu</span></a>
                                                                     <div class="mobile-menu" data-menu="2"></div>
                                                                     <div class="overlay"></div>
                                                                 </div>
                                                             </div>
                                                         </div>
                                                     </div>
                                                 </div>
                                             </div>
                                             <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3a029dc wdt-order-2"
                                                 data-id="3a029dc" data-element_type="column">
                                                 <div class="elementor-widget-wrap elementor-element-populated">
                                                     
                                                     <div class="elementor-widget-container">
                                                         
                                                     </div>
                                                     <div class="elementor-element elementor-element-e395455 elementor-widget__width-auto elementor-hidden-mobile elementor-hidden-tablet_extra elementor-hidden-tablet elementor-hidden-mobile_extra elementor-widget elementor-widget-wdt-button"
                                                         data-id="e395455" data-element_type="widget"
                                                         data-settings="{&quot;item_hover_background_background&quot;:&quot;classic&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                         data-widget_type="wdt-button.default">
                                                         <div class="elementor-widget-container">
                                                             <div class="wdt-button-holder wdt-template-filled wdt-button-link wdt-button-style-default wdt-button-size-nm wdt-animation- wdt-button-icon-after"
                                                                 id="wdt-button-e395455"><a class="wdt-button"
                                                                     href="<?php echo e(route('frontend.our-services')); ?>">
                                                                     <div class="wdt-button-text"><span>استكشف
                                                                             خدماتنا</span></div>
                                                                 </a></div>
                                                         </div>
                                                     </div>
                                                     <div class="elementor-element elementor-element-39d1bf5 elementor-align-center wdt-dark-bg elementor-widget__width-auto elementor-hidden-desktop elementor-hidden-laptop elementor-widget elementor-widget-wdt-header-menu"
                                                         data-id="39d1bf5" data-element_type="widget"
                                                         data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                         data-widget_type="wdt-header-menu.default">
                                                         <div class="elementor-widget-container">
                                                             <div class="wdt-header-menu" data-menu="2">
                                                                 <div class="menu-container">
                                                                     <ul id="menu-main-menu-2"
                                                                         class="wdt-primary-nav " data-menu="2">
                                                                         <li class="close-nav"><a
                                                                                 href="javascript:void(0);"></a></li>
                                                                         <li><a href="<?php echo e(route('frontend.home')); ?>"
                                                                                 aria-current="page"><span
                                                                                     data-text="%1$s">الرئسية</span></a>
                                                                             
                                                                         </li>
                                                                         <li><a href="<?php echo e(route('guests.reviews')); ?>"><span
                                                                                     data-text="%1$s">
                                                                                     اراء النزلاء</span></a>

                                                                         </li>
                                                                         <li><a href="<?php echo e(route('frontend.rooms')); ?>"><span
                                                                                     data-text="%1$s">قسم
                                                                                     الغرف</span></a>

                                                                         </li>

                                                                         <li> <a
                                                                                 href="<?php echo e(route('frontend.about-us')); ?>"><span
                                                                                     data-text="%1$s">من نحن</span></a>
                                                                            
                                                                         </li>
                                                                         <li> <a
                                                                                 href="<?php echo e(route('frontend.our-services')); ?>"><span
                                                                                     data-text="%1$s">خدماتنا</span></a>
                                                                             
                                                                         </li>
                                                                         <li
                                                                             class="menu-item menu-item-type-post_type menu-item-object-page menu-item-7567 menu-item-depth-0">
                                                                             <a
                                                                                 href="<?php echo e(route('contact')); ?>"><span
                                                                                     data-text="%1$s">تواصل معنا</span></a>
                                                                         </li>
                                                                     </ul>
                                                                     <div class="sub-menu-overlay"></div>
                                                                 </div>
                                                                 <div class="mobile-nav-container mobile-nav-offcanvas-right"
                                                                     data-menu="2"><a
                                                                         href="https://wdtgrassroot.wpengine.com/rtl-demo/#"
                                                                         class="menu-trigger menu-trigger-icon"
                                                                         data-menu="2"><i></i><span>Menu</span></a>
                                                                     <div class="mobile-menu" data-menu="2"></div>
                                                                     <div class="overlay"></div>
                                                                 </div>
                                                             </div>
                                                         </div>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </section>
                                     <div class="elementor-element elementor-element-3947615 elementor-absolute elementor-widget elementor-widget-spacer"
                                         data-id="3947615" data-element_type="widget"
                                         data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                         data-widget_type="spacer.default">
                                         <div class="elementor-widget-container">
                                             <div class="elementor-spacer">
                                                 <div class="elementor-spacer-inner"></div>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </section>
                 </div>
             </div>
         </div>
     </header> <!-- **Header - End ** -->
 </div><!-- ** Header Wrapper - End ** -->
<?php /**PATH D:\KSA\hotel\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>