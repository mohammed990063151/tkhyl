<!DOCTYPE html>
<html lang="ar">

<style>
    .logo {
  display: inline-block;
  max-width: 100%;
}

.logo-img {
  max-width: 180px; /* حجم افتراضي مناسب */
  height: auto;
  transition: all 0.3s ease-in-out;
}

/* الشاشات الصغيرة */
@media (max-width: 768px) {
  .logo-img {
    max-width: 140px;
  }
}

/* الشاشات الصغيرة جدًا (مثل الجوالات) */
@media (max-width: 480px) {
  .logo-img {
    max-width: 120px;
  }
}
</style>



<?php echo $__env->make('frontend.layouts.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body>
    <?php echo $__env->make('frontend.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>





<?php echo $__env->make('frontend.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('frontend.layouts.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


</body>
</html>
<?php /**PATH D:\KSA\hassin\hotel\hisan\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>