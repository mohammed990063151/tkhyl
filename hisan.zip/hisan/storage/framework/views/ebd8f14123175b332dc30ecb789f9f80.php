   <!-- **Footer** -->
   <footer id="footer">
       <div class="wdt-elementor-container-fluid">
           <div id="footer-15854" class="wdt-footer-tpl footer-15854">
               <div data-elementor-type="wp-post" data-elementor-id="15854" class="elementor elementor-15854">
                   <section
                       class="elementor-section elementor-top-section elementor-element elementor-element-1112c9d elementor-section-full_width wdt-black-bg elementor-section-height-default elementor-section-height-default"
                       data-id="1112c9d" data-element_type="section"
                       data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                       <div class="elementor-container elementor-column-gap-no">
                           <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-66a1009"
                               data-id="66a1009" data-element_type="column">
                               <div class="elementor-widget-wrap elementor-element-populated">
                                   <div class="elementor-element elementor-element-2ed325f e-transform elementor-widget elementor-widget-spacer"
                                       data-id="2ed325f" data-element_type="widget"
                                       data-settings="{&quot;_transform_flipY_effect&quot;:&quot;transform&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                       data-widget_type="spacer.default">
                                       <div class="elementor-widget-container">
                                           <div class="elementor-spacer">
                                               <div class="elementor-spacer-inner"></div>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </section>
                   <section
                       class="elementor-section elementor-top-section elementor-element elementor-element-1c6bf5a wdt-black-bg elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                       data-id="1c6bf5a" data-element_type="section"
                       data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                       <div class="elementor-background-overlay"></div>
                       <div class="elementor-container elementor-column-gap-no">
                           <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-04c5b19"
                               data-id="04c5b19" data-element_type="column">
                               <div class="elementor-widget-wrap elementor-element-populated">
                                   <section
                                       class="elementor-section elementor-inner-section elementor-element elementor-element-ff6f8d4 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                       data-id="ff6f8d4" data-element_type="section"
                                       data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                                       <div class="elementor-container elementor-column-gap-no">
                                           <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5504f3e"
                                               data-id="5504f3e" data-element_type="column">
                                               <div class="elementor-widget-wrap elementor-element-populated">
                                                   <div class="elementor-element elementor-element-fe3a6aa wdt-dark-bg elementor-widget-tablet__width-initial elementor-widget-mobile__width-inherit elementor-widget elementor-widget-wdt-heading"
                                                       data-id="fe3a6aa" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="wdt-heading.default">
                                                       <div class="elementor-widget-container">
                                                           <div class="wdt-heading-holder " id="wdt-heading-fe3a6aa">
                                                               <h2
                                                                   class="wdt-heading-title-wrapper wdt-heading-align- wdt-heading-deco-wrapper">
                                                                   <span class="wdt-heading-title">الهدوء و الرفاهية</span></h2>
                                                           </div>
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                           <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-a4f3561"
                                               data-id="a4f3561" data-element_type="column">
                                               <div class="elementor-widget-wrap elementor-element-populated">
                                                   <div class="elementor-element elementor-element-7b165e4 wdt-cus-footer-iconbox wdt-dark-bg elementor-widget-mobile__width-initial elementor-widget elementor-widget-wdt-advanced-slider"
                                                       data-id="7b165e4" data-element_type="widget"
                                                       data-settings="{&quot;columns&quot;:&quot;3&quot;,&quot;columns_tablet&quot;:&quot;3&quot;,&quot;columns_mobile_extra&quot;:&quot;2&quot;,&quot;columns_laptop&quot;:2,&quot;columns_tablet_extra&quot;:2,&quot;columns_mobile&quot;:1,&quot;carousel_arrows_prev_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_prev_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_vertical_top_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_laptop&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_tablet&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile_extra&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;carousel_arrows_next_arrow_horizontal_left_indent_mobile&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="wdt-advanced-slider.default">
                                                       <div class="elementor-widget-container">
                                                           <div class="wdt-specifications-holder wdt-content-item-holder wdt-column-holder "
                                                               id="wdt-specifications-7b165e4" data-settings="">
                                                               <div class="wdt-column-wrapper wdt-column-gap-default wdt-snap-scroll-enabled"
                                                                   data-column-settings="{&quot;columnDevices&quot;:[&quot;mobile_extra&quot;,&quot;mobile&quot;]}"
                                                                   data-module-id="wdt-module-id-7b165e4"
                                                                   id="wdt-module-id-7b165e4">
                                                                   <div class="wdt-column">
                                                                       <div class="wdt-content-item">
                                                                           <div class="wdt-advanced-slider-block">
                                                                               <div class="wdt-image-icon-group">
                                                                                   <div
                                                                                       class="wdt-content-icon-wrapper ">
                                                                                       <div class="wdt-content-icon"><a
                                                                                               href="https://wdtgrassroot.wpengine.com/rtl-demo/"
                                                                                               class="silde_pop_vid"><span><i><svg
                                                                                                           xmlns="http://www.w3.org/2000/svg"
                                                                                                           x="0px"
                                                                                                           y="0px"
                                                                                                           viewBox="0 0 100 100"
                                                                                                           style="enable-background:new 0 0 100 100;"
                                                                                                           xml:space="preserve">
                                                                                                           <path
                                                                                                               d="M48.1,5C29.1,6,14,21.3,14,40c0,7.9,2.7,15.2,7.2,21h0l24.4,31.8c2.2,2.9,6.6,2.9,8.8,0L78.8,61h0 c4.2-5.4,6.8-11.9,7.2-19.1C87.1,21.2,69.4,4,48.1,5z M74,41c0,13.3-10.7,24-24,24S26,54.3,26,41s10.7-24,24-24S74,27.7,74,41z">
                                                                                                           </path>
                                                                                                       </svg></i></span></a>
                                                                                       </div>
                                                                                   </div>
                                                                               </div>
                                                                               <div class="wdt-content-detail-group">
                                                                                   <div class="wdt-content-description">
                                                                                       <p>الرياض، المملكة العربية السعودية</p>
                                                                                       
                                                                                   </div>
                                                                               </div>
                                                                           </div>
                                                                       </div>
                                                                   </div>
                                                                   <div class="wdt-column">
                                                                       <div class="wdt-content-item">
                                                                           <div class="wdt-advanced-slider-block">
                                                                               <div class="wdt-image-icon-group">
                                                                                   <div
                                                                                       class="wdt-content-icon-wrapper ">
                                                                                       <div class="wdt-content-icon"><a
                                                                                               href="https://wdtgrassroot.wpengine.com/rtl-demo/"
                                                                                               class="silde_pop_vid"><span><i><svg
                                                                                                           xmlns="http://www.w3.org/2000/svg"
                                                                                                           xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                                                           x="0px"
                                                                                                           y="0px"
                                                                                                           viewBox="0 0 120 120"
                                                                                                           style="enable-background:new 0 0 120 120;"
                                                                                                           xml:space="preserve">
                                                                                                           <path
                                                                                                               d="M46.4,55.1C46.4,55.1,46.4,55.1,46.4,55.1L46.4,55.1C46.5,55.2,46.5,55.2,46.4,55.1 C46.5,55.2,46.5,55.2,46.4,55.1l4.5,4.1c5.2,4.7,13.1,4.7,18.2,0l4.2-3.8l0.5-0.5l38.4-35.1c0.3-0.3,0.1-0.7-0.3-0.7H8 c-0.4,0-0.5,0.5-0.3,0.7L46.4,55.1C46.4,55.1,46.4,55.1,46.4,55.1C46.4,55.1,46.4,55.1,46.4,55.1C46.4,55.1,46.4,55.1,46.4,55.1z">
                                                                                                           </path>
                                                                                                           <path
                                                                                                               d="M1.7,25.8C1.4,25.5,1,25.7,1,26.1v67.8c0,0.4,0.4,0.5,0.7,0.3l23.4-23.8c6.6-6.8,6.3-17.7-0.7-24L1.7,25.8z">
                                                                                                           </path>
                                                                                                           <path
                                                                                                               d="M62.5,74.2C62.5,74.2,62.5,74.2,62.5,74.2c-0.7,0.7-1.6,1-2.5,1c-0.9,0-1.8-0.3-2.5-1l-9-8.5 c-2.4-2.3-6.3-2.2-8.5,0.3L7.7,100.1c-0.3,0.3-0.1,0.7,0.3,0.7H112c0.4,0,0.6-0.5,0.3-0.7L80.1,65.9c-2.3-2.4-6.1-2.5-8.5-0.3 L62.5,74.2C62.5,74.2,62.5,74.2,62.5,74.2z">
                                                                                                           </path>
                                                                                                           <path
                                                                                                               d="M118.9,25.2C118.9,25.2,118.9,25.2,118.9,25.2L93.1,48.6c-5.7,5.1-5.9,13.9-0.6,19.4l25.8,26.2 c0.3,0.3,0.7,0.1,0.7-0.3V26.1C119,25.8,119,25.5,118.9,25.2C118.9,25.2,118.9,25.2,118.9,25.2z">
                                                                                                           </path>
                                                                                                       </svg></i></span></a>
                                                                                       </div>
                                                                                   </div>
                                                                               </div>
                                                                               <div class="wdt-content-detail-group">
                                                                                   <div
                                                                                       class="wdt-content-button-group">
                                                                                       <div
                                                                                           class="wdt-content-button wdt-button-clone">
                                                                                           <a
                                                                                               href="mailto:reservations@enala.sa">
                                                                                               <div
                                                                                                   class="wdt-button-text">
                                                                                                   <span>reservations@enala.sa</span>
                                                                                               </div>
                                                                                           </a></div>
                                                                                       <div
                                                                                           class="wdt-content-button wdt-button-clone">
                                                                                           <a
                                                                                               href="mailto:contact@example.com">
                                                                                               <div
                                                                                                   class="wdt-button-text">
                                                                                                   <span></span>
                                                                                               </div>
                                                                                           </a></div>
                                                                                   </div>
                                                                               </div>
                                                                           </div>
                                                                       </div>
                                                                   </div>
                                                                   <div class="wdt-column">
                                                                       <div class="wdt-content-item">
                                                                           <div class="wdt-advanced-slider-block">
                                                                               <div class="wdt-image-icon-group">
                                                                                   <div
                                                                                       class="wdt-content-icon-wrapper ">
                                                                                       <div class="wdt-content-icon"><a
                                                                                               href="https://wdtgrassroot.wpengine.com/rtl-demo/"
                                                                                               class="silde_pop_vid"><span><i><svg
                                                                                                           xmlns="http://www.w3.org/2000/svg"
                                                                                                           xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                                                           x="0px"
                                                                                                           y="0px"
                                                                                                           viewBox="0 0 120 120"
                                                                                                           style="enable-background:new 0 0 120 120;"
                                                                                                           xml:space="preserve">
                                                                                                           <path
                                                                                                               d="M115.8,108c4.8-4.8,4.2-12.8-1.4-16.8l-19.1-14c-4.4-3.3-10.6-2.8-14.4,1l-3.3,3.3c-0.4,0.4-0.8,0.7-1.2,1 c-1.6,1.6-3.9,2.1-6,1.3c-16.6-6.3-28-17.8-34.4-34.4c-0.8-2.1-0.3-4.4,1.3-6l0.6-0.6c0.1-0.2,0.3-0.3,0.4-0.5l3.3-3.3 c3.9-3.9,4.3-10,1.1-14.4l-14-19.1c-4-5.5-12-6.2-16.8-1.4L8.6,7.6c-3.9,3.9-6.4,8.8-7.2,14.2c-0.1,0.7-0.2,1.5-0.2,2.2 C0.2,37.2,5,51.2,14.7,66.2c0.3,0.5,0.7,1,1,1.5c9.7,14.5,22.2,26.9,36.6,36.6c0.5,0.3,1,0.6,1.4,0.9c15,9.7,29.1,14.5,42.2,13.6 c0.7,0,1.5-0.1,2.2-0.2c5.4-0.8,10.3-3.4,14.2-7.2L115.8,108L115.8,108z">
                                                                                                           </path>
                                                                                                           <path
                                                                                                               d="M119,57.2c-1.1-14.5-7.4-28.2-17.7-38.5C91,8.4,77.3,2.1,62.8,1c-2.2-0.2-4.1,1.5-4.3,3.7 C58.3,6.9,60,8.8,62.2,9c12.6,0.9,24.5,6.4,33.5,15.3c9,9,14.4,20.8,15.3,33.5c0.2,2.1,1.9,3.7,4,3.7c0.1,0,0.2,0,0.3,0 C117.5,61.3,119.2,59.4,119,57.2L119,57.2z">
                                                                                                           </path>
                                                                                                           <path
                                                                                                               d="M86.4,36.6C80.1,30.3,72,26.4,63.2,25.2c-2.3-0.3-4.4,1.3-4.6,3.6c-0.3,2.3,1.3,4.4,3.6,4.6 c7,0.9,13.4,4,18.4,9c5,5,8.1,11.4,9,18.4c0.3,2.1,2.1,3.6,4.1,3.6c0.2,0,0.4,0,0.5,0c2.3-0.3,3.9-2.4,3.6-4.6 C96.7,51,92.7,43,86.4,36.6L86.4,36.6z">
                                                                                                           </path>
                                                                                                       </svg></i></span></a>
                                                                                       </div>
                                                                                   </div>
                                                                               </div>
                                                                               <div class="wdt-content-detail-group">
                                                                                   <div
                                                                                       class="wdt-content-button-group">
                                                                                       <div
                                                                                           class="wdt-content-button wdt-button-clone">
                                                                                           <a
                                                                                               href="tel:(+966)50 555 7749">
                                                                                               <div
                                                                                                   class="wdt-button-text">
                                                                                                   <span>050 555 7749</span></div>
                                                                                           </a></div>
                                                                                       <div
                                                                                           class="wdt-content-button wdt-button-clone">
                                                                                           <a
                                                                                               href="tel:(+000)%20-%20123%20-%20456%20-%20789">
                                                                                               <div
                                                                                                   class="wdt-button-text">
                                                                                                   <span></span>
                                                                                               </div>
                                                                                           </a></div>
                                                                                   </div>
                                                                               </div>
                                                                           </div>
                                                                       </div>
                                                                   </div>
                                                               </div>
                                                               <div
                                                                   class="wdt-column-pagination wdt-snap-scroll-pagination">
                                                                   <button
                                                                       class="wdt-pagination-prev wdt-module-id-7b165e4 disabled"
                                                                       style="cursor: not-allowed;">Previous</button>
                                                                   <button
                                                                       class="wdt-pagination-next wdt-module-id-7b165e4 disabled"
                                                                       style="cursor: not-allowed;">Next</button>
                                                               </div>
                                                           </div>
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                       </div>
                                   </section>
                                   <section
                                       class="elementor-section elementor-inner-section elementor-element elementor-element-4c3b952 wdt-dark-bg wdt-section-wrap-col elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                       data-id="4c3b952" data-element_type="section"
                                       data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                                       <div class="elementor-container elementor-column-gap-no">
                                           <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-be77a71"
                                               data-id="be77a71" data-element_type="column">
                                               <div class="elementor-widget-wrap elementor-element-populated">
                                                   <div class="elementor-element elementor-element-394fb59 elementor-widget elementor-widget-wdt-logo"
                                                       data-id="394fb59" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="wdt-logo.default">
                                                       <div class="elementor-widget-container">
                                                           <div id="grassroot-394fb59" class="wdt-logo-container"> <a
                                                                   href="<?php echo e(route('frontend.home')); ?>"
                                                                   rel="home"><img loading="lazy"
                                                                       src="../img/logo.png"
                                                                       alt="RTL GrassRoot Site" width="350"
                                                                       height="80"></a></div>
                                                       </div>
                                                   </div>
                                                   <div class="elementor-element elementor-element-20c16b4 elementor-widget elementor-widget-wdt-heading"
                                                       data-id="20c16b4" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="wdt-heading.default">
                                                       <div class="elementor-widget-container">
                                                           <div class="wdt-heading-holder " id="wdt-heading-20c16b4">
                                                               <div class="wdt-heading-content-wrapper">شركة إناله هي شركة سعودية رائدة في مجال إدارة وتشغيل الفنادق والمنتجعات، تأسست في عام 2013. تلتزم الشركة بتقديم خدماتها وفقًا لأعلى المعايير العالمية في مجال الضيافة والاستجمام، وذلك بهدف تحقيق تطلعات رؤية المملكة 2030.</div>
                                                           </div>
                                                       </div>
                                                   </div>
                                                   <div class="elementor-element elementor-element-0a7afe2 elementor-icon-list--layout-inline wdt-header-icon-social-style wdt-footer-socials elementor-list-item-link-inline elementor-mobile_extra-align-right elementor-widget-mobile_extra__width-inherit elementor-widget elementor-widget-icon-list"
                                                       data-id="0a7afe2" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="icon-list.default">
                                                       <div class="elementor-widget-container">
                                                           <ul
                                                               class="elementor-icon-list-items elementor-inline-items">
                                                               <li
                                                                   class="elementor-icon-list-item elementor-inline-item">
                                                                   <a href="https://www.facebook.com/enala.sau">

                                                                       <span class="elementor-icon-list-icon">
                                                                           <svg aria-hidden="true"
                                                                               class="e-font-icon-svg e-fab-facebook-f"
                                                                               viewBox="0 0 320 512"
                                                                               xmlns="http://www.w3.org/2000/svg">
                                                                               <path
                                                                                   d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z">
                                                                               </path>
                                                                           </svg> </span>
                                                                       <span class="elementor-icon-list-text"></span>
                                                                   </a>
                                                               </li>
                                                               <li
                                                                   class="elementor-icon-list-item elementor-inline-item">
                                                                   <a href="https://twitter.com/enala_sa">

                                                                       <span class="elementor-icon-list-icon">
                                                                           <svg xmlns="http://www.w3.org/2000/svg"
                                                                               xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                               x="0px" y="0px" viewBox="0 0 100 100"
                                                                               style="enable-background:new 0 0 100 100;"
                                                                               xml:space="preserve">
                                                                               <path
                                                                                   d="M0.7,3.7L39,54.8L0.5,96.3h8.7L42.8,60L70,96.3h29.5l-40.4-54L94.9,3.7h-8.7l-31,33.5L30.2,3.7H0.7z M13.5,10H27L86.8,90 H73.2L13.5,10z">
                                                                               </path>
                                                                           </svg> </span>
                                                                       <span class="elementor-icon-list-text"></span>
                                                                   </a>
                                                               </li>
                                                               <li
                                                                   class="elementor-icon-list-item elementor-inline-item">
                                                                   <a href="https://in.linkedin.com/">

                                                                       <span class="elementor-icon-list-icon">
                                                                           <svg aria-hidden="true"
                                                                               class="e-font-icon-svg e-fab-youtube"
                                                                               viewBox="0 0 576 512"
                                                                               xmlns="http://www.w3.org/2000/svg">
                                                                               <path
                                                                                   d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z">
                                                                               </path>
                                                                           </svg> </span>
                                                                       <span class="elementor-icon-list-text"></span>
                                                                   </a>
                                                               </li>
                                                               <li
                                                                   class="elementor-icon-list-item elementor-inline-item">
                                                                   <a href="https://www.google.com/">

                                                                       <span class="elementor-icon-list-icon">
                                                                           <svg xmlns="http://www.w3.org/2000/svg"
                                                                               xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                               x="0px" y="0px" viewBox="0 0 120 120"
                                                                               style="enable-background:new 0 0 120 120;"
                                                                               xml:space="preserve">
                                                                               <path
                                                                                   d="M84.9,1H35.1C16.3,1,1,16.3,1,35.1v49.9C1,103.7,16.3,119,35.1,119h49.9c18.8,0,34.1-15.3,34.1-34.1V35.1 C119,16.3,103.8,1,84.9,1z M108.1,85.8c0,12.5-10.1,22.6-22.6,22.6h-51c-12.5,0-22.6-10.1-22.6-22.6v-51c0-12.5,10.1-22.6,22.6-22.6 h51c12.5,0,22.6,10.1,22.6,22.6V85.8z">
                                                                               </path>
                                                                               <path
                                                                                   d="M58,28.5c-16.3,0-29.5,13.2-29.5,29.5S41.7,87.5,58,87.5S87.5,74.3,87.5,58S74.3,28.5,58,28.5z M58,77.2 c-10.6,0-19.1-8.6-19.1-19.1S47.5,38.9,58,38.9S77.2,47.5,77.2,58S68.6,77.2,58,77.2z">
                                                                               </path>
                                                                               <path
                                                                                   d="M87.5,20.7c-4.3,0-7.9,3.5-7.9,7.9s3.5,7.9,7.9,7.9s7.9-3.5,7.9-7.9S91.9,20.7,87.5,20.7z">
                                                                               </path>
                                                                           </svg> </span>
                                                                       <span class="elementor-icon-list-text"></span>
                                                                   </a>
                                                               </li>
                                                           </ul>
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                           <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-0fc9044"
                                               data-id="0fc9044" data-element_type="column">
                                               <div class="elementor-widget-wrap elementor-element-populated">
                                                   <div class="elementor-element elementor-element-dc87ddb elementor-widget elementor-widget-wdt-heading"
                                                       data-id="dc87ddb" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="wdt-heading.default">
                                                       <div class="elementor-widget-container">
                                                           <div class="wdt-heading-holder " id="wdt-heading-dc87ddb">
                                                               <h4
                                                                   class="wdt-heading-title-wrapper wdt-heading-align- wdt-heading-deco-wrapper">
                                                                   <span class="wdt-heading-title">Instagram</span>
                                                               </h4>
                                                           </div>
                                                       </div>
                                                   </div>
                                                   <div class="elementor-element elementor-element-9ee7309 gallery-spacing-custom wdt-cus-footer-gallery elementor-widget elementor-widget-image-gallery"
                                                       data-id="9ee7309" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="image-gallery.default">
                                                       <div class="elementor-widget-container">
                                                           <div class="elementor-image-gallery">
                                                               <div id="gallery-1"
                                                                   class="gallery galleryid-15720 gallery-columns-3 gallery-size-full">
                                                                   <figure class="gallery-item">
                                                                       <div class="gallery-icon landscape">
                                                                           <a data-elementor-open-lightbox="yes"
                                                                               data-elementor-lightbox-slideshow="9ee7309"
                                                                               data-elementor-lightbox-title="footer-gallery-img-1"
                                                                               data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NTcsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctMS5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D"
                                                                               href="https://www.instagram.com/enala.sa/"><img
                                                                                   loading="lazy" width="800"
                                                                                   height="800"
                                                                                   src="./RTL GrassRoot Site – Your SUPER-powered WP Engine Site_files/footer-gallery-img-1.jpg"
                                                                                   class="attachment-full size-full"
                                                                                   alt="" decoding="async"
                                                                                   srcset="../img/break-649351_1280.jpg"
                                                                                   sizes="(max-width: 800px) 100vw, 800px"></a>
                                                                       </div>
                                                                   </figure>
                                                                   <figure class="gallery-item">
                                                                       <div class="gallery-icon landscape">
                                                                           <a data-elementor-open-lightbox="yes"
                                                                               data-elementor-lightbox-slideshow="9ee7309"
                                                                               data-elementor-lightbox-title="footer-gallery-img-2"
                                                                               data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NTgsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctMi5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D"
                                                                               href="https://www.instagram.com/enala.sa/"><img
                                                                                   loading="lazy" width="800"
                                                                                   height="800"
                                                                                   src="./RTL GrassRoot Site – Your SUPER-powered WP Engine Site_files/footer-gallery-img-2.jpg"
                                                                                   class="attachment-full size-full"
                                                                                   alt="" decoding="async"
                                                                                   srcset="../img/6315b138554a6_restaurant.webp"
                                                                                   sizes="(max-width: 800px) 100vw, 800px"></a>
                                                                       </div>
                                                                   </figure>
                                                                   <figure class="gallery-item">
                                                                       <div class="gallery-icon landscape">
                                                                           <a data-elementor-open-lightbox="yes"
                                                                               data-elementor-lightbox-slideshow="9ee7309"
                                                                               data-elementor-lightbox-title="footer-gallery-img-3"
                                                                               data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NTksInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctMy5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D"
                                                                               href="https://www.instagram.com/enala.sa/"><img
                                                                                   loading="lazy" width="800"
                                                                                   height="800"
                                                                                   src="./RTL GrassRoot Site – Your SUPER-powered WP Engine Site_files/footer-gallery-img-3.jpg"
                                                                                   class="attachment-full size-full"
                                                                                   alt="" decoding="async"
                                                                                   srcset="../img/to-travel-1677347_1280.jpg"
                                                                                   sizes="(max-width: 800px) 100vw, 800px"></a>
                                                                       </div>
                                                                   </figure>
                                                                   <figure class="gallery-item">
                                                                       <div class="gallery-icon landscape">
                                                                           <a data-elementor-open-lightbox="yes"
                                                                               data-elementor-lightbox-slideshow="9ee7309"
                                                                               data-elementor-lightbox-title="footer-gallery-img-4"
                                                                               data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NjAsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctNC5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D"
                                                                               href="https://www.instagram.com/enala.sa/"><img
                                                                                   loading="lazy" width="800"
                                                                                   height="800"
                                                                                   src="./RTL GrassRoot Site – Your SUPER-powered WP Engine Site_files/footer-gallery-img-4.jpg"
                                                                                   class="attachment-full size-full"
                                                                                   alt="" decoding="async"
                                                                                   srcset="../img/bedroom-5664221_1280.jpg"
                                                                                   sizes="(max-width: 800px) 100vw, 800px"></a>
                                                                       </div>
                                                                   </figure>
                                                                   <figure class="gallery-item">
                                                                       <div class="gallery-icon landscape">
                                                                           <a data-elementor-open-lightbox="yes"
                                                                               data-elementor-lightbox-slideshow="9ee7309"
                                                                               data-elementor-lightbox-title="footer-gallery-img-5"
                                                                               data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NjEsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctNS5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D"
                                                                               href="https://www.instagram.com/enala.sa/"><img
                                                                                   loading="lazy" width="800"
                                                                                   height="800"
                                                                                   src="./RTL GrassRoot Site – Your SUPER-powered WP Engine Site_files/footer-gallery-img-5.jpg"
                                                                                   class="attachment-full size-full"
                                                                                   alt="" decoding="async"
                                                                                   srcset="../img/bedroom-349701_1280.jpg"
                                                                                   sizes="(max-width: 800px) 100vw, 800px"></a>
                                                                       </div>
                                                                   </figure>
                                                                   <figure class="gallery-item">
                                                                       <div class="gallery-icon landscape">
                                                                           <a data-elementor-open-lightbox="yes"
                                                                               data-elementor-lightbox-slideshow="9ee7309"
                                                                               data-elementor-lightbox-title="footer-gallery-img-6"
                                                                               data-e-action-hash="#elementor-action%3Aaction%3Dlightbox%26settings%3DeyJpZCI6MTU4NjIsInVybCI6Imh0dHBzOlwvXC93ZHRncmFzc3Jvb3Qud3BlbmdpbmUuY29tXC9ydGwtZGVtb1wvd3AtY29udGVudFwvdXBsb2Fkc1wvc2l0ZXNcLzNcLzIwMjVcLzAxXC9mb290ZXItZ2FsbGVyeS1pbWctNi5qcGciLCJzbGlkZXNob3ciOiI5ZWU3MzA5In0%3D"
                                                                               href="https://www.instagram.com/enala.sa/"><img
                                                                                   loading="lazy" width="800"
                                                                                   height="800"
                                                                                   src="./RTL GrassRoot Site – Your SUPER-powered WP Engine Site_files/footer-gallery-img-6.jpg"
                                                                                   class="attachment-full size-full"
                                                                                   alt="" decoding="async"
                                                                                   srcset="../img/6323224c2d9c5_63136758b69271662216024.webp"
                                                                                   sizes="(max-width: 800px) 100vw, 800px"></a>
                                                                       </div>
                                                                   </figure>
                                                               </div>
                                                           </div>
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                           <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-7352c06"
                                               data-id="7352c06" data-element_type="column">
                                               <div class="elementor-widget-wrap elementor-element-populated">
                                                   <div class="elementor-element elementor-element-4786dd5 elementor-widget elementor-widget-wdt-accordion-and-toggle"
                                                       data-id="4786dd5" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="wdt-accordion-and-toggle.default">
                                                       <div class="elementor-widget-container">
                                                           <div class="wdt-accordion-toggle-holder wdt-module-toggle wdt-template-default wdt-expand-collapse-position-end accordion ui-accordion ui-accordion-icons ui-widget ui-helper-reset"
                                                               id="wdt-accordion-and-toggle-4786dd5">
                                                               <div class="wdt-accordion-toggle-wrapper">
                                                                   <div
                                                                       class="wdt-accordion-toggle-title-holder ui-accordion-header ui-state-default ui-corner-top ui-corner-bottom">
                                                                       <div class="wdt-accordion-toggle-title">آخر المواضيع</div>
                                                                       <div class="wdt-accordion-toggle-icon">
                                                                           <div
                                                                               class="wdt-accordion-toggle-icon-expand">
                                                                               <svg aria-hidden="true"
                                                                                   class="e-font-icon-svg e-fas-plus"
                                                                                   viewBox="0 0 448 512"
                                                                                   xmlns="http://www.w3.org/2000/svg">
                                                                                   <path
                                                                                       d="M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z">
                                                                                   </path>
                                                                               </svg></div>
                                                                           <div
                                                                               class="wdt-accordion-toggle-icon-collapse">
                                                                               <svg aria-hidden="true"
                                                                                   class="e-font-icon-svg e-fas-minus"
                                                                                   viewBox="0 0 448 512"
                                                                                   xmlns="http://www.w3.org/2000/svg">
                                                                                   <path
                                                                                       d="M416 208H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h384c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z">
                                                                                   </path>
                                                                               </svg></div>
                                                                       </div>
                                                                   </div>
                                                                   <div class="wdt-accordion-toggle-description ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom"
                                                                       style="display: none;">
                                                                       <style>
                                                                           .elementor-widget-icon-list .elementor-icon-list-item:not(:last-child):after {
                                                                               border-color: var(--e-global-color-text);
                                                                           }

                                                                           .elementor-widget-icon-list .elementor-icon-list-icon i {
                                                                               color: var(--e-global-color-primary);
                                                                           }

                                                                           .elementor-widget-icon-list .elementor-icon-list-icon svg {
                                                                               fill: var(--e-global-color-primary);
                                                                           }

                                                                           .elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
                                                                           .elementor-widget-icon-list .elementor-icon-list-item>a {
                                                                               font-family: var(--e-global-typography-text-font-family), Sans-serif;
                                                                               font-weight: var(--e-global-typography-text-font-weight);
                                                                               line-height: var(--e-global-typography-text-line-height);
                                                                           }

                                                                           .elementor-widget-icon-list .elementor-icon-list-text {
                                                                               color: var(--e-global-color-secondary);
                                                                           }

                                                                           .elementor-15851 .elementor-element.elementor-element-9d93d7b .elementor-icon-list-icon i {
                                                                               transition: color 0.3s;
                                                                           }

                                                                           .elementor-15851 .elementor-element.elementor-element-9d93d7b .elementor-icon-list-icon svg {
                                                                               transition: fill 0.3s;
                                                                           }

                                                                           .elementor-15851 .elementor-element.elementor-element-9d93d7b {
                                                                               --e-icon-list-icon-size: 14px;
                                                                               --icon-vertical-offset: 0px;
                                                                           }

                                                                           .elementor-15851 .elementor-element.elementor-element-9d93d7b .elementor-icon-list-text {
                                                                               transition: color 0.3s;
                                                                           }

                                                                           @media(max-width:1540px) {

                                                                               .elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
                                                                               .elementor-widget-icon-list .elementor-icon-list-item>a {
                                                                                   line-height: var(--e-global-typography-text-line-height);
                                                                               }
                                                                           }

                                                                           @media(max-width:1024px) {

                                                                               .elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
                                                                               .elementor-widget-icon-list .elementor-icon-list-item>a {
                                                                                   line-height: var(--e-global-typography-text-line-height);
                                                                               }
                                                                           }

                                                                           @media(max-width:479px) {

                                                                               .elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
                                                                               .elementor-widget-icon-list .elementor-icon-list-item>a {
                                                                                   line-height: var(--e-global-typography-text-line-height);
                                                                               }
                                                                           }
                                                                       </style>
                                                                       <div data-elementor-type="section"
                                                                           data-elementor-id="15851"
                                                                           class="elementor elementor-15851">
                                                                           <section
                                                                               class="elementor-section elementor-top-section elementor-element elementor-element-1f1e026 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                                                               data-id="1f1e026"
                                                                               data-element_type="section"
                                                                               data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                                                                               <div
                                                                                   class="elementor-container elementor-column-gap-no">
                                                                                   <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a13fd5"
                                                                                       data-id="5a13fd5"
                                                                                       data-element_type="column">
                                                                                       <div
                                                                                           class="elementor-widget-wrap elementor-element-populated">
                                                                                           <div class="elementor-element elementor-element-9d93d7b elementor-list-item-link-inline elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list"
                                                                                               data-id="9d93d7b"
                                                                                               data-element_type="widget"
                                                                                               data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                                                               data-widget_type="icon-list.default">
                                                                                               <div
                                                                                                   class="elementor-widget-container">
                                                                                                   <ul
                                                                                                       class="elementor-icon-list-items">
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('blog.index')); ?> ">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text"> أ. فالح الفالح رئيس لجنة السياحة والترفيه والفعاليات بـ #غرفة_الرياض متحدثاً عن تطلعات اللجنة نحو خدمة القطاع</span>
                                                                                                           </a>
                                                                                                       </li>
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('blog.index')); ?> ">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text"> اليوم العالمي للرجل ومنتجعات إناله السياحية في الرياض
                                                                                                               </span>
                                                                                                           </a>
                                                                                                       </li>
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('blog.index')); ?> ">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text">أملج: بوابة الجمال والتاريخ على ساحل البحر الأحمر</span>
                                                                                                           </a>
                                                                                                       </li>
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('blog.index')); ?> ">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text"> استمتع بتجربة استثنائية في المنتجعات الأولى</span>
                                                                                                           </a>
                                                                                                       </li>

                                                                                                   </ul>
                                                                                               </div>
                                                                                           </div>
                                                                                       </div>
                                                                                   </div>
                                                                               </div>
                                                                           </section>
                                                                       </div>
                                                                   </div>
                                                               </div>
                                                           </div>
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                           <div class="elementor-column elementor-col-20 elementor-inner-column elementor-element elementor-element-609698a"
                                               data-id="609698a" data-element_type="column">
                                               <div class="elementor-widget-wrap elementor-element-populated">
                                                   <div class="elementor-element elementor-element-415c5ac elementor-widget elementor-widget-wdt-accordion-and-toggle"
                                                       data-id="415c5ac" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="wdt-accordion-and-toggle.default">
                                                       <div class="elementor-widget-container">
                                                           <div class="wdt-accordion-toggle-holder wdt-module-toggle wdt-template-default wdt-expand-collapse-position-end accordion ui-accordion ui-accordion-icons ui-widget ui-helper-reset"
                                                               id="wdt-accordion-and-toggle-415c5ac">
                                                               <div class="wdt-accordion-toggle-wrapper">
                                                                   <div
                                                                       class="wdt-accordion-toggle-title-holder ui-accordion-header ui-state-default ui-corner-top ui-corner-bottom">
                                                                       <div class="wdt-accordion-toggle-title">روابط سريعة</div>
                                                                       <div class="wdt-accordion-toggle-icon">
                                                                           <div
                                                                               class="wdt-accordion-toggle-icon-expand">
                                                                               <svg aria-hidden="true"
                                                                                   class="e-font-icon-svg e-fas-plus"
                                                                                   viewBox="0 0 448 512"
                                                                                   xmlns="http://www.w3.org/2000/svg">
                                                                                   <path
                                                                                       d="M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z">
                                                                                   </path>
                                                                               </svg></div>
                                                                           <div
                                                                               class="wdt-accordion-toggle-icon-collapse">
                                                                               <svg aria-hidden="true"
                                                                                   class="e-font-icon-svg e-fas-minus"
                                                                                   viewBox="0 0 448 512"
                                                                                   xmlns="http://www.w3.org/2000/svg">
                                                                                   <path
                                                                                       d="M416 208H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h384c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z">
                                                                                   </path>
                                                                               </svg></div>
                                                                       </div>
                                                                   </div>
                                                                   <div class="wdt-accordion-toggle-description ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom"
                                                                       style="display: none;">
                                                                       <style>
                                                                           .elementor-widget-icon-list .elementor-icon-list-item:not(:last-child):after {
                                                                               border-color: var(--e-global-color-text);
                                                                           }

                                                                           .elementor-widget-icon-list .elementor-icon-list-icon i {
                                                                               color: var(--e-global-color-primary);
                                                                           }

                                                                           .elementor-widget-icon-list .elementor-icon-list-icon svg {
                                                                               fill: var(--e-global-color-primary);
                                                                           }

                                                                           .elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
                                                                           .elementor-widget-icon-list .elementor-icon-list-item>a {
                                                                               font-family: var(--e-global-typography-text-font-family), Sans-serif;
                                                                               font-weight: var(--e-global-typography-text-font-weight);
                                                                               line-height: var(--e-global-typography-text-line-height);
                                                                           }

                                                                           .elementor-widget-icon-list .elementor-icon-list-text {
                                                                               color: var(--e-global-color-secondary);
                                                                           }

                                                                           .elementor-15852 .elementor-element.elementor-element-7dd0c1b .elementor-icon-list-icon i {
                                                                               transition: color 0.3s;
                                                                           }

                                                                           .elementor-15852 .elementor-element.elementor-element-7dd0c1b .elementor-icon-list-icon svg {
                                                                               transition: fill 0.3s;
                                                                           }

                                                                           .elementor-15852 .elementor-element.elementor-element-7dd0c1b {
                                                                               --e-icon-list-icon-size: 14px;
                                                                               --icon-vertical-offset: 0px;
                                                                           }

                                                                           .elementor-15852 .elementor-element.elementor-element-7dd0c1b .elementor-icon-list-text {
                                                                               transition: color 0.3s;
                                                                           }

                                                                           @media(max-width:1540px) {

                                                                               .elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
                                                                               .elementor-widget-icon-list .elementor-icon-list-item>a {
                                                                                   line-height: var(--e-global-typography-text-line-height);
                                                                               }
                                                                           }

                                                                           @media(max-width:1024px) {

                                                                               .elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
                                                                               .elementor-widget-icon-list .elementor-icon-list-item>a {
                                                                                   line-height: var(--e-global-typography-text-line-height);
                                                                               }
                                                                           }

                                                                           @media(max-width:479px) {

                                                                               .elementor-widget-icon-list .elementor-icon-list-item>.elementor-icon-list-text,
                                                                               .elementor-widget-icon-list .elementor-icon-list-item>a {
                                                                                   line-height: var(--e-global-typography-text-line-height);
                                                                               }
                                                                           }
                                                                       </style>
                                                                       <div data-elementor-type="section"
                                                                           data-elementor-id="15852"
                                                                           class="elementor elementor-15852">
                                                                           <section
                                                                               class="elementor-section elementor-top-section elementor-element elementor-element-a90fb6d elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                                                               data-id="a90fb6d"
                                                                               data-element_type="section"
                                                                               data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                                                                               <div
                                                                                   class="elementor-container elementor-column-gap-no">
                                                                                   <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0f5e8a1"
                                                                                       data-id="0f5e8a1"
                                                                                       data-element_type="column">
                                                                                       <div
                                                                                           class="elementor-widget-wrap elementor-element-populated">
                                                                                           <div class="elementor-element elementor-element-7dd0c1b elementor-list-item-link-inline elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list"
                                                                                               data-id="7dd0c1b"
                                                                                               data-element_type="widget"
                                                                                               data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                                                               data-widget_type="icon-list.default">
                                                                                               <div
                                                                                                   class="elementor-widget-container">
                                                                                                   <ul
                                                                                                       class="elementor-icon-list-items">
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('guests.reviews')); ?>">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text"> اراء النزلاء</span>
                                                                                                           </a>
                                                                                                       </li>
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('frontend.rooms')); ?>">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text"> قسم الغرف</span>
                                                                                                           </a>
                                                                                                       </li>
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('frontend.about-us')); ?>">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text">

                                                                                                                   من نحن</span>
                                                                                                           </a>
                                                                                                       </li>
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('contact')); ?>">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text"> تواصل معنا</span>
                                                                                                           </a>
                                                                                                       </li>
                                                                                                       <li
                                                                                                           class="elementor-icon-list-item">
                                                                                                           <a
                                                                                                               href="<?php echo e(route('frontend.our-services')); ?>">

                                                                                                               <span
                                                                                                                   class="elementor-icon-list-text">  خدماتنا</span>
                                                                                                           </a>
                                                                                                       </li>

                                                                                                   </ul>
                                                                                               </div>
                                                                                           </div>
                                                                                       </div>
                                                                                   </div>
                                                                               </div>
                                                                           </section>
                                                                       </div>
                                                                   </div>
                                                               </div>
                                                           </div>
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                           
                                       </div>
                                   </section>
                                   <section
                                       class="elementor-section elementor-inner-section elementor-element elementor-element-1dfcbbe elementor-section-content-middle wdt-dark-bg wdt-section-wrap-col elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                       data-id="1dfcbbe" data-element_type="section"
                                       data-settings="{&quot;wdt_bg_image&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_laptop&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_tablet&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile_extra&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_image_mobile&quot;:{&quot;url&quot;:&quot;&quot;,&quot;id&quot;:&quot;&quot;,&quot;size&quot;:&quot;&quot;},&quot;wdt_bg_position&quot;:&quot;center center&quot;,&quot;wdt_animation_effect&quot;:&quot;none&quot;}">
                                       <div class="elementor-container elementor-column-gap-no">
                                           <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1eb0f08"
                                               data-id="1eb0f08" data-element_type="column">
                                               <div class="elementor-widget-wrap elementor-element-populated">
                                                   <div class="elementor-element elementor-element-6d42fed wdt-dark-bg elementor-widget-mobile_extra__width-auto elementor-widget elementor-widget-text-editor"
                                                       data-id="6d42fed" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="text-editor.default">
                                                       <div class="elementor-widget-container">
                                                           <p><a
                                                                   href="<?php echo e(route('frontend.home')); ?>">Enala Hotel</a>&nbsp;
                                                               © 2024 &nbsp; </p>
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                           <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-5519fab"
                                               data-id="5519fab" data-element_type="column">
                                               <div class="elementor-widget-wrap elementor-element-populated">
                                                   <div class="elementor-element elementor-element-26d22a4 elementor-widget__width-auto elementor-widget elementor-widget-image"
                                                       data-id="26d22a4" data-element_type="widget"
                                                       data-settings="{&quot;wdt_animation_effect&quot;:&quot;none&quot;}"
                                                       data-widget_type="image.default">
                                                       <div class="elementor-widget-container">
                                                           <img loading="lazy" width="684" height="60"
                                                               src="./RTL GrassRoot Site – Your SUPER-powered WP Engine Site_files/footer-payment.png"
                                                               class="attachment-full size-full wp-image-16391"
                                                               alt=""
                                                               srcset="https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-payment.png 684w, https://wdtgrassroot.wpengine.com/rtl-demo/wp-content/uploads/sites/3/2025/01/footer-payment-300x26.png 300w"
                                                               sizes="(max-width: 684px) 100vw, 684px">
                                                       </div>
                                                   </div>
                                               </div>
                                           </div>
                                       </div>
                                   </section>
                               </div>
                           </div>
                       </div>
                   </section>
               </div>
           </div>
       </div>
   </footer> <!-- **Footer - End** -->
<?php /**PATH D:\KSA\hotel\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>